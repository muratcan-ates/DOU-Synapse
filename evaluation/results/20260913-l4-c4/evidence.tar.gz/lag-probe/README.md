# Sabit eşikli, tek koşuluk gecikme tanısı

Bu eklenti yalnız şu orijinal testi kabul eder:

`tests/test_event_loop_blocking.py::TestIngestionLoopUnaffected::test_belge_islenirken_saglik_yoklamasi_kesintisiz_yanit_verir`

**Durum: hazırlanmış, çalıştırılmadı.** Kaynak sözdizimi AST ile okundu; pytest, model veya veritabanı çalıştırılmadı. Depo kaynakları değiştirilmedi. Bu dosyalar proje çıktı dizinindedir.

## Tek koşuluk protokol

1. Root, mevcut izole L4 PostgreSQL kümesinin kimliğini doğrular. Yeni ve benzersiz test DB adı ile mevcut güvenli test ortamını kurar. Ortam/DSN/parola bu eklenti tarafından okunmaz veya rapora yazılmaz.
2. Birbirinden bağımsız ağır süreçler dururken tek koşu başlatılır. Root dış süreç sarmalayıcısında **60 saniyelik sert üst sınır** uygular. Sınır aşılırsa süreç sahibi kendi alt süreçlerini temizler, timeout sonucunu ayrı receipt'e yazar ve rapor `finished=false` olarak korunur. Eklenti ürün görevini iptal ederek farklı bir davranış oluşturmaz.
3. Eklenti aynı istemciyle **1 saniye sağlık kontrolü → değiştirilmemiş orijinal test → 1 saniye sağlık kontrolü** uygular. Kontrol pencerelerinde 100 ms aşımı özgün testi atlatmaz; gözlem olarak kaydedilir. Kontrolün 200 dönmemesi fixture hatasıdır.
4. Orijinal testin **<100 ms**, **POST 202** ve **sağlayıcı gerçekten çağrıldı** doğrulamaları aynen çalışır. Eklenti eşik ve 0.4 saniyelik sahte sağlayıcı gecikmesini değiştirmek yerine başlangıçta sabit olduklarını doğrular.
5. Sonuç hangi renk olursa olsun saklanır; aynı deney yeşile ulaşmak için tekrarlanmaz. Tanısal geçiş, önceki tam paket başarısızlığını silmez ve tam API kapısının geçtiği anlamına gelmez.

## Çağırma

Çalışma dizini `/Users/muratates/code/dou-synapse-018-l4-retrieval-ops/apps/api` olmalı. Aşağıdaki komut **yalnız root'un zaten izole küme/DB ortamını sağlayan ve süreyi sınırlayan sarmalayıcısının içinde** kullanılmalıdır. Tek başına varsayılan DB ayarlarıyla çalıştırılmamalıdır.

```text
PYTHONPATH=/Users/muratates/.codex/.chatgpt-projects/g-p-6a7ba85af06c8191968907d3148d90a7/outputs/DOU-Synapse-L4-2026-09-13/lag-probe:/Users/muratates/code/dou-synapse-018-l4-retrieval-ops/apps/api

/Users/muratates/code/dou-synapse-018-l4-retrieval-ops/apps/api/.venv/bin/python -m pytest -q -p dou_lag_probe --lag-probe-output=/Users/muratates/.codex/.chatgpt-projects/g-p-6a7ba85af06c8191968907d3148d90a7/outputs/DOU-Synapse-L4-2026-09-13/lag-probe/observation-001.json tests/test_event_loop_blocking.py::TestIngestionLoopUnaffected::test_belge_islenirken_saglik_yoklamasi_kesintisiz_yanit_verir
```

`PYTHONPATH` satırı komut çıktısına basılacak bir ortam dökümü değildir; root sarmalayıcısı kendi child-env sözlüğüne bu değeri ekler. Mevcut özel veritabanı değişkenleri aynı sarmalayıcıdan gelir. `observation-001.json` önceden varsa eklenti fixture'lar başlamadan reddeder; önceki kanıtı üzerine yazmaz.

## Kaydedilenler

- Ön/son kaynak SHA-256 damgaları, özgün test sonucu ve pytest çıkış kodu.
- Statik faz adları, monotonic başlangıç/bitiş, wall time, thread CPU time, thread kimliği ve event loop thread'i olup olmadığı.
- Her sağlık çağrısının süresi; 10 ms asyncio tick'lerinin gecikmesi. Pencere sınırını aşan tick `transition` olur.
- Ön kontrol, `treatment_preparation`, sağlık yoklaması başladıktan sonraki `treatment`, son kontrol ayrımı. Orijinal `make_pdf` işi ölçülen sağlık yoklamasından önce gerçekleşir; onun süresi yanlışlıkla sağlık gecikmesinin nedeni sayılmaz.
- En çok **12000 ham olay**; bu sınır aşılırsa düşen olay sayısı görünür. Faz başına adet/maksimum özeti kayıp olsa bile korunur. Kontrol başına ayrıca 10000 istek üst sınırı vardır.
- Ham belge, başlık, kullanıcı kimliği, exception metni, DSN veya environment yoktur. Debug slow-callback logging açılmaz; task repr argüman sızdırabilir.

Belge doğrulama/hash, kaynak hash, yerel yol çözümleme, worker import/engine kurulumu, parser/chunking, embedding, logging senkron süreleri ölçülür. Claim, verify, process ve finalize async fazları ayrıca ölçülür. `from app import worker` cold import'u **önceden yapılmaz**: asıl ürün import'u çağrılırken ölçülür, döndüğünde alt işlevler geçici sarılır. Daha önceden yüklenmiş modüller raporda belirtilir. Tüm monkeypatch'ler fixture bitince geri alınır.

## Sonucu yorumlama

- Kontrolde de sağlık >100 ms: ingestion olmadan eşiğin aşılması gösterilir. Bu, upload yolunu aklamaz ve tek başına OS bellek baskısını kanıtlamaz.
- Yalnız treatment'ta sağlık >100 ms ve aynı aralıkta event loop thread'inde belirli **sync_span** >100 ms: o işlev için güçlü, somut inceleme adayı. CPU/wall farkına bakılır; ölçüm araçlarının da ek yük getirdiği belirtilir.
- Senkron wall time büyük, thread CPU küçük: scheduling veya blocking I/O ile uyumlu; aralarındaki ayrım henüz yapılmamıştır.
- Parser/embedding worker thread'inde uzun sürmüş fakat sağlık hızlı: uzun işlem süresi, event loop blokajı değildir.
- Async fazın thread CPU süresi yalnız o faza ait değildir; aynı thread'deki başka coroutineleri de içerir. Async fazın uzun wall time'ı tek başına blokaj değildir.
- Sağlık gecikmesi var, karşılık gelen ölçülmüş senkron segment yok: **INCONCLUSIVE**; ölçülmeyen callback, C uzantısı/GIL, OS scheduling veya ölçüm yükü aday olarak kalır.
- Ön kontrol sağlık taşımasını ısıtır; bu bir tanıdır, cold kabul denemesinin yerine geçmez. Test kapsamı, 100 ms eşiği ve orijinal başarısız koşular korunur.

Rapor disk yazıları pencere arasında veya koşu sonunda yapılır; ölçüm boyunca periyodik senkron disk yazısı eklenmez. Bu nedenle hard-timeout/crash, en son tamamlanan pencerenin receipt'ini bırakabilir; tamamlanmamış kayıt başarı değildir.
