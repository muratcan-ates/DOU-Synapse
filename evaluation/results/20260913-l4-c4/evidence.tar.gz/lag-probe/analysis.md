# 2026-09-13 — tek tanısal koşunun değerlendirmesi

**Sonuç:** Değiştirilmemiş testin bu tanısal koşusu geçti. Ölçülen upload sırasında 100 ms üzerinde sağlık gecikmesi veya event-loop thread'inde 100 ms üzerinde adlandırılmış senkron faz görülmedi. Önceki iki başarısız cold koşunun kök nedeni hâlâ **INCONCLUSIVE**. Ürün hatası düzeltildi veya tam API kapısı geçti denemez.

Bu değerlendirme yalnız mevcut JSON/log dosyalarını okudu. Ek test, model veya veritabanı koşusu yapılmadı. Önceki `lag-audit.md`, eklenti ve hazırlık kayıtları değiştirilmedi.

## Koşu ve kanıt bütünlüğü

- Root'un tek tanısal koşusu: **2026-09-13 14:42:18–14:42:33 UTC**.
- Pytest: **1 passed, 5 warnings in 10.84s**, çıkış kodu **0**. Setup/call/teardown geçti.
- Orijinal kabul sınırı **<0.1 s**, sahte sağlayıcı gecikmesi **0.4 s**; eklenti ikisinin sabitliğini doğruladı. Orijinal POST 202 ve sağlayıcı çağrıldı doğrulamaları korundu.
- Eklenti `finished=true`, `stage=diagnostic_complete`; kaynakların ön/son SHA-256 eşleşmesi hem eklentide hem root receipt'inde doğrulandı.
- **468 ham olay, 0 düşen olay**; kontrol istek sayısı sınırına ulaşılmadı.
- Kontrol başlamadan önce `app.worker`, ingestion pipeline ve `pymupdf` yüklenmemişti. Worker'ın ilk import'u treatment sırasında ölçüldü; ölçümden önce worker import edilmedi.
- `logging_dispatch` olayı yok. Bu koşu logging sink maliyetini ölçmüş sayılmaz; sıfır maliyet sonucu çıkarılamaz.

| Kanıt dosyası | SHA-256 |
|---|---|
| `observation-001.json` | `0dadfa056e82c7d12817e61176e118f08483535edf40a11ac7f321a8a6a3b66d` |
| `../c4-api-lag-diagnostic/result.json` | `67b0284cc1da88596bd06a34ba993c5563a69d9a17e2c350d31ffbfe28d4c3dc` |
| `dou_lag_probe.py` | `cec7356d5e99f6560534a13280bca11c742cb428706aded3bdb1081aa03958fb` |

## Sağlık çağrıları

Değerler eklentinin sakladığı ham HTTP span'lerinden türetildi. P95, nearest-rank yöntemiyle hesaplandı; bu yeni bir deney değildir.

| Pencere | Çağrı | Medyan | P95 | Maksimum | ≥100 ms |
|---|---:|---:|---:|---:|---:|
| Ön kontrol | 91 | 7.426 ms | 27.845 ms | **92.899 ms** | 0 |
| Treatment: upload sırasında sağlık | 75 | 6.020 ms | 41.896 ms | **62.182 ms** | 0 |
| Son kontrol | 82 | 9.116 ms | 32.802 ms | **82.979 ms** | 0 |

Kontrol pencereleri birer saniye hedefledi; son isteğin tamamlanmasıyla gerçek süreler yaklaşık 1.003 ve 1.047 saniye oldu. Treatment sağlık penceresi yaklaşık 0.822 saniyeydi. Aynı pencerelerde loop tick gecikme maksimumları sırasıyla **41.939 / 38.506 / 23.242 ms** idi. Buradaki tick gecikmesi, 10 ms istenen bekleme çıkarıldıktan sonraki değerdir; HTTP süresiyle aynı ölçüt değildir.

Treatment'ın kontrol maksimumlarından küçük olması bir performans iyileştirmesi göstermez: tek koşu, farklı pencere uzunlukları, ön kontrolün health yolunu ısıtması ve araç yükü vardır. Orijinal testin kendi doğrulamasının geçmesi ayrıca receipt'te mevcuttur.

## Adlandırılmış senkron fazlar

| Faz | Yer | Wall time | Thread CPU | Bu koşunun söylediği |
|---|---|---:|---:|---|
| İlk worker import'u | Event loop thread'i | **17.125 ms** | **12.235 ms** | En uzun ölçülen event-loop senkron fazı; 100 ms altında. |
| Worker engine/factory kurulumu | Event loop thread'i | 0.637 ms | 0.552 ms | Bu örnekte kısa. |
| Storage yol çözümleme, en uzun çağrı | Event loop thread'i | 0.725 ms | 0.422 ms | Bu örnekte kısa; iki çağrı var. |
| Upload doğrulama | Event loop thread'i | 0.125 ms | 0.123 ms | Küçük PDF için kısa. |
| Upload SHA-256 oluşturma | Event loop thread'i | 0.0115 ms | 0.0114 ms | Küçük PDF için kısa. |
| Kaynak SHA-256 oluşturma | Event loop thread'i | 0.0093 ms | 0.0093 ms | Küçük PDF için kısa. |
| Parser + chunking | **Ayrı thread** | **36.512 ms** | **13.872 ms** | Event loop üzerinde doğrudan çalışmadığı doğrulandı. |
| Sahte embedding | **Ayrı thread** | **403.254 ms** | **0.511 ms** | 0.4 s `sleep` içeren sağlayıcıyla uyumlu; uzun süre sağlık yolunu >100 ms bekletmedi. |

Parser ve embedding farklı worker thread kimliklerinde görüldü. Thread kimlikleri yalnız bu süreç içindeki yerleşim kanıtıdır; başka koşulara taşınmaz. SHA fazı ölçümü `sha256(content)` oluşturmasını kapsar; sonraki `hexdigest()` çağrısı ayrı ölçülmemiştir.

`process_document` async span'i 441.811 ms, `finalize_document` 55.659 ms ve upload HTTP span'i 813.277 ms sürdü. Bunlar await edilen işleri de kapsar. Async span'lerde thread CPU zamanı aynı loop üzerindeki başka coroutine'lerin çalışmasını içerdiği için münhasır işlem maliyeti değildir. Upload'ın yaklaşık 813 ms sürmesi, sağlık çağrısının 813 ms bloke olması anlamına gelmez.

## 438.855 ms transition tick'in doğru yorumu

Tek büyük loop tick şu aralıkta:

- Tick başlangıcı: `1612607588125 ns`
- Orijinal test başlangıcı: `1612613724291 ns`
- İlk treatment sağlık çağrısı başlangıcı: `1613055623500 ns`
- Tick bitişi: `1613056443500 ns`

Tick toplam beklemesi **448.855 ms**, 10 ms çıkarıldıktan sonraki gecikme **438.855 ms**. Bunun neredeyse tamamı ilk treatment sağlık çağrısından **önceki** aralığı kapsıyor. Bitişin ilk sağlık başlangıcından sonra kalan kısmı yalnız **0.820 ms**; bu nedenle “tamamen sağlık penceresi dışında” demek de teknik olarak doğru olmaz.

Orijinal test bu önceki hazırlık aralığında PDF'yi üretir; health yoklaması bundan sonra başlar. Eklenti tick'i bu yüzden `transition` olarak işaretledi. Bu gözlem **438 ms sağlık blokajı kanıtı değildir** ve treatment health maksimumuna eklenmemelidir. Hazırlıktaki ilk PyMuPDF kullanımıyla zaman bakımından uyumludur; eklenti PDF üretimi/import içini ayrı fazlara ayırmadığından tek başına hangi alt işin kaç ms tuttuğunu kanıtlamaz. Tick'in yaklaşık 255 ms thread CPU değeri de bütün aralığı kapsar, tek bir işleme ait değildir.

## Karar ve kalan sınır

Bu koşu, mevcut `to_thread` sarmalarının parser ve sahte embedding'i event loop dışına taşıdığını somut olarak gösterdi. Ölçülen senkron adaylardan hiçbiri bu koşuda 100 ms sağlık arızasını üretmedi. Dolayısıyla yalnız önceki gecikmelerden hareketle rastgele sarma/threshold değişikliği yapmak için kanıt yok.

Önceki tam paket koşusundaki **131.320 ms** ve yeniden başlatma sonrası hedefli cold koşudaki **220.816 ms** başarısızlıklar aynen geçerlidir. Bugün yapılan deney ek kontrol ve araç yükü içerir; pre-control health yolunu ısıtır. Kök neden, bir yazılım düzeltmesi veya işletim sistemi bellek baskısına nedensel bağ bu verilerle doğrulanmış değildir.

**ENGEL korunur:** sabit 100 ms tam API kabul kapısının başarısızlığı kapanmadı. Bu tanısal geçiş tam paket kabulü yerine yazılmamalı. Bağımsız L4 işleri sürdürülebilir; bu deney yeşile kadar tekrar edilmemelidir.
