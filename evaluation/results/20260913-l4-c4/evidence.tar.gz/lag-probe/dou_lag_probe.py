"""One-run diagnostics around the unchanged L4 ingestion responsiveness test.

No thresholds, fixtures, provider delays or product results are replaced. This
plugin is deliberately restricted to one exact test. An external process owner
must enforce a hard timeout; this plugin does not cancel product work.
"""

from __future__ import annotations

import asyncio
import builtins
import contextlib
import functools
import hashlib
import json
import logging
import os
from pathlib import Path
import sys
import tempfile
import threading
import time

import pytest
import pytest_asyncio


EXACT_NODE = (
    "tests/test_event_loop_blocking.py::TestIngestionLoopUnaffected::"
    "test_belge_islenirken_saglik_yoklamasi_kesintisiz_yanit_verir"
)
CONTROL_SECONDS = 1.0
TICK_SECONDS = 0.01
MAX_EVENTS = 12000
MAX_CONTROL_REQUESTS = 10000
ACCEPTANCE_SECONDS = 0.1
SOURCE_PATHS = (
    "tests/test_event_loop_blocking.py",
    "tests/factories.py",
    "tests/conftest.py",
    "app/api/documents.py",
    "app/api/health.py",
    "app/api/internal.py",
    "app/main.py",
    "app/worker.py",
    "app/core/db.py",
    "app/core/logging.py",
    "app/modules/ingestion/pipeline.py",
    "app/modules/ingestion/storage.py",
    "app/modules/ingestion/validation.py",
)
STATE = None


def _hash_sources(api_root):
    return {
        relative: hashlib.sha256((api_root / relative).read_bytes()).hexdigest()
        for relative in SOURCE_PATHS
    }


class ProbeState:
    def __init__(self, output, api_root):
        self.output = output
        self.api_root = api_root
        self.lock = threading.Lock()
        self.window = "setup"
        self.events = []
        self.dropped_events = 0
        self.phase_summary = {}
        self.main_thread = threading.get_ident()
        self.before = _hash_sources(api_root)
        self.after = None
        self.windows = {}
        self.test_outcomes = {}
        self.stage = "reserved_before_fixtures"
        self.finished = False
        self.started_ns = time.perf_counter_ns()
        self.threshold_verified = False
        self.slow_provider_verified = False
        self.modules_loaded_before_controls = {}

    def event(self, *, phase, window, start_ns, end_ns, cpu_ns, kind, **extra):
        event = {
            "kind": kind,
            "phase": phase,
            "window": window,
            "start_ns": start_ns,
            "end_ns": end_ns,
            "wall_ns": max(0, end_ns - start_ns),
            "thread_cpu_ns": max(0, cpu_ns),
            "thread_id": threading.get_ident(),
            "on_event_loop_thread": threading.get_ident() == self.main_thread,
            **extra,
        }
        with self.lock:
            key = (window, kind, phase)
            summary = self.phase_summary.setdefault(
                key,
                {
                    "window": window,
                    "kind": kind,
                    "phase": phase,
                    "count": 0,
                    "max_wall_ns": 0,
                    "max_thread_cpu_ns": 0,
                    "over_100ms": 0,
                    "failure_count": 0,
                    "max_scheduling_lag_ns": 0,
                    "scheduling_lag_over_100ms": 0,
                },
            )
            summary["count"] += 1
            summary["max_wall_ns"] = max(summary["max_wall_ns"], event["wall_ns"])
            summary["max_thread_cpu_ns"] = max(summary["max_thread_cpu_ns"], event["thread_cpu_ns"])
            summary["over_100ms"] += event["wall_ns"] >= 100_000_000
            summary["failure_count"] += extra.get("completed") is False
            lag = extra.get("scheduling_lag_ns", 0)
            summary["max_scheduling_lag_ns"] = max(summary["max_scheduling_lag_ns"], lag)
            summary["scheduling_lag_over_100ms"] += lag >= 100_000_000
            if len(self.events) < MAX_EVENTS:
                self.events.append(event)
            else:
                self.dropped_events += 1

    def snapshot(self):
        with self.lock:
            return {
                "schema": "dou-lag-probe/v1",
                "diagnostic_only": True,
                "not_a_replacement_for_original_cold_gate": True,
                "stage": self.stage,
                "finished": self.finished,
                "exact_test": EXACT_NODE,
                "fixed_acceptance_seconds": ACCEPTANCE_SECONDS,
                "original_threshold_verified": self.threshold_verified,
                "slow_provider_0_4s_verified": self.slow_provider_verified,
                "modules_loaded_before_controls": dict(self.modules_loaded_before_controls),
                "control_seconds_each": CONTROL_SECONDS,
                "tick_interval_seconds": TICK_SECONDS,
                "maximum_events": MAX_EVENTS,
                "dropped_events": self.dropped_events,
                "started_monotonic_ns": self.started_ns,
                "source_sha256_before": self.before,
                "source_sha256_after": self.after,
                "sources_unchanged": self.after == self.before if self.after else None,
                "plugin_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "test_outcomes": dict(self.test_outcomes),
                "windows": dict(self.windows),
                "phase_summary": list(self.phase_summary.values()),
                "events": list(self.events),
                "limitations": [
                    "Pre-control warms health transport; no worker or upload warmup is performed.",
                    "Instrumentation adds timing, allocation and lock overhead.",
                    "Async-span thread CPU includes other tasks on the same event loop thread.",
                    "Long async wall time alone is not evidence of event-loop blocking.",
                    "Wall-minus-thread-CPU does not distinguish OS descheduling from blocking I/O.",
                    "Only named synchronous operations are instrumented; attribution may remain inconclusive.",
                    "Loop ticks crossing a window boundary are labelled transition.",
                    "Original PDF creation is treatment_preparation, before treatment health polling starts.",
                    "No raw arguments, documents, headers, exceptions, DSNs or environment are recorded.",
                    "No debug slow-callback logging: task repr can contain request arguments.",
                    "A separate process owner must enforce the hard timeout.",
                ],
            }

    def persist(self):
        # Called between measurement windows or after test completion, never
        # periodically on the event loop while the response gate is measured.
        payload = json.dumps(self.snapshot(), indent=2, sort_keys=True) + "\n"
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=self.output.parent,
                prefix=".lag-probe-", suffix=".json", delete=False,
            ) as stream:
                temporary = Path(stream.name)
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.output)
        finally:
            if temporary is not None:
                with contextlib.suppress(FileNotFoundError):
                    temporary.unlink()


def pytest_addoption(parser):
    parser.addoption("--lag-probe-output", help="New, non-existing diagnostic JSON path.")


def pytest_configure(config):
    global STATE
    requested = config.getoption("--lag-probe-output")
    if not requested:
        raise pytest.UsageError("--lag-probe-output must name a new JSON file")
    output = Path(requested).absolute()
    api_root = Path(config.rootpath).resolve()
    if not (api_root / "tests/test_event_loop_blocking.py").is_file():
        raise pytest.UsageError("Run from the repository apps/api directory")
    try:
        # Do not overwrite earlier evidence, and fail before DB/test fixtures.
        with output.open("x", encoding="utf-8") as stream:
            stream.write('{"schema":"dou-lag-probe/v1","stage":"reserved","finished":false}\n')
    except OSError:
        raise pytest.UsageError("Diagnostic output must be new and its parent must exist") from None
    STATE = ProbeState(output, api_root)
    STATE.persist()


def pytest_collection_modifyitems(session, config, items):
    del session, config
    if len(items) != 1 or items[0].nodeid != EXACT_NODE:
        raise pytest.UsageError("This diagnostic plugin permits only its one exact ingestion test")


def _sync_wrapper(state, phase, original):
    @functools.wraps(original)
    def wrapped(*args, **kwargs):
        window = state.window
        started = time.perf_counter_ns()
        cpu = time.thread_time_ns()
        completed = False
        try:
            result = original(*args, **kwargs)
            completed = True
            return result
        finally:
            ended = time.perf_counter_ns()
            consumed = time.thread_time_ns() - cpu
            state.event(phase=phase, window=window, start_ns=started, end_ns=ended,
                        cpu_ns=consumed, kind="sync_span", completed=completed)
    return wrapped


def _async_wrapper(state, phase, original):
    @functools.wraps(original)
    async def wrapped(*args, **kwargs):
        if phase == "health_http" and state.window == "treatment_preparation":
            state.window = "treatment"
            state.windows["treatment_health_polling"] = {"start_ns": time.perf_counter_ns()}
        window = state.window
        started = time.perf_counter_ns()
        cpu = time.thread_time_ns()
        completed = False
        try:
            result = await original(*args, **kwargs)
            completed = True
            return result
        finally:
            ended = time.perf_counter_ns()
            consumed = time.thread_time_ns() - cpu
            state.event(phase=phase, window=window, start_ns=started, end_ns=ended,
                        cpu_ns=consumed, kind="async_span", completed=completed,
                        cpu_is_exclusive=False)
    return wrapped


class HashModuleProxy:
    """Replace only a module's hashlib reference, not global hashlib functions."""
    def __init__(self, original, sha256):
        self._original = original
        self.sha256 = sha256

    def __getattr__(self, name):
        return getattr(self._original, name)


def _install(state, patch, client, provider):
    from app.api import documents
    from app.modules.ingestion import storage, validation

    sync_targets = (
        (documents, "validate_upload", "upload_validate"),
        (storage.LocalFileStorage, "_resolve", "storage_resolve"),
        (provider, "embed_documents", "embedding_documents"),
        (logging.Logger, "callHandlers", "logging_dispatch"),
    )
    async_targets = (
        (client, "get", "health_http"),
        (client, "post", "upload_http"),
        (storage.LocalFileStorage, "save", "storage_save"),
        (storage.LocalFileStorage, "load", "storage_load"),
    )
    for owner, name, phase in sync_targets:
        patch.setattr(owner, name, _sync_wrapper(state, phase, getattr(owner, name)))
    for owner, name, phase in async_targets:
        patch.setattr(owner, name, _async_wrapper(state, phase, getattr(owner, name)))
    original_hashlib = validation.hashlib
    patch.setattr(validation, "hashlib", HashModuleProxy(
        original_hashlib, _sync_wrapper(state, "upload_hash", original_hashlib.sha256),
    ))

    installed = set()

    def install_worker_modules_if_loaded():
        # Do not pre-import worker/pipeline: their cold import is itself one of
        # the candidates. Bind after the product's original import returns.
        worker = sys.modules.get("app.worker")
        pipeline = sys.modules.get("app.modules.ingestion.pipeline")
        if worker is not None and "worker" not in installed and hasattr(worker, "drain"):
            patch.setattr(worker, "_get_session_factory", _sync_wrapper(
                state, "worker_factory", worker._get_session_factory,
            ))
            installed.add("worker")
        if pipeline is not None and "pipeline" not in installed and hasattr(pipeline, "run_pending_jobs"):
            patch.setattr(pipeline, "_parse_and_chunk", _sync_wrapper(
                state, "parse_chunk", pipeline._parse_and_chunk,
            ))
            for name in ("claim_next_job", "verify_claim", "process_document", "finalize_document"):
                patch.setattr(pipeline, name, _async_wrapper(state, name, getattr(pipeline, name)))
            original = pipeline.hashlib
            patch.setattr(pipeline, "hashlib", HashModuleProxy(
                original, _sync_wrapper(state, "source_hash", original.sha256),
            ))
            installed.add("pipeline")

    original_import = builtins.__import__
    measured_import = _sync_wrapper(state, "worker_import", original_import)

    @functools.wraps(original_import)
    def observe_worker_import(name, globals=None, locals=None, fromlist=(), level=0):
        if level == 0 and name == "app" and fromlist and "worker" in fromlist:
            module = measured_import(name, globals, locals, fromlist, level)
            install_worker_modules_if_loaded()
            return module
        return original_import(name, globals, locals, fromlist, level)

    install_worker_modules_if_loaded()
    patch.setattr(builtins, "__import__", observe_worker_import)


async def _ticks(state):
    while True:
        window = state.window
        started = time.perf_counter_ns()
        cpu = time.thread_time_ns()
        await asyncio.sleep(TICK_SECONDS)
        ended = time.perf_counter_ns()
        if window != state.window:
            window = "transition"
        state.event(phase="loop_tick", window=window, start_ns=started, end_ns=ended,
                    cpu_ns=time.thread_time_ns() - cpu, kind="loop_tick",
                    cpu_is_exclusive=False,
                    scheduling_lag_ns=max(0, ended - started - 10_000_000))


async def _control(state, client, window):
    state.window = window
    started = time.perf_counter_ns()
    deadline = started + int(CONTROL_SECONDS * 1_000_000_000)
    count = 0
    try:
        while time.perf_counter_ns() < deadline and count < MAX_CONTROL_REQUESTS:
            response = await client.get("/health/live")
            count += 1
            if response.status_code != 200:
                raise AssertionError("lag probe health control did not return 200")
    finally:
        ended = time.perf_counter_ns()
        state.windows[window] = {
            "start_ns": started, "end_ns": ended, "requests": count,
            "request_count_cap_reached": count >= MAX_CONTROL_REQUESTS,
        }
        state.window = "between_windows"


@pytest_asyncio.fixture(autouse=True)
async def lag_probe(request, client, ders, slow_provider, monkeypatch):
    del ders
    state = STATE
    assert state is not None
    test_module = request.node.module
    if test_module.MAX_ACCEPTABLE_LAG_SECONDS != ACCEPTANCE_SECONDS:
        raise AssertionError("Original 100 ms gate changed; diagnostic aborted")
    if slow_provider._delay != 0.4:
        raise AssertionError("Original 0.4 s synthetic provider changed; diagnostic aborted")
    state.threshold_verified = True
    state.slow_provider_verified = True
    state.modules_loaded_before_controls = {
        name: name in sys.modules
        for name in ("app.worker", "app.modules.ingestion.pipeline", "pymupdf")
    }
    # All instrumentation is temporary, and original call results/exceptions pass
    # through unchanged. No debug logger is enabled and no data arguments are read.
    with monkeypatch.context() as patch:
        _install(state, patch, client, slow_provider)
        ticker = asyncio.create_task(_ticks(state))
        try:
            await asyncio.sleep(0)
            await _control(state, client, "control_pre")
            state.stage = "pre_control_complete"
            state.persist()
            yield
        finally:
            # Post-control is recorded even when the original assertion fails.
            try:
                await _control(state, client, "control_post")
            finally:
                ticker.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await ticker
    state.after = _hash_sources(state.api_root)
    state.stage = "diagnostic_complete"
    state.finished = True
    state.persist()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    del item
    state = STATE
    assert state is not None
    state.window = "treatment_preparation"
    state.stage = "original_test_running"
    started = time.perf_counter_ns()
    try:
        yield
    finally:
        state.windows["treatment"] = {
            "start_ns": started, "end_ns": time.perf_counter_ns(),
            "original_assertions_preserved": True,
        }
        if "treatment_health_polling" in state.windows:
            state.windows["treatment_health_polling"]["end_ns"] = time.perf_counter_ns()
        state.window = "between_windows"


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    del item, call
    outcome = yield
    report = outcome.get_result()
    if STATE is not None:
        # Deliberately omit longrepr, captured logs and local variable values.
        STATE.test_outcomes[report.when] = report.outcome
        STATE.persist()


def pytest_sessionfinish(session, exitstatus):
    del session
    if STATE is not None:
        STATE.test_outcomes["pytest_exit_code"] = int(exitstatus)
        STATE.after = _hash_sources(STATE.api_root)
        STATE.persist()
