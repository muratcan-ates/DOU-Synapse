# L4 sağlık yoklaması gecikmesi — bağımsız salt okuma incelemesi

Tarih: 2026-09-13. Sonuç: **INCONCLUSIVE; doğrulanmış başarısız kabul kapısı, kök neden henüz ayrıştırılmadı.** Bu inceleme test, model veya veritabanı çalıştırmadı; ürün/test kaynaklarını değiştirmedi.

## Mevcut kanıt

- `c4-gates/api-result.json` ve `api.stdout.txt`: değişmemiş API kaynaklarında tam paket **1 başarısız, 1688 başarılı, 38 alt test başarılı**; ilgili sağlık yoklaması **0.13131970899848966 s**, sabit sınır **<0.1 s**. Koşu 13:44:15–14:04:48 UTC, exit 1.
- `c4-api-lag-recovery/result.json` ve `stdout.txt`: yeniden başlatma sonrası aynı tek test **0.2208155830001033 s**, exit 1; 14:32:50–14:33:21 UTC. Log ilk örneklerde ayrıca 0.1477474579999125 s ve 0.09324758399998245 s gösteriyor. Tüm örneklerin zaman damgaları ve hangi işlemle örtüştüğü kaydedilmemiş.
- İki koşuda da POST 202 ve `slow_provider.calls >= 1` iddiasına kadar geçildi. Dolayısıyla kaybolmuş worker yolu veya hiç koşmayan embedding, bu başarısızlığın açıklaması değil.
- Her iki receipt `sources_unchanged=true`. Gerçek E5/uzak sağlayıcı bu testlerin parçası değil. Ana ajan yüksek bellek sıkışması/swap bildirdi; bu olası karıştırıcıdır, tek başına nedensellik kanıtı değildir.

## Kaynakta kesin görülenler

1. `tests/test_event_loop_blocking.py:120–147`: PDF üretimi ve dolayısıyla `make_pdf` içindeki ilk PyMuPDF import'u **ölçüm başlamadan önce** tamamlanır. Bu import'u ölçülmüş gecikmenin nedeni diye sunmak yanlış olur.
2. Aynı test `139–155`, HTTPX ASGITransport ile `/health/live` uçtan uca çağrı süresini ölçer. Arka planda bütün upload → claim → parser → embedding → finalize döngüsü vardır; ölçüt tek başına parser/embedding callback süresi değildir.
3. `app/api/health.py:20–27` veritabanına gitmez. Ancak `app/main.py:161–201` güvenlik ve istek günlüğü middleware'lerinden geçer. Sağlık isteğinin >100 ms olması, kendi SQL sorgusunun yavaşlığıyla açıklanamaz.
4. `pipeline.py:74,83`: parser+chunking ve senkron embedding **zaten `asyncio.to_thread` ile çevrili**. `storage.py:63–78` dosya write/read/unlink işlemlerini de thread'e gönderir. Bu dosyalarda eksik sarma iddiası doğrulanmadı.
5. `factories.py:962–970`: sahte sağlayıcı `time.sleep(0.4)` sonra hashing çalıştırır. Bu, gerçek E5 çalışma/başlatma veya PDF C uzantısının GIL davranışı için performans kanıtı değildir.
6. `conftest.py:182–190` `ASGITransport(app=app)` kurar, lifespan bağlamı açmaz. Dolayısıyla bu testin otomatik startup warmup çalıştırdığı varsayılamaz. `worker_cleanup` ayrıca her test sonunda worker engine'i dispose eder (`122–127`); worker havuzu bu testte tekrar kurulabilir.

## Somut iyileştirme adayları; bu arızanın kanıtlanmış nedeni değiller

| Konum | Event loop üzerinde kalan senkron iş | Yorum |
|---|---|---|
| `app/api/documents.py:82–88`, `validation.py:95–102` | UTF-8 çözümleme / SHA-256 / dosya adı temizliği | Büyük upload altında ölçmeye değer. Buradaki küçük PDF için UTF-8 yolu kullanılmaz, hash'in 100 ms sürdüğüne dair kayıt yok. |
| `pipeline.py:71–73` | Yüklenmiş kaynağın SHA-256 doğrulaması | Güvenlik doğrulaması kaldırılmamalı; gerekirse thread'e taşınması ayrı kanıtla değerlendirilir. Küçük PDF arızasının kanıtı değil. |
| `storage.py:54–61,69–70` | `Path.resolve()` dosya sistemi kontrolü | Async yöntemin içinde thread'e gönderilmemiş dosya sistemi işi. Süresi bu koşulda ölçülmemiş; L4 dışında storage değişikliği yapılmadı. |
| `pipeline.py:138–155` | Bütün chunk/embedding parametrelerinin hazırlanması ve `str(embedding)` | Büyük belgenin sonlandırılmasında artabilir. İki sayfalık küçük fixture için nedensellik kanıtı yok. |
| `app/main.py:189–200`, `core/logging.py:416–423` | Senkron log formatlama/sink write+flush; testte aktif handler ayrıca fixture/pytest durumuna bağlı | Sink backpressure veya capture maliyeti ayırt edilmeli. Bu fixture lifespan açmadığı için özel handler'ın her koşuda kurulduğu söylenemez. |
| `worker.py:36–45`, `internal.py:121–125` | İlk worker import/engine kurulumu; SQLAlchemy hazırlık aşamaları | I/O bekleyişi async olsa da ilk kurulum/derleme CPU işi içerebilir. Ölçümde cold faz yer alır; yalnız açıklayıcı adaydır. |

## En küçük ayrıştırıcı ölçüm — öneri, henüz çalıştırılmadı

Ürün/test kaynakları ve **0.1 s sınırı sabit** tutularak tek, önceden sınırlanmış tanısal koşu yapılabilir. Yeni özel test veritabanı, aynı sentetik iki sayfa PDF ve aynı SlowSyncEmbeddingProvider kullanılır. Ürün kabul testinin yerine geçirilmez; bir sonraki düzeltme kararını üretir.

1. Aynı uygulama/istemcide önce sabit **1 saniyelik sağlık yoklaması kontrol penceresi**, sonra **bir upload**, sonra sabit **1 saniyelik kontrol penceresi**. Kontrol beklemesi async olur. Upload sırasındaki yoklama yine aralıksızdır. Her istekte monotonic başlangıç/bitiş ve gecikme saklanır; üç pencerenin ham sonuçları saklanır. Kontrol penceresi >100 ms ise ortam/ASGI/logging maliyetinin ingestion olmadan da eşiği aştığı görülür; bu upload yolunu otomatik aklamaz.
2. Tanı için event loop debug slow callback sınırı **0.05 s** olarak kaydedilebilir; kabul sınırı hâlâ **0.1 s**. Upload validation, storage resolve/save/load, claim, parser, embedding ve finalize fazlarına içerik/kimlik taşımayan monotonic işaretler eklenir. İşaretler yalnız tanı katmanında tutulur; üretim loglarına kişisel veri eklenmez.
3. Gecikme penceresi bir senkron callback ile örtüşürse o callback için wall time ile `time.thread_time()` ayrılır. Yüksek wall/CPU farkı OS descheduling veya blocking I/O ile uyumludur; tek başına hangisi olduğunu kanıtlamaz. Uzun CPU segmenti ise odaklanmış kod düzeltmesi için aday olur. `to_thread` içindeki işler ayrıca thread kimliğiyle işaretlenir; async fazın uzun olması event loop bloke olduğunu tek başına göstermez.
4. İlk koşunun sonucu neyse saklanır. Önceden tanımlı kalibrasyon mevcut 0.4 s senkron çağrının >0.3 s loop gecikmesi üretmesi olabilir. **Yeşile kadar tekrar, threshold gevşetme, başarısız cold pencereyi silme veya yalnız sıcak sonucu kabul diye gösterme yoktur.**

Karar: şu anda ürüne rastgele `to_thread` sarmaları eklemek yerine **ENGEL: sabit 100 ms sağlık kapısı iki kez başarısız; nedensel faz kanıtı yok** yazılmalı. L4'ün bağımsız işleri sürdürülebilir. Tam API kapısı geçti diye raporlanamaz; tanı veya hedefli geçiş daha önceki tam paket başarısızlığını silmez.

## İncelenen kaynak damgası

HEAD: `22a85d390f759a77265e624d4d2acdf9b7c3d143`

```json
{
  "apps/api/tests/test_event_loop_blocking.py": "f67b7498c68c7199e7e65dbcc42ca5441c4976b2df353bb50414f85d67c36682",
  "apps/api/tests/factories.py": "29f2dd6245118e4feb8620ee8aa8a0da35c5c9f1e99d5cd8d98da8f88c6c93d1",
  "apps/api/tests/conftest.py": "53436c76018eee9b5ac0638ce6952cbdd2cc8087096dfba912cb94567203e8d6",
  "apps/api/app/api/documents.py": "cd1d217e187bb52c26e3d434e7b9bf09d0d1253c74d1ce5aefb4b5c1b6f735ea",
  "apps/api/app/api/health.py": "b11c51dd7f38846bca5f5250dd561a80ed0785c16750f190bdb7dcb376e20f43",
  "apps/api/app/api/internal.py": "6feec72a87a91cef026b7052f0c1f997335319ff6272dfe7c02242f30a11a816",
  "apps/api/app/main.py": "429994118397a91b5502c3afddf3d2f9f7e6f5b471943f4443ebfaf9534031d0",
  "apps/api/app/modules/ingestion/pipeline.py": "4cd396f9f5f6712791b4cf4b98dce7c6a89681adf59e56592846f673c19ef14f",
  "apps/api/app/modules/ingestion/storage.py": "adf22e4d56517f1fabff32a269e70d6853e2aaa06e96c09bac7207d35b36e2a1",
  "apps/api/app/modules/ingestion/validation.py": "7bbcbce699a2e4f26647f1d73f1f4e9a167a09f10a0a7b684145e2b860389ba7",
  "apps/api/app/worker.py": "2cdbea27191cadd0bd2d73f88857b3e461122bdde0f4bdebc98f606771b7a634",
  "apps/api/app/core/logging.py": "e8523eb720219c5137c950f0f73dcad38a6ea300619f3b848c4592065b3d67a5"
}
```
