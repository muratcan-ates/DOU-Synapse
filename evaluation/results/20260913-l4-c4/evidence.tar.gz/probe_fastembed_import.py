"""İçerik/adres kaydetmeden bağımlılık import'undaki soket yoklamasını ayırır."""
import json
import sys

events=[]

def audit(event, values):
    if event not in {'socket.connect','socket.connect_ex','socket.bind','socket.getaddrinfo'}:
        return
    address_kind='not-classified'
    if event=='socket.bind' and len(values)>1:
        value=values[1]
        if isinstance(value,tuple) and len(value)>=2:
            address_kind='ipv6-loopback-ephemeral' if value[:2]==('::1',0) else 'other-bind'
    stack=[]
    frame=sys._getframe(1)
    while frame and len(stack)<8:
        stack.append({'module':frame.f_globals.get('__name__','unknown'),'function':frame.f_code.co_name})
        frame=frame.f_back
    events.append({'event':event,'address_kind':address_kind,'stack':stack})
    raise OSError('L4_PROBE_NETWORK_BLOCKED')

sys.addaudithook(audit)
try:
    import fastembed
    status='imported'
except Exception:
    status='import-failed'
print(json.dumps({'status':status,'model_loaded':False,'events':events},indent=2))
