"""Owned L4 cluster only; persisted command receipts, no credential output."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
from urllib.parse import quote

ROOT = Path('/Users/muratates/code/dou-synapse-018-l4-retrieval-ops')
RUNTIME = Path('/Users/muratates/code/.dou-synapse-l4-runtime')
OUT = Path(__file__).resolve().parent
PG = Path('/opt/homebrew/opt/postgresql@16/bin')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def hashes():
    paths = [*ROOT.glob('apps/api/app/**/*.py'), *ROOT.glob('apps/api/tests/**/*.py'), *ROOT.glob('supabase/migrations/*.sql'), ROOT/'apps/api/uv.lock']
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

def main():
    name, db, *selection = sys.argv[1:]
    assert re.fullmatch(r'[a-z0-9-]+', name)
    assert re.fullmatch(r'dou_l4_[a-z0-9_]+', db)
    output = OUT/name
    output.mkdir(exist_ok=False)
    secret = (RUNTIME/'admin.pass').read_text().strip()
    env = {k:v for k,v in os.environ.items() if k in ('HOME', 'USER', 'TMPDIR', 'LANG', 'LC_ALL', 'PATH')}
    env.update(PGUSER='dou_l4_admin', PGPASSWORD=secret, PGHOST='127.0.0.1', PGPORT='55484', PG_BIN=str(PG))
    pin = json.loads((RUNTIME/'cluster-pin.json').read_text())
    verify = subprocess.run([str(PG/'psql'), '-XAt', '-d', 'postgres', '-c', "SELECT json_build_object('system_identifier',system_identifier::text,'data_directory',current_setting('data_directory'),'port',current_setting('port'),'server_address',host(inet_server_addr())) FROM pg_control_system()"], env=env, capture_output=True, text=True, check=True)
    actual = json.loads(verify.stdout)
    assert all(pin[k] == v for k,v in actual.items())
    env.update(TEST_DB_NAME=db, TEST_ADMIN_DSN=f'postgresql+psycopg://dou_l4_admin:{quote(secret,safe="")}@127.0.0.1:55484/{db}', TEST_APP_DSN=f'postgresql+psycopg://dou_app:dou_app_local@127.0.0.1:55484/{db}', TEST_WORKER_DSN=f'postgresql+psycopg://dou_worker:dou_worker_local@127.0.0.1:55484/{db}', GROQ_API_KEY='', GEMINI_API_KEY='', OPENAI_API_KEY='', UV_OFFLINE='1', UV_NO_SYNC='1', HF_HUB_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1', DO_NOT_TRACK='1')
    command=[str(ROOT/'apps/api/.venv/bin/python'), '-m', 'pytest', '-q', *selection]
    diagnostic = 'dou_lag_probe' in selection
    if diagnostic:
        env['PYTHONPATH']=str(OUT/'lag-probe')+os.pathsep+str(ROOT/'apps/api')
    receipt={'started_at':now(), 'command':command, 'database':db, 'isolated_cluster':actual, 'source_hashes_before':hashes(), 'real_provider_calls_authorized':False, 'status':'running'}
    (output/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
    with (output/'stdout.txt').open('x') as stdout, (output/'stderr.txt').open('x') as stderr:
        proc=subprocess.Popen(command, cwd=ROOT/'apps/api', env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        receipt['pid']=proc.pid
        (output/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
        try:
            code=proc.wait(timeout=60 if diagnostic else 2400)
        except BaseException:
            os.killpg(proc.pid,signal.SIGTERM)
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
            receipt.update(status='interrupted',finished_at=now(),exit_code=proc.returncode)
            (output/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
            raise
    # Logs from synthetic tests may contain fixture credentials; the private random
    # administrator password must never leave the local runtime, including errors.
    for log in ('stdout.txt','stderr.txt'):
        path=output/log
        content=path.read_text().replace(secret,'[PRIVATE_ADMIN_PASSWORD]').replace(quote(secret,safe=''),'[PRIVATE_ADMIN_PASSWORD]')
        path.write_text(content)
        receipt[log+'_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    receipt.update(status='passed' if code==0 else 'failed', exit_code=code, finished_at=now(), sources_unchanged=receipt['source_hashes_before']==hashes())
    (output/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='source_hashes_before'},indent=2))
    print((output/'stdout.txt').read_text()[-5000:])
    return code

if __name__=='__main__':
    sys.exit(main())
