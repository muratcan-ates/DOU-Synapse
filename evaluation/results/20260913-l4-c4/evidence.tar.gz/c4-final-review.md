# C4 son kaynak incelemesi — 2026-09-13

**Sonuç: belirtilen kapsamda yeni maddi kusur bulunmadı.** Bu bir salt okuma incelemesidir; test, gerçek model veya DB çalıştırılmadı. Ürün/kod değişikliği yapılmadı. Sonuç yalnız aşağıdaki kaynak damgalarına aittir; daha sonraki değişiklikler ayrıca değerlendirilmelidir.

| Dosya | İncelenen SHA-256 |
|---|---|
| `scripts/measure_embedding_rss.py` | `3b19c4ba3d5eff09155e1e5216e2b40d876da907558c45e84ab0e265bb016f9a` |
| `scripts/test_measure_embedding_rss.py` | `b1c09c193031f693ddb2ff1351575d7d186841d066e3de86a3dffba91f8863ca` |

## İncelenen maddi sözleşmeler

**Kaynak ve zaman sınırları.** `measure_embedding_rss.py:817–838` sonlu grup süresi, örnekleme aralığı, RSS bütçesi, paragraf sayısı ve profil/artefakt girdilerini sınırlar. `427–431` aynı gözlemdeki çocuk RSS toplamını kontrol eder; `313–325` RSS gözlem sürecinin kendi süresini 5 saniye ile sınırlar. `463–465` grup zaman sınırını, `372–397` sahip olunan çocukları terminate/kill/wait ile toplamayı uygular. Bütçe kernel bellek sınırı değildir; örnekler arasında ani tahsisleri önleyemez. Grup zaman sınırı da ön/son model hashing işlemlerini veya temizlik süresini kapsayan tüm-komut sert süre sınırı değildir. Rapor bunu grup süresi/örneklemeli RSS olarak sunuyor; genel sistem boş bellek garantisi vermiyor (`868–902`). Kaynak/model hashing'i parça parça yapılır (`223–237`). Bu kapsamın “tam servis kapasitesi” diye genişletilmemesi gerekir.

**Çıktı çakışması ve sonuç kaybı.** `1002–1015` hedefi model/çocuk çalışması başlamadan `open("x")` ile ayırır. Mevcut dosya veya olmayan üst dizin, önceki kanıtı ezmeden sabit hata ve çıkış 1 üretir. `1025–1033` write/close kaynaklı `OSError` için ölçüm nesnesini korur, `output_error=OUTPUT_WRITE_FAILED` ekler ve tam JSON'u stdout'a yazar. Test kaynağında bunlar `301–408` aralığında ayrı hata senaryolarıyla ele alınmış; bu inceleme o testlerin geçtiğini ayrıca iddia etmez. Elektrik kesintisi/parent SIGKILL veya stdout sink arızası için dayanıklı günlük garantisi yok; mevcut kapsam bunu vaat etmiyor.

**Yerel IPv6 sınıflandırması izin değildir.** `115–129` yalnız IPv6 stream socket ve tam `::1`, port 0, varsa flow/scope 0 biçimini ayrı sayar. `138–143` bu biçimde de koşulsuz `NETWORK_FORBIDDEN` yükseltir: bind gerçekleşmez. Diğer bind/connect/getaddrinfo girişimleri genel reddedilen-girişim sayacını artırır. `753,800` yalnız ayrı sınıflandırılmış ve yine engellenmiş bu yoklamayı genel sayacın dışında bırakır. `897–902` sıfır genel sayacın sıfır socket girişimi anlamına gelmediğini ve OS firewall garantisi olmadığını açıklar. Test kaynağı `640–747` biçim dışı adres/port/socket türlerini, gerçek engellenmiş bind'i ve urllib3 import davranışını kapsar. Sınıflandırmanın ağ erişimini açtığına dair bir yol görülmedi.

**Başarısız çoklu çocukta uydurma sıfır yok.** `558–563` yalnız doğrulanmış çocuk hatasının sayaçlarını alır. `602–613` rapor vermemiş roller için `null`, tüm roller bilinmiyorsa toplam için `null` kullanır. `539–556` başarılı tamamlama bildirimlerinde sayaç tipi/değeri ve kaynak özetlerini doğrular. Tek bir başarısız çocuğun 0/1 sayacı, kardeş çocuğun bilinmeyen sayacını sıfıra dönüştürmez. Hata ayrıntıları izin listeli kod/kategori/sayaç/özetle sınırlıdır (`150–215`); serbest exception mesajı rapora alınmaz. Test kaynağı `492–576` bu tekli/çoklu ayrımı içerir.

**İstenen profil ile tüm C4 tamamlanması ayrı.** `905–910` seçilmeyen profilleri `PROFILE_NOT_SELECTED` olarak kaydeder. `937–949` istenmiş fakat artefaktı olmayan qint8'i `not_run` içine alır ve `complete_requested_profiles=false` yapar. Yalnız qint8 istendiğinde qint8 başarılıysa bu bayrak doğru olarak `true` olabilir; query/ingest/combined yine seçilmemiştir. Bu, tüm C4'ün tamamlandığı iddiası değildir. `947–956` integrity kontrolünden önce alanı hesaplar; sonraki integrity arızasında üst `status=failed` olur. Kabul okuyan taraf sadece completion bayrağına bakmamalı. Normal başarılı akışta seçilmiş query/ingest/combined grupları bitmeden bayrak hesaplanmaz. Başarısız ilk grup kalan grupları çalıştırmaz ve üst durum başarısız kalır.

**qint8 başarısız girişimi kaybolmuyor.** `923–936` başlamış qint8'i `running` durumuna geçirir; `957–973` başarısız girişimi `failed/QINT8_SMOKE_FAILED` yapıp gözlem ve cleanup kaydını muhafaza eder. Artefakt mevcutken önceki grup hata verirse qint8 `PROFILE_NOT_STARTED` kalır. Test kaynağı `258–298` iki durumu ayırır.

## Teslimde korunacak kanıt sınırı

Bu kaynak incelemesi önceki kaynak sürümündeki gerçek qint8 sonucunu yeni sürümün çalıştırılmış sonucu hâline getirmez. Root'un bildirdiği eski qint8 başarı damgası, E5'nin önceki guard sürümündeki başarısızlığı ve yeni IPv6 guard mekanik testi kendi sürüm/koşu kayıtlarıyla ayrı sunulmalıdır. Yeni kaynakta gerçek E5 query/ingest/combined tamamlanmamışsa **C4 tamamlandı denmemeli**.

Aynı şekilde 100 ms sağlık kapısının önceki tam paket başarısızlığı bu betiğin değişmesi veya tanısal tek testin geçmesiyle kapanmaz. Tam API kabulündeki **ENGEL** korunur. Burada ek kapı, yeni bağımlılık veya kapsam dışı ürün değişikliği önerilmedi.
