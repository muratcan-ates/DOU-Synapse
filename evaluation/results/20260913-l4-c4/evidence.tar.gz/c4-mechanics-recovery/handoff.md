# C4 crash recovery handoff

Only the two assigned script files were changed. No Git, PR, environment, database, model, dependency, or aggregate operations were performed.

- Qint8 supplied artifact starts as `not-run / PROFILE_NOT_STARTED`. Starting the smoke switches it to running; attempted failure becomes `failed / QINT8_SMOKE_FAILED`, keeps the fixed error code, and reuses the failed-group observations and owned-child cleanup. Earlier profile failure keeps qint8 not-run and explicitly records it in `not_run`.
- An output path is exclusively reserved before `run()` can load a model or start a child. Existing files remain unchanged, and missing parent directories fail without starting measurement. Write or close failure returns nonzero while stdout retains the complete report plus `output_error: OUTPUT_WRITE_FAILED`.
- New negative tests cover qint8 failure and earlier failure, output collisions/missing parents, pre-execution reservation, and late write/close errors including child cleanup evidence and private-error redaction.

## Final verification

From `/Users/muratates/code/dou-synapse-018-l4-retrieval-ops`:

```
apps/api/.venv/bin/ruff check --no-cache --config apps/api/pyproject.toml scripts/measure_embedding_rss.py scripts/test_measure_embedding_rss.py
apps/api/.venv/bin/ruff format --check --no-cache --config apps/api/pyproject.toml scripts/measure_embedding_rss.py scripts/test_measure_embedding_rss.py
PYTHONDONTWRITEBYTECODE=1 UV_OFFLINE=1 UV_NO_SYNC=1 apps/api/.venv/bin/python -m pytest -q -p no:cacheprovider scripts/test_measure_embedding_rss.py
```

Ruff and format: pass. Mechanics: **37 passed in 10.71 seconds**, run 2026-09-13T14:34:21.920156Z to 14:34:33.727171Z, unchanged source hashes. Mechanics used local escalated execution because default sandbox blocks `ps` observation of owned children. It uses offline hashing, not real E5 or qint8 weights, and proves harness behavior only.

Durable logs: `recovery-project-style-results.json`, `recovery-project-style-01.log`, `recovery-project-style-02.log`, `recovery-mechanics-02-start.json`, `recovery-mechanics-02.log`, `recovery-mechanics-02-results.json` in this directory.

Prior failed attempts were preserved: initial Ruff cached write was blocked by sandbox; a no-config Ruff invocation inherited an unrelated ancestor configuration and reported rule mismatches; explicit API project config then passed. The first mechanics invocation (default sandbox) had 36 passed and 1 RSS_OBSERVER_FAILED, followed by the successful same-source escalated run.

## Frozen source SHA256

- `scripts/measure_embedding_rss.py`: `b9bb8bfd51d41b4916ca4bde513a44d6c04f19d2af6815709d31ab9b985cc6d5`
- `scripts/test_measure_embedding_rss.py`: `e9905f943ee64750e29cfb1e4410ca2efc54bc0fdcb2a6745e0c20f7bd5eff66`

No source edits were made after the passing mechanics run. Actual model memory runs and whole-project gates remain with the parent.
