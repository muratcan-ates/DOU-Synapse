"""Persist one repository gate without shell evaluation or credential forwarding."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root=Path('/Users/muratates/code/dou-synapse-018-l4-retrieval-ops')
name,relative,*command=sys.argv[1:]
assert re.fullmatch(r'[a-z0-9-]+',name)
cwd=(root/relative).resolve();assert cwd.is_relative_to(root)
out=Path(__file__).resolve().parent/name;out.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if k in ('HOME','USER','TMPDIR','LANG','LC_ALL')}
env.update(PATH='/Users/muratates/.bun/bin:/Users/muratates/.local/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin',UV_OFFLINE='1',UV_NO_SYNC='1',UV_CACHE_DIR='/Users/muratates/code/.dou-synapse-l4-runtime/uv-cache',MYPY_CACHE_DIR='/Users/muratates/code/.dou-synapse-l4-runtime/mypy-cache',GROQ_API_KEY='',OPENAI_API_KEY='',GEMINI_API_KEY='',NEXT_TELEMETRY_DISABLED='1',DO_NOT_TRACK='1')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
result={'command':command,'cwd':relative,'started_at':now(),'status':'running'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
with (out/'stdout.txt').open('x') as stdout,(out/'stderr.txt').open('x') as stderr:
    proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
    result['pid']=proc.pid
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    try:code=proc.wait(timeout=1800)
    except BaseException:
        proc.terminate()
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:proc.kill();proc.wait()
        result.update(status='interrupted',exit_code=proc.returncode,finished_at=now())
        (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        raise
for file in ('stdout.txt','stderr.txt'):result[file+'_sha256']=hashlib.sha256((out/file).read_bytes()).hexdigest()
result.update(status='passed' if code==0 else 'failed',exit_code=code,finished_at=now())
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
for file in ('stdout.txt','stderr.txt'):
    content=(out/file).read_text()
    try:payload=json.loads(content)
    except ValueError:print(content[-3000:]);continue
    if isinstance(payload,dict) and 'requested_profiles' in payload:
        print(json.dumps({k:payload.get(k) for k in ('status','error','requested_profiles','complete_requested_profiles','not_run')},indent=2))
        groups=payload.get('groups',[])+([payload['failed_group']] if 'failed_group' in payload else [])
        if payload.get('qint8',{}).get('measurement'):groups.append(payload['qint8']['measurement'])
        for group in groups:print(json.dumps({k:v for k,v in group.items() if k not in ('observations','source_manifest_digest')},indent=2))
    else:print(content[-3000:])
sys.exit(code)
