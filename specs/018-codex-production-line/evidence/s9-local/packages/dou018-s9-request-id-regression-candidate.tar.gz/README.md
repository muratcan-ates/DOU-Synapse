# S9 destek kimliği maskeleme regresyonu — dar aday

8 Eylül 2026. Repo düzenlenmedi. Test, import, DB, ağ, sunucu veya sağlayıcı çalıştırılmadı. Yalnız metin hazırlığı, standart AST parse ve SHA-256 hesaplandı. Bu paket çalışmış kabul kanıtı değildir.

Kaynak bulgu: `/private/tmp/dou018-s9-final-code-review.md`, F1. Bu raporun tarihsel dosya hashleri ve eski 80 gizlilik testi değiştirilmedi. Yeni ayrı dosyada iki sentetik kalıp × iki gerçek mekanizma = dört parametrik vaka hazırlanmıştır.

Üretim deltası `logging.py` içinde yalnız `context["request_id"] = redact(request_id)` satırıdır. Kimlik önce mevcut biçim filtresinden geçer, sonra mevcut bilinen anahtar/11 hane maskesine girer. Opaque kimliklerin daha geniş kişisel veri sınırı bu yama tarafından kapanmaz. Normal destek kimliği aynı kalır; hassas kalıp eşleşmesinde log maskelenir ve mevcut HTTP yanıt kimliği sözleşmesi korunur.

Testler gerçek JsonFormatter'ı filtresiz çağırır ve ayrı olarak gerçek paylaşılan `unhandled_error_handler` ile yapılandırılmış logging handler'ını kullanır. Ham stdout'ta kimlik yokluğu, tam beklenen maske, olay/tür tanısı kontrol edilir; ikinci mekanizmada stderr boş, genel500 ve yanıt kimliği aynı olmalıdır. Bu doğrudan handler deneyi gerçek HTTP dinleyicisi değildir. Testler mevcut maskeyi çağırarak beklenen sonucu türetmez; bağımsız sabit maskeleri bekler.

## Kök görev ölçüm protokolü

Aynı yeni dört oracle önce `baseline/logging.py` (manifest'teki eski SHA), sonra `files/apps/api/app/core/logging.py` ile ayrı kaynak bağları/çıktı dosyalarında yürütülmeli. `errors.py` her iki kolda aşağıdaki aynı repo SHA'sıdır; Settings/app.main/DB başlatılmamalı. Eski kolun beklenen dört hatası ilk ham-kimlik oracle'ından gelmeli; import/fixture/hash hatası geçerli kırmızı kontrol değildir. Yeni kolun dört geçişi ayrıca ölçülmeli. Hazırlanmış test sayısı gerçek çalışma sayısının yerine geçmez.

Kök görev yeni dosyayı kendi izole runner'ı veya test protokolüyle çalıştıracak. Bu paket runner başlatmadı ve önceki 1651 API geçişini düzeltilmiş kaynağa yeniden atfetmiyor. Yeni kaynak entegre edilirse dört negatifin yanında mevcut 80 gizlilik kontratı, eski request/storage günlük kontrolleri ve uygun son kabul kaynak bağı kök görevce yeniden doğrulanmalı.

`candidate.patch` mevcut entegre eski adaya göre tek üretim satırını ve ayrı test dosyasını ekler. Ana repo uygulanmadı. S10 kimlik politikası daha sonraki ayrı kapsamdır.
