"""Root için kaynak bağlı S9/S9B karşılaştırması; pytest burada hazırlanırken koşulmadı."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import socket
import sys
from pathlib import Path

ROOT = Path("/Users/muratates/code/dou-synapse-018-codex-production-line")
HERE = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=["baseline_s9", "candidate_s9b"], required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE / "manifest.json").read_text())
    for relative, expected in manifest["package_files"].items():
        assert hashlib.sha256((HERE / relative).read_bytes()).hexdigest() == expected, relative
    for absolute, expected in manifest["import_source_sha256"].items():
        assert hashlib.sha256(Path(absolute).read_bytes()).hexdigest() == expected, (
            "Kaynak değişti; root ayrı ölçüm manifestinde açık yeniden bağlama yapmalı."
        )
    original = Path(manifest["s9_manifest_path"])
    assert hashlib.sha256(original.read_bytes()).hexdigest() == manifest["s9_manifest_sha256"]
    selected = HERE / (
        "baseline/logging.py" if args.arm == "baseline_s9" else "files/apps/api/app/core/logging.py"
    )
    # Bu testler app.main, uygulama Settings veya sağlayıcıları yüklemez.
    os.environ.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / "apps/api"))
    import psycopg
    import pytest

    import app.core

    attempts = {"db": 0, "network": 0}

    def no_database(*args, **kwargs):
        attempts["db"] += 1
        raise AssertionError("Bu çalıştırıcı DB bağlantısı yapmaz.")

    def no_network(*args, **kwargs):
        attempts["network"] += 1
        raise AssertionError("Bu çalıştırıcı ağ bağlantısı yapmaz.")

    psycopg.Connection.connect = no_database
    psycopg.AsyncConnection.connect = no_database
    socket.create_connection = no_network
    socket.socket.connect = no_network
    socket.socket.connect_ex = no_network
    name = "app.core.logging"
    spec = importlib.util.spec_from_file_location(name, selected)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    app.core.logging = module
    spec.loader.exec_module(module)
    result = pytest.main(
        [
            "--noconftest",
            "-p",
            "no:cacheprovider",
            "-p",
            "pytest_asyncio.plugin",
            "-o",
            "asyncio_mode=auto",
            "-o",
            "asyncio_default_fixture_loop_scope=function",
            "-q",
            str(HERE / "files/apps/api/tests/test_lifespan_log_privacy.py"),
        ]
    )
    print(
        json.dumps(
            {
                "version": "s9b-no-db-01",
                "arm": args.arm,
                "pytest_exit": int(result),
                "selected_logging_sha256": hashlib.sha256(selected.read_bytes()).hexdigest(),
                "manifest_sha256": hashlib.sha256(
                    (HERE / "manifest.json").read_bytes()
                ).hexdigest(),
                "attempts": attempts,
            }
        )
    )
    assert attempts == {"db": 0, "network": 0}
    return int(result)


if __name__ == "__main__":
    raise SystemExit(main())
