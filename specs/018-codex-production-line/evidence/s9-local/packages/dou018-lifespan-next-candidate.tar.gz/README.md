# S9B: Uvicorn düz hata mesajı sınırı — hazırlık, henüz çalışma kanıtı değil

Bu paket donmuş S9'un üzerine dar bir ek adaydır. Repo, S9 paketi ve eski kanıtlar değiştirilmedi. Yalnız `app/core/logging.py` üretim adayı var. `s9-to-s9b.patch` S9'a göre deltadır; mevcut repo üzerine tek başına uygulanacak bağımsız bir yama değildir. İki seçilebilir kol aynı yeni test oracle'larını kullanır: `baseline_s9`, `candidate_s9b`. S9'un hatayı biçimlendirmeden özetleyen exc_info dalı korunur; yerel `context` değişkeni tip çakışmasını gidermek için `exception_context` olarak adlandırılır, davranış aynı kalır.

## Somut kaynak yolu ve etki

Kurulu Uvicorn ve Starlette kaynakları `manifest.json` içinde dosya hashleriyle bağlanır. `starlette/routing.py:646–653` yaşam döngüsündeki hatayı `traceback.format_exc()` ile metne çevirip `lifespan.startup.failed` veya `lifespan.shutdown.failed` mesajına ekler. `uvicorn/lifespan/on.py:121,134` bu metni `logger.error(message["message"])` ile, **exc_info olmadan**, yazar. Bu yüzden S9'un exc_info minimizasyonu bu ayrı yolu kapatmaz. Metin hata mesajını, zinciri, notları ve kaynak satırını içerebilir. Etki koşulu, yaşam döngüsü hatasının böyle bir özel değer içermesi ve proje günlük yapılandırmasının etkin olmasıdır; uzak bir öğrencinin bu hatayı bağımsız tetikleyebildiği kanıtlanmadı.

Ardından Uvicorn aynı dosya 59/73'te sabit başlangıç/kapanış başarısızlığı mesajını üretir. İlk keyfi mesajı yorumlamadan `uvicorn_error` olayına çevirmek ve ikinci sabit olaydan fazı korumak yeterlidir. Özel traceback regex'i, hata metni parçalama veya içeriği tahmin etme yoktur.

## Aday sözleşmesi

Yalnız tam `uvicorn.error` logger'ının ERROR/CRITICAL ve exc_info olmayan kayıtları:

- Serbest `msg`, `args`, `context`, ekstra alanlar, önceden biçimlendirilmiş `exc_text`, `stack_info` ve kaynak dosya adı yayımlanmaz; `str()`/`getMessage()` çağrılmaz. Formatter tek başına da aynı sınırı uygular; filtre önce nesneyi biçimlendirmez.
- Sabit startup/shutdown, HTTP/WS sözleşme ve app-factory hata şablonları sabit mesaj ve `error_code` ile ayırt edilir. Keyfi argümanları alınmaz.
- Graceful shutdown aşımında yalnız tam tamsayı 0..1.000.000 `task_count` korunur. Diğer tür/taşan değerler atılır; hata olayı korunur.
- Uvicorn'un `server.py:181` OSError kayıt yolu yalnız yerleşik OSError türlerinden, `errno.errorcode` içinde bilinen tam tamsayı errno ve sabit sembolünü alır. Mesaj, filename, strerror, URL, adres, özel alt sınıf özellikleri alınmaz. Böylece örneğin EADDRINUSE/EACCES tanısı kalır.
- Bilinmeyen/preformatted hata sabit `uvicorn_error` olur. Uvicorn sürümü yeni şablon eklerse özel metin otomatik izinli olmaz; yeni tanı kaydı ayrıca incelenir.
- Normal INFO başlangıç/kapanış ve mevcut WARNING protokol mesajları değişmez. `uvicorn.error` kapanmaz, kök JSON handler'a yayılır. S9 exc_info özeti önceliklidir ve korunur.

`uvicorn.Config` logger kurulumunu yapar; gerçek app lifespan içindeki `configure_logging` bundan sonra root JSON handler'ını kurup `uvicorn` ve `uvicorn.error` handler'larını temizler/propagation açar. Normal tek süreçte `Server.startup` önce lifespan'i başlatır, sonra bağlanır (`server.py:108–183`); bu yüzden o bağlanma hatası etkin formatter'a ulaşır. Gerçek konfigürasyon nesnesi ile handler zinciri testte denetlenir. Gerçek süreç ve ham stdout/stderr doğrulaması root'un ayrı deneyi olacaktır.

## Hazırlanan 35 test vakası

`test_lifespan_log_privacy.py` mevcut logger çıkışını JSON olarak okur; yalnız yardımcı fonksiyonun sonucunu sınamaz. Gerçek Starlette yaşam döngüsü + `LifespanOn.startup/shutdown` başlangıç/kapanış hatası ve başarı durumunu kullanır (sunucu/soket yok). Aynı canary oracle'ı donmuş S9 kolunda kırmızı beklenir. Doğrudan gerçek `LifespanOn.send` ayrıca traceback'e benzemeyen üç mesajın her iki failed olayını sınar.

Diğer vakalar altı bilinen protokol/üretici şablonunu, sekiz sınır task-count girdisini, beş errno girdisini, ERROR/CRITICAL ve diğer alanlardan sızıntıyı, biçimlendirilmesi yasak mesaj/argüman nesnelerini, filtresiz formatter'ı, gerçek Uvicorn handler kurulumunu/başarı/protokol mesajlarını ve S9 exc_info yolunu denetler. Tamamı sentetik değerlerdir. İstemciye HTTP hata cevabı, auth, endpoint veya DB davranışı bu yamada değişmez.

**Henüz pytest veya ASGI yaşam döngüsü çalıştırılmadı.** Aday hazırlığında yalnız Ruff, biçim kontrolü, AST/compile (import/execute olmadan) ve tek üretim modülü mypy yapıldı. Gerçek süreç, DB, sağlayıcı, model, ağ veya sunucu çalıştırılmadı. Bu sınırları root ölçüm raporu güncelleyebilir; önceki hazırlık iddiası geriye dönük başarı iddiasına çevrilmemeli.

## Root için DB'siz karşılaştırma

Aşağıdaki iki çağrı ayrı süreç ve ayrı ham log/receipt olarak saklanmalı. `baseline_s9` için exit!=0 beklenir; başarısızlıklar canary oracle'ı veya beklenen sabit şema karşılaştırması olmalı, kurulum/import hatası kabul edilmez. Test eşiği/oracle değiştirilmez. İki kol için `attempts.db=0`, `attempts.network=0` zorunludur. Runner dosyaların/package/framework hashlerini doğrular; S9'un donmuş manifestinin hashini de kontrol eder. Kaynak değişimi olursa eski paketi oynatmak yerine root açık bir yeni koşu bağlama manifesti üretmelidir.

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-lifespan-next-candidate/run_no_db_tests.py --arm baseline_s9
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-lifespan-next-candidate/run_no_db_tests.py --arm candidate_s9b
```

Runner `--noconftest` ve yalnız pytest-asyncio ile çalışır; normal DB fixture'ı yüklenmez. Uygulama `main`, Settings, LLM veya embedding sağlayıcısı yüklenmez. Psycopg ve socket connect çağrıları sayılan hata ile engellenir. Bu bir sandbox veya bütün üçüncü parti I/O biçimlerinin evrensel engeli değildir; bu testlerin görülen import/çağrı sınırı için ek reddetme kontrolüdür.

## Root gerçek Uvicorn kabul planı

S9 ve S9B aynı sabit kaynak bağlı uygulama/lifecycle adaptöründe, ayrı subprocess/sentetik özel dizinde yürütülmeli. API gerçek lifespan yapılandırması kullanılır; ek canary yalnız kontrollü startup/shutdown aşamasında fırlatılır, canlı veri veya DB gerekmez. Root mevcut sinyal değiştirmeyen normal kapanış/proxy-off/no-DB protokolünü koruyabilir.

1. Başarılı yaşam döngüsü: gerçek startup ve shutdown INFO kayıtları, normal dönüş/çıkış ve güvenli app.request kaydı korunur.
2. Yapılandırma çalıştıktan sonra startup canary hatası: S9 ham logda canary + sabit startup-failed olayı; S9B ham stdout **ve stderr** hiçbir canary içermez, `uvicorn_error` ve `application_startup_failed` olayları vardır; başarısız başlangıç çıkış durumu değişmez.
3. Shutdown canary hatası: aynı karşılaştırma `application_shutdown_failed` için; normal Uvicorn kapanış sinyali/çıkış davranışı korunur.
4. Bağlanma hatası: parent yalnız numeric loopback'te kendi tuttuğu private portla EADDRINUSE oluşturur; yeni JSON'da errno/sembol vardır, hata içeriği/adres/özel metin yoktur. Önceden kullanılan bir servis portu seçilmez.
5. İsteğe bağlı gerçek ASGI yanlış dönüş sözleşmesi ve invalid-HTTP WARNING: hata kanalı kapanmadan sabit tanı ve normal protokol uyarısı korunur. Baseline ve aday aynı HTTP sonuçlarını vermeli.

S9 generic500/exception-chain gerçek süreç ölçümleri bu ekle birlikte yeniden bağlanmalı; S9B tek başına tüm API salım kabulü değildir. Tam kaynak ve framework hashleri, PID, ham log hashleri, guard sayaçları ve beklenen/gerçek çıkışlar rapora bağlanmalı.

## Kalan sınırlar

Bu yalnız proje `configure_logging` sonrasındaki kontrollü logger zinciridir. Config/app import veya supervisor bind hatası konfigürasyondan önce olabilir; reload/multiprocess parent'ın app lifespan çalıştırmaması, sonradan eklenen handler, doğrudan stdout/stderr, hosting/proxy kayıtları bu adayla kapanmış sayılmaz. INFO/WARNING serbest metinleri, diğer exc_info olmayan logger'lar ve mevcut istemci kontrollü request_id sınırı ayrıca açıktır. Bilinmeyen hatalarda ham detay yerine sabit olay kalması bilinçli tanı ödünleşimidir. Kaynak sürümü yükselince bilinen şablon envanteri ve gerçek süreç kabulü yeniden gözden geçirilmeli. Genel anonimlik, kusursuz redaction veya KVKK/GDPR hukuki uygunluk iddiası yoktur.
