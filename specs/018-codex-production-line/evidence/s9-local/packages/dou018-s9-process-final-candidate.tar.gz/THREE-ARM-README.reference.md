# S9 + S9B — kaynak bağlı gerçek Uvicorn süreç deneyi hazırlığı

Bu paket **henüz çalıştırılmadı**. Repo, donmuş S9/S9B paketleri ve önceki S8 kanıtları değiştirilmedi. Üç kol için aynı mevcut uygulama Python kaynakları ve static dosyaları geçici pakete byte olarak kopyalandı; yalnız `app/core/errors.py` ile `app/core/logging.py` seçimi değişir. Kaynaklar `manifest.json` ile sabittir. `c45e0e7` yalnız baseline'ın bu iki dosyasının gerçek Git kaynağını belirtir; bütün runtime'ın eski commit olduğu iddia edilmez. Diğer kaynaklar hazırlık anındaki OPS çalışma ağacıyla bağlanır.

Kontrollü sentetik hata indüksiyonu kullanılır. Ağ katmanı bir ASGITransport simülasyonu değildir: root çalıştırınca gerçek ayrı Uvicorn süreçleri, gerçek numeric loopback TCP, gerçek h11/httptools protokolleri, gerçek FastAPI middleware/error handler ve gerçek Starlette/Uvicorn lifespan mesajları yürür. Bu deney normal çalışan çıktı hedefiyle günlük kanallarını ölçer; StreamHandler/handleError arızası S9C'nin ayrı test konusudur. S9B'nin bu kanaldaki açık kusuru gizlenmez; son kabul S9C ile yapılmalıdır.

## Sabit kollar ve beklenen karşıtlık

| Kol | errors | logging | HTTP body/cause/note/URL günlükte | Lifespan günlükte |
| --- | --- | --- | --- | --- |
| current | gerçek c45 kaynak, mevcutla byte eşit | gerçek c45 kaynak, mevcutla byte eşit | dört canary hem app.error hem uvicorn.error içinde olmalı | dört canary ilk serbest ERROR içinde olmalı |
| s9 | donmuş S9 | donmuş S9 | canary yok; iki içeriksiz exception özeti | dört canary ilk serbest ERROR içinde olmalı |
| s9b | donmuş S9 | donmuş S9B | canary yok; iki içeriksiz exception özeti | canary yok; sabit unknown-error + startup/shutdown-failed |

S9B'deki yerel `exception_context` adı düzeltmesi davranış dışıdır; farklı logging hashinde açıkça kalır. Hata kaydı sayısı her senaryoda tam ikidir. Beklenen baseline sızıntısı deneyin pozitif kontrolüdür; baseline'a da sızıntı yokmuş gibi bir kabul beklentisi verilmez. Beklenmeyen kurulum/import hatası başarı sayılmaz.

## 12 süreç / 15 gerçek HTTP yanıtı

Her kol sırayla dört senaryo kullanır:

1. `http-h11`: sağlık 200, ardından JSON gövdesindeki canary ile `POST /__s9_probe__/error` → genel 500; normal startup ve shutdown.
2. `http-httptools`: aynı iki istek ve oracle, gerçek `HttpToolsProtocol`.
3. `startup-failure`: gerçek uygulamanın `configure_logging` yaptığı lifespan'e girildikten sonra sentetik canary hatası; Uvicorn startup.failed mesajı ve sabit failure olayı; mevcut Uvicorn çıkışı 3. HTTP gönderilmez.
4. `shutdown-failure`: gerçek startup ve sağlık 200; parent kapanış borusuna bayt yazdıktan sonra gerçek lifespan cleanup tamamlanır, ardından canary hatası; shutdown.failed mesajı ve sabit failure olayı; bu Uvicorn yolunun mevcut çıkışı 0 korunur, bu tek başına başarılı shutdown anlamına gelmez.

Hata rotası yalnız çocuk sürecin belleğine eklenir. Gövde önce gerçek `Request.json()` ile okunur, sonra bilinen sentetik fixture ile birebir eşleşmesi doğrulanır. Hata `RuntimeError` + `ValueError` cause + note taşır; hiçbir uygulama veya Uvicorn hata logger'ı test adaptöründen doğrudan çağrılmaz. HTTP 500 gerçek generic handler'ı ve Starlette'in yeniden yükselttiği hatadan Uvicorn'un ikinci kanalı üretir. Yaşam döngüsü adaptörü gerçek `app.router.lifespan_context` etrafına sarılır, doğrudan `message["message"]` logu simüle edilmez.

HTTP yanıtı üç kol arasında byte hashleriyle aynı olmalı. 500 gövdesi yalnız mevcut sabit Türkçe `internal_error` zarfını ve önceden belirlenmiş destek kimliğini taşır; özel metin yoktur. Mevcut generic500 akışında `X-Request-ID` yanıt başlığı oluşmaması değiştirilmez ve oracle bunu açıkça korur. Sağlık yanıtında bu başlık ve JSON alanları doğrulanır. `API_VERSION=0.1.0` üç kolda sabitlenir. Hata akışının mevcut `app.request` tamamlanma kaydı eksikliği kapandı denmez; yalnız başarılı health kaydı beklenir.

S9/S9B HTTP exception özetlerinde yalnız izinli şema, RuntimeError ve gerçek uygulama-köküne göreli kaynak frame'leri doğrulanır. Frame kaynağı staged uygulama içinde mevcut bir Python dosyası olmalı, function/satır aralığı dosyaya uymalı; mutlak dosya yolu veya serbest kaynak satırı exception özetine alınmaz. Ham source binding sidecar'ları ise bilinçli olarak teknik kaynak yollarını/PID/hashleri içerir; bunlar öğrenci metni canary'leri değildir.

## Süreç ve hedef sahipliği

Parent sıfırdan AF_INET socket açıp yalnız `127.0.0.1:0` ile ephemeral listener ayırır ve `pass_fds` ile kendi çocuğuna devreder. Çocuk `server.started` sonrasında PID/adres içeren atomik `ready.json` yazar. Parent bu kimliğin kendi Popen PID'si/portuyla eşitliğini doğrulamadan HTTP göndermez. `http.client` proxy keşfi/redirect izlemesi yapmaz; adres numeric ve sabittir.

Normal kapanış özel `os.pipe` üzerinden tek `S` baytıyla istenir; control thread yalnız `server.should_exit=True` yapar. Uvicorn sinyal işleyicisi değiştirilmez. Startup failure için çocuk doğal SystemExit 3'ü kaydeder ve geri döndürür. Thread bitişi ve boru sahipliği receipt'te doğrulanır. Başlangıç 25 saniye, HTTP 5 saniye, kapanış 12 saniye; timeout/istisnada yalnız kaydedilmiş Popen çocuğu öldürülüp beklenir, bu yol başarı sayılmaz. Genel process arama, port öldürme, başka sürece sinyal veya DB cleanup yoktur. Unix `pass_fds`/pipe kullanılır; Windows taşınabilirliği iddia edilmez.

Çıktı yalnız `/private/tmp/dou018-evidence/s9-process-<benzersiz-ad>` altında yeni dizin olabilir; mevcut/symlink hedefe yazılmaz. Alt dosyalar ve raporlar yeni oluşturulur. `umask 077`, özel boş regular `.pgpass` dosyası kullanılır. Her çocuk için stdout/stderr ayrı ham dosyalar; dosya başına 1 MiB üst sınır denetlenir. Saklanan canary'ler tümü yapaydır. Klasör otomatik silinmez.

## DB/model/ağ sınırı

Ortam izinli listeyle sıfırdan kurulur; ambient PG service/hostaddr/proxy veya sır taşınmaz. DB URL'leri yalnız sentetik port9 adresidir. Gerçek psycopg sync/async/connect yolları hata veren sayaçla engellenir; localhost dahil outbound socket/connect/DNS çağrıları da çocukta engellenir. Parent yalnız kendi listener'ına bağlanır. Warmup kapalı, sağlayıcı fake/hashing, anahtarlar boş, HF offline; gerçek LLM ve embedding factory/metotları ayrıca sayaçla reddedilir. Her receipt için database/outbound_socket/embedding/llm sayaçlarının tümü 0 olmalıdır. Bu provider/model kalite veya DB davranış testi değildir. Guard'lar bu bilinen Python çağrı yollarını kapsar; bütün olası native I/O için işletim sistemi sandbox garantisi değildir.

## Root komutu ve sonuç

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-s9-process-candidate/run_processes.py --output /private/tmp/dou018-evidence/s9-process-three-arm-01
```

Yeni çıktı adı kullanılır. Parent her süreç öncesi/sonunda kaynakları, framework/native parser dosyalarını ve donmuş S9/S9B manifestlerini doğrular. Çocuk yüklediği üç modülün gerçek `__file__`/hashini, seçili gerçek transport sınıfını ve sürümleri yazar; ana uygulamanın imported configure_logging/error handler callable kimlikleri ayrıca doğrulanır. Sonuç `result.json`; her süreç `binding.json`, `configured.json`, `ready.json` (startup failure hariç), `receipt.json`, `stdout.log`, `stderr.log`, başarılıysa `audit.json` üretir. Son rapor PID, sayaç, gerçek çıkış, süre, yanıt ve ham log hashlerini bağlar. Hata olursa ham dosyalar korunur; son rapor aktif senaryoyu belirtir. İstisna açıklaması rapora serbestçe yazılmaz.

## S9C için ayrı dördüncü kol ekleme protokolü

Bu **donmuş üç kollu paketi değiştirmeyin**. Yeni ad altında byte kopyasını oluşturun, `arms/s9c` uygulama ağacını aynı paylaşılan kaynaklardan kopyalayın; errors S9, logging son donmuş S9C olur. Yeni manifest `arm_order` değerini yalnız `current,s9,s9b,s9c` sırasına genişletebilir. Önceki üç kolun profil beklentileri sabit kodda kalır; S9C, S9B ile aynı normal-sink minimizasyon sözleşmesini sağlamalıdır. Yeni manifestte `s9c_extension` şunları içerir:

- `prior_three_arm_manifest_sha256`: bu paketin donmuş manifesti;
- `logging_source_manifest_path` ve `logging_source_manifest_sha256`: root'un seçtiği donmuş S9C kaynak manifesti;
- okunabilir provenance için errors/logging kaynağı ve SHA eşleştirmesi.

`package_files` yeni kopya dosyalarıyla ve kaynak seçimleriyle tekrar hesaplanır; yeni manifestin hashini gerçek koşuya başlamadan kaydedin. Çalıştırıcı üç ya da dört sabit sıradan başka seçimi kabul etmez. Dördüncü kol 16 süreç/20 HTTP yanıtı olur. Eski üç kollu ölçüm veya olumsuz kayıtlar yeniden yazılmaz. Bu eklenti sadece normal-sink socket kabulüdür; S9C log hedefi/handleError arıza testleri ayrıca yapılır.

## Kanıt sınırı

Bu paket hazırlanırken yalnız statik kaynak okuma, Ruff/format ve importsuz compile/AST kontrolü yapılmıştır. Pytest, DB, gerçek model, ağ veya sunucu çalıştırılmamıştır. Root gerçek sonuçları gelmeden PASS iddiası yoktur. Yapılandırma öncesi Uvicorn/import/supervisor günlükleri, yeniden yapılandırılan handler'lar, diğer serbest INFO/WARNING mesajları, doğrudan stdout/stderr, hosting/proxy ve istemci kontrollü request_id sınırı hâlâ açıktır. Normal sink çalışması log hedefinin bozulduğu durumu kanıtlamaz. Genel anonimlik veya KVKK/GDPR hukuki uygunluk sertifikası değildir.
