# S9/S9B/S9C — dört kollu gerçek süreç deneyi hazırlığı

Bu ayrı paket **hazırlandı, henüz çalıştırılmadı**. Önceki üç kollu paket `/private/tmp/dou018-s9-process-candidate` ve donmuş S9, S9B, S9C kaynakları değişmedi. Üç kollu ölçümün daha önce çalıştırıldığı iddia edilmez. Dört kollu paket, kökün sıralı çalıştıracağı 16 gerçek Uvicorn süreci ve 20 HTTP yanıtı için hazırlanmıştır.

## Açık kaynak bağı

- Üç kollu ana manifest: `b83dcde2a99d2a1544a97cd85a66e92c12ef6974c4741fd34501b63861f42154`; byte kopyası `three-arm-manifest.reference.json`.
- Önceki üç kolun bütün app/static dosyaları byte eşittir. `common.py`, `child.py`, `run_processes.py` yardımcıları da özgün paketle byte eşittir; oracle veya süreç davranışı değiştirilmedi.
- S9C errors kaynağı donmuş S9: `82d90cf7f1501e4af51c27f1252a425540224a6e2407883fb77f4ae88499b72f`.
- S9C logging kaynağı `/private/tmp/dou018-log-sink-next-candidate/files/apps/api/app/core/logging.py`: `040ae8a026022f544d2e731ab202ca678f32c0a8326d9b9b552663277658517f`.
- S9C kaynak manifesti: `b1c4c265e5ca8981602b44b47ac5c6caee7a81acb4dc16fbc979190808e8e55a`.
- Hazırlık anında OPS `a40a689` ucundaki seçilen 123 runtime dosyasının tamamı eski manifestteki hashlerle hâlâ eşittir. Test dosyalarındaki sarmalama değişiklikleri bu runtime snapshot'ına alınmaz. `c45e0e7` yalnız current errors/logging dosyalarının gerçek Git tabanıdır; tüm runtime için eski commit iddiası değildir.
- Yeni `manifest.json`, özgün manifest hashini ve S9C manifest/hash/yol eşleştirmesini `s9c_extension` içinde taşır; aynı 408 framework/native parser kaynak dosyasını sabit tutar. Önceki adaylar ve özgün paket manifesti runtime girişinde tekrar doğrulanır.

## Dört kolun sabit beklentileri

| Kol | HTTP 500 günlük kanalları | Lifespan hata kanalı |
| --- | --- | --- |
| current | Sentetik body/cause/note/URL hem app.error hem uvicorn.error içinde görünmeli; bu eski sızıntı kontrolüdür. | Aynı dört canary ilk serbest ERROR içinde görünmeli. |
| s9 | İki içeriksiz exception özeti; canary yok. | Canary hâlâ görünmeli; S9'un kapsamadığı ayrı yol korunur. |
| s9b | İki içeriksiz exception özeti; canary yok. | Sabit unknown-error + startup/shutdown-failed, canary yok. |
| s9c | Aynı normal-sink HTTP sözleşmesi. | Aynı normal-sink lifespan sözleşmesi. |

Her kolda h11 HTTP ve httptools HTTP senaryosu (sağlık 200 + sentetik gövdeden genel 500), h11 startup-failure (HTTP yok) ve h11 shutdown-failure (sağlık 200) sıralıdır. Hata rotası gerçek `Request.json()` → gerçek FastAPI generic handler → gerçek Starlette re-raise → gerçek Uvicorn ikinci hata kaydını kullanır. Lifespan adaptörü gerçek uygulama yaşam döngüsünün etrafında kontrollü hata üretir; logger'a doğrudan hata mesajı göndermez. Bu **sentetik hata indüksiyonudur**, gerçek bir uzak saldırı veya provider arızası keşfi iddiası değildir. Soket/transport katmanı gerçek süreç deneyi olacaktır; ASGITransport simülasyonu değildir.

HTTP gövde hashleri dört kol arasında aynı olmalı. Genel 500 zarfı ve destek kimliği, health gövdesi/başlığı, mevcut 500 yanıtındaki X-Request-ID başlığı yokluğu, kaynak frame metadata sınırı ve iki hata kaydı sayısı korunur. API p95, retrieval veya model kalite iddiası bu deneyden üretilmez.

## Root çalıştırması

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-s9-process-four-arm-candidate/run_processes.py --output /private/tmp/dou018-evidence/s9-process-four-arm-01
```

Çıktı adı yeni ve benzersiz olmalı; önceki klasöre yazılmaz. Özgün helper'ın `HERE` değeri yeni paket konumundan çözülür; dört kolun bütün dosyaları bu paketten yüklenir. `arm_order=current,s9,s9b,s9c` dışında seçim yoktur. Çalıştırıcı her seferinde kendi `127.0.0.1:0` listener'ını açar, yalnız kendi Popen çocuğuna `pass_fds` ile verir. PID/port/ready eşleşmesinden sonra HTTP gönderir. Kapanış özel boruyla, sinyal handler değiştirilmeden istenir; timeout temizliği yalnız o çocuğa uygulanır. Normal hata yanıtları ve Uvicorn startup failure 3/shutdown failure 0 davranışı aynı kalır; çıkış0 tek başına başarılı shutdown sayılmaz.

DB, outbound socket/DNS, embedding ve LLM çağrıları çocukta sayılan hatayla engellenir; dört sayaç da 0 olmalıdır. Ortam sıfırdan kurulur, ambient PG/proxy/sırlar alınmaz, özel boş regular passfile kullanılır. Isıtma kapalı, fake/hashing, anahtarlar boş, HF offline. Parent yalnız kendi numeric listener'ına bağlanır. Bu, bütün olası native I/O için OS sandbox garantisi değildir.

Her senaryo ham `stdout.log` ve `stderr.log`, kaynak/sürüm/protokol/PID `binding.json`, yapılandırma `configured.json`, kapanış/sayaç `receipt.json` ve başarılı oracle için `audit.json` üretir. Root raporu `result.json`; bütün kaynak, yanıt ve log hashleri oraya bağlıdır. Kaynak veya davranış farklıysa FAIL olur; eski artefaktlar yeniden yazılmaz.

## S9C kabul sınırı

Bu süreç deneyi **normal çalışan çıktı hedefini** kullanır. S9C'nin formatter/write/flush/handleError arızası karşısındaki davranışı ve ham record/trace sızmaması ayrı adversarial testlerde doğrulanmalıdır. Normal sink'te PASS almak o kusurun kapanma kanıtı değildir. S9/S9B'nin bu ayrı arıza yolu hakkındaki olumsuz bulgusu silinmez.

Yapılandırma öncesi Uvicorn/import/supervisor kayıtları, sonradan eklenen handler'lar, serbest INFO/WARNING, doğrudan stdout/stderr, hosting/proxy ve mevcut istemci kontrollü request_id sınırı açık kalır. Teknik sidecar'lardaki kaynak yolları/PID/hashler özel öğrenci metni canary'lerinden ayrı operasyon metadata'sıdır; bütün stdout anonim denmez. KVKK/GDPR hukuki uygunluk sertifikası değildir.

Hazırlıkta sadece kaynak/hash karşılaştırması ve importsuz compile yapıldı. Yardımcılar değişmediği için üç kollu statik Ruff/format sonucu geçerlidir; yeni dosya göçü, pytest, DB, model, ağ veya sunucu çalıştırılmadı. Ayrıntılı ilk üç kollu tasarım bağlamı `THREE-ARM-README.reference.md` içinde byte eşit tarihsel referans olarak tutulur; oradaki üç kol/12 süreç sayısı yeni paketin çalıştırma sayısı değildir.
