"""Gerçek Uvicorn çocuğu; yalnız parent'ın devrettiği listener ve kapanış borusu.

Bu dosya hazırlık sırasında çalıştırılmadı. Hata rotası ve yaşam döngüsü adaptörü
yalnız bu test sürecinin belleğine eklenir; üretim kaynakları değiştirilmez.
"""

from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import json
import logging
import os
import select
import socket
import sys
import threading
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from common import ARMS, HERE, digest, require, verify_sources, write_json


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=ARMS, required=True)
    parser.add_argument(
        "--mode", choices=("http", "startup_failure", "shutdown_failure"), required=True
    )
    parser.add_argument("--protocol", choices=("h11", "httptools"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--socket-fd", type=int, required=True)
    parser.add_argument("--control-fd", type=int, required=True)
    args = parser.parse_args()
    require(args.output == args.output.resolve(), "CHILD_OUTPUT_SYMLINK")
    require(
        args.output.parent.parent == Path("/private/tmp/dou018-evidence"), "CHILD_OUTPUT_PARENT"
    )
    require(args.output.parent.name.startswith("s9-process-"), "CHILD_OUTPUT_PREFIX")
    manifest = verify_sources()
    require(args.arm in manifest["arm_order"], "ARM_NOT_IN_MANIFEST")
    stage = HERE / "arms" / args.arm
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(stage))
    counters = {"database": 0, "outbound_socket": 0, "embedding": 0, "llm": 0}

    def forbidden(kind: str):
        def denied(*_args: Any, **_kwargs: Any) -> Any:
            counters[kind] += 1
            raise RuntimeError("S9_PROCESS_DEPENDENCY_FORBIDDEN")

        return denied

    import psycopg

    psycopg.connect = forbidden("database")
    psycopg.Connection.connect = forbidden("database")
    psycopg.AsyncConnection.connect = forbidden("database")
    socket.create_connection = forbidden("outbound_socket")
    socket.socket.connect = forbidden("outbound_socket")
    socket.socket.connect_ex = forbidden("outbound_socket")
    socket.getaddrinfo = forbidden("outbound_socket")

    from app.modules.generation import fake, llm
    from app.modules.ingestion import embedding

    llm.build_llm_client = forbidden("llm")
    llm.LiteLlmClient.complete = forbidden("llm")
    fake.FakeLlmClient.complete = forbidden("llm")
    embedding.get_embedding_provider = forbidden("embedding")
    for provider in (embedding.HashingEmbeddingProvider, embedding.FastEmbedProvider):
        provider.embed_query = forbidden("embedding")
        provider.embed_documents = forbidden("embedding")

    import uvicorn
    from fastapi import Request

    config = uvicorn.Config(
        "app.main:app",
        host="127.0.0.1",
        port=0,
        loop="asyncio",
        http=args.protocol,
        ws="none",
        lifespan="on",
        interface="asgi3",
        access_log=True,
        log_level="info",
        proxy_headers=False,
        timeout_graceful_shutdown=5,
    )
    config.load()
    main_module = importlib.import_module("app.main")
    app_logging = importlib.import_module("app.core.logging")
    app_errors = importlib.import_module("app.core.errors")
    require(config.loaded_app is main_module.app, "LOADED_APP_IDENTITY")
    expected_protocol = {
        "h11": "uvicorn.protocols.http.h11_impl.H11Protocol",
        "httptools": "uvicorn.protocols.http.httptools_impl.HttpToolsProtocol",
    }[args.protocol]
    actual_protocol = (
        config.http_protocol_class.__module__ + "." + config.http_protocol_class.__name__
    )
    require(actual_protocol == expected_protocol, "PROTOCOL_CLASS_MISMATCH")
    loaded = {}
    for module_name in ("app.main", "app.core.errors", "app.core.logging"):
        module = importlib.import_module(module_name)
        path = Path(module.__file__).resolve()
        require(path.is_relative_to(stage), "MODULE_OUTSIDE_ARM")
        require(
            digest(path) == manifest["package_files"][str(path.relative_to(HERE))], "MODULE_HASH"
        )
        loaded[module_name] = {"path": str(path), "sha256": digest(path)}
    require(main_module.configure_logging is app_logging.configure_logging, "LOGGING_BINDING")
    require(
        main_module.unhandled_error_handler is app_errors.unhandled_error_handler, "HANDLER_BINDING"
    )
    fixture = json.loads((HERE / "fixture.json").read_text())

    def private_failure(payload: dict[str, str]) -> None:
        try:
            raise ValueError(payload["cause"] + " " + payload["url"])
        except ValueError as cause:
            error = RuntimeError(payload["body"])
            error.add_note(payload["note"])
            raise error from cause

    async def injected_error(request: Request) -> None:
        payload = await request.json()
        require(payload == fixture, "UNEXPECTED_SYNTHETIC_REQUEST")
        private_failure(payload)

    # Yerel import, ertelenmiş tür adının FastAPI tarafından gerçek Request
    # sınıfı olarak görülmesi için açıkça bağlanır; query parametresi oluşmaz.
    injected_error.__annotations__["request"] = Request
    main_module.app.add_api_route(
        "/__s9_probe__/error", injected_error, methods=["POST"], include_in_schema=False
    )
    original_lifespan = main_module.app.router.lifespan_context
    configured = {}

    @asynccontextmanager
    async def controlled_lifespan(app: Any) -> AsyncIterator[Any]:
        async with original_lifespan(app) as state:
            root_handlers = logging.getLogger().handlers
            error_logger = logging.getLogger("uvicorn.error")
            require(len(root_handlers) == 1, "ROOT_HANDLER_COUNT")
            require(
                isinstance(root_handlers[0].formatter, app_logging.JsonFormatter), "ROOT_FORMATTER"
            )
            require(
                not error_logger.handlers and error_logger.propagate and not error_logger.disabled,
                "UVICORN_ERROR_ROUTE",
            )
            require(not logging.getLogger("uvicorn").handlers, "UVICORN_PARENT_HANDLER")
            configured.update(
                {
                    "json_formatter": True,
                    "error_enabled": True,
                    "error_handlers": 0,
                    "error_propagates": True,
                }
            )
            write_json(args.output / "configured.json", {"pid": os.getpid(), **configured})
            if args.mode == "startup_failure":
                private_failure(fixture)
            yield state
        if args.mode == "shutdown_failure":
            private_failure(fixture)

    main_module.app.router.lifespan_context = controlled_lifespan
    listener = socket.socket(fileno=args.socket_fd)
    address = list(listener.getsockname())
    require(address[0] == "127.0.0.1" and 0 < address[1] < 65536, "LISTENER_NOT_LOOPBACK")
    server = uvicorn.Server(config)
    finished = threading.Event()
    stop_state = {"received": False}
    binding = {
        "pid": os.getpid(),
        "arm": args.arm,
        "mode": args.mode,
        "transport": actual_protocol,
        "loaded": loaded,
        "versions": {
            name: importlib.metadata.version(name)
            for name in ("fastapi", "starlette", "uvicorn", "h11", "httptools")
        },
        "python_major_minor": list(sys.version_info[:2]),
        "source_manifest_sha256": digest(HERE / "manifest.json"),
        "fixture_sha256": digest(HERE / "fixture.json"),
        "adapter": (
            "copied real app + synthetic route + wrapped actual lifespan; dependency guards only"
        ),
    }
    write_json(args.output / "binding.json", binding)

    def controlled_shutdown() -> None:
        try:
            while not server.started and not finished.wait(0.01):
                pass
            if finished.is_set():
                return
            write_json(args.output / "ready.json", {"pid": os.getpid(), "address": address})
            while not finished.is_set():
                readable, _, _ = select.select([args.control_fd], [], [], 0.1)
                if readable:
                    stop_state["received"] = os.read(args.control_fd, 1) == b"S"
                    server.should_exit = True
                    return
        finally:
            os.close(args.control_fd)

    control = threading.Thread(target=controlled_shutdown, daemon=True, name="s9-private-stop")
    control.start()
    exit_code = 0
    try:
        # Uvicorn'un kendi sinyal yakalayıcıları değiştirilmez.
        server.run(sockets=[listener])
    except SystemExit as error:
        exit_code = error.code if type(error.code) is int else 98
    except Exception:
        exit_code = 99
    finally:
        finished.set()
        control.join(timeout=2)
        listener.close()
        write_json(
            args.output / "receipt.json",
            {
                "pid": os.getpid(),
                "exit_code": exit_code,
                "server_started": server.started,
                "control_stop_received": stop_state["received"],
                "control_thread_stopped": not control.is_alive(),
                "counters": counters,
                "configured": configured,
            },
        )
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
