"""Sınav provası uçları — T032.

Router `main.py`'ye ZATEN kayıtlı; bu dosya yalnız gövde ekler.

**Mod politikaları sunucuda zorlanır.** Frontend "exam modunda ipucu butonunu
gizlemek" ile yetinir; reddi buradan gelir (FR-017):

| | `exam` | `practice` |
|---|---|---|
| Süre | `EXAM_DURATION_MINUTES` | süresiz (`expires_at = NULL`) |
| İpucu | **403** | kaynaktan türetilmiş kademeli ipucu |
| Deneme | soru başına tek — ikincisi **409** | oturum başına yine tek, yeni oturum serbest |
| Geri bildirim | `/finish`'te | cevapla birlikte, anında |
| Mastery | bitişte, tüm cevaplarla | ilk cevapta, anında |

Üç zaman kuralı, ikisi güvenlik biri tutarlılık:

1. **Saat veritabanınındır.** Kalan süre her istekte `SELECT clock_timestamp()` ile okunur;
   ne istemci saati ne uygulama sunucusunun saati kullanılır.
2. **`expires_at` kırpılır.** Etkin bitiş `min(expires_at, started_at + süre)`'dir,
   yani satırdaki `expires_at` ileri atılsa bile süre uzamaz. Bu kırpma tek başına
   yeterli DEĞİLDİR: `started_at` de aynı politikayla yazılabildiği için ikisini
   birden değiştiren biri süreyi yine uzatabilir. Yapısal kapanış `0005`'teki
   kolon bazlı GRANT'e bağlıdır (KARARLAR_SERIT4.md Karar 2). Bugün API'de bu iki
   sütuna yazan hiçbir uç yoktur; sömürü doğrudan veritabanı erişimi ister.
3. **Puan `answers`'tan türetilir**, `exam_sessions.score`'dan okunmaz. `answers`
   write-once olduğu için öğrencinin dokunamayacağı tek kayıt odur (Karar 1).

Cevap satırı puanıyla birlikte yazılır ve bir daha güncellenmez; `exam` modunda
geri bildirim yazım anında değil, **gösterim anında** tutulur.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime, timedelta
from uuid import UUID

from fastapi import APIRouter, status
from pydantic import ValidationError as PydanticValidationError
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import (
    CourseContext,
    CourseMemberDep,
    PageDep,
    SessionDep,
    SettingsDep,
    load_owned,
)
from app.core.config import Settings, get_settings
from app.core.errors import (
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    StudentAssessmentWorkspaceDisabledError,
)
from app.core.pagination import decode_time_cursor, encode_time_cursor, paginate_keyset
from app.models.assessment import (
    Answer,
    ExamBlueprint,
    ExamMode,
    ExamSession,
    ExamVersion,
    ExamVersionStatus,
    Question,
    QuestionStatus,
    Topic,
)
from app.modules.assessment import exam_state
from app.modules.assessment.exam_paper import paper_question_ids
from app.modules.assessment.exam_state import (
    acquire_user_assessment_lock,
    assessment_now,
    effective_expiry,
    remaining_seconds,
    session_cap_minutes,
)
from app.modules.assessment.grading import (
    GradingOutcome,
    SourceMaterial,
    grade_answer,
    grounded_criterion_is_valid,
    load_source_material,
    load_source_refs,
    payload_rubric,
    score_of,
)
from app.modules.mastery.service import record_answer
from app.schemas.assessment import (
    AnswerFeedbackOut,
    AnswerFormat,
    AnswerSubmitRequest,
    ExamFinishOut,
    ExamQuestionOut,
    ExamSessionOut,
    ExamStartRequest,
    GroundedCriterionEvidence,
    GroundedMissingCriterionOut,
    HintOut,
    HintRequest,
    McqPayload,
    OpenPayload,
    RubricCriterionScore,
    SourceRefOut,
    parse_payload,
    public_payload,
    solution_payload,
)
from app.schemas.exam_workspace import ExamCatalogOut, PublishedExamSummary
from app.schemas.page import PageOut

router = APIRouter(prefix="/courses/{course_id}", tags=["exams"])


# ---------------------------------------------------------------------------
# Zaman
# ---------------------------------------------------------------------------


# Zaman yardımcıları `app/modules/assessment/exam_state.py`'ye taşındı: aynı süre
# kuralına asistan kilidi de (`api/deps.py`) ihtiyaç duyuyor ve `deps.py`'nin bu
# dosyayı içe aktarması döngü olurdu. Yukarıdaki üç zaman kuralından ikincisinin
# (kırpma) gerekçesi artık orada yaşıyor.


# ---------------------------------------------------------------------------
# Yükleme yardımcıları
# ---------------------------------------------------------------------------


async def _load_exam(
    session: AsyncSession, session_id: UUID, context: CourseContext
) -> ExamSession:
    """Oturumu yükler. Başkasının oturumu, varlığı sızdırılmadan 404 döner.

    Eğitmen RLS'te kendi dersinin oturumlarını okuyabilir (analitik için) ama bu
    uçlar öğrenci akışıdır: burada yalnız oturumun sahibi geçer.
    """
    exam = await session.get(ExamSession, session_id)
    if exam is None or exam.course_id != context.course_id or exam.user_id != context.user_id:
        raise NotFoundError("Sınav oturumu bulunamadı.")
    return exam


async def _load_questions(session: AsyncSession, question_ids: list[UUID]) -> dict[UUID, Question]:
    """Oturumun sorularını okur.

    Oturum açılırken sorular sabitlenir, ama sabitlenmiş bir soru sonradan
    reddedilirse RLS onu öğrenciye kapatır ve burada eksik döner. Bu bilinçlidir:
    kayıtlı puan `answers` satırında korunur. Okuma projeksiyonu görünmeyen soruya
    ait puan ve çözümü göstermez; geçmiş cevap kaydı yeniden yazılmaz.
    """
    if not question_ids:
        return {}
    rows = await session.execute(select(Question).where(Question.id.in_(question_ids)))
    return {question.id: question for question in rows.scalars()}


async def _answers_of(session: AsyncSession, session_id: UUID) -> list[Answer]:
    rows = await session.execute(
        select(Answer).where(Answer.session_id == session_id).order_by(Answer.answered_at)
    )
    return list(rows.scalars().all())


# ---------------------------------------------------------------------------
# Geri bildirim biçimleme
# ---------------------------------------------------------------------------


def _feedback_payload(outcome: GradingOutcome) -> dict[str, object]:
    """`answers.feedback` jsonb'si. Puan kendi sütununda; burada tekrarlanmaz."""
    return {
        "durum": "degerlendirildi" if outcome.graded else "tamamlanamadi",
        "eksik_noktalar": outcome.missing_points,
        "dayanak_chunk_id": str(outcome.evidence_chunk_id) if outcome.evidence_chunk_id else None,
        "neden_yanlis_chunk_id": (
            str(outcome.why_wrong_chunk_id) if outcome.why_wrong_chunk_id else None
        ),
        "mesaj": outcome.message,
        "odak": outcome.focus,
        # FR-117: ölçüt kırılımı. Yeni tablo açılmadı — `answers.feedback` tam bu iş
        # için var (0004:110-112) ve içeriği tek bir yerden üretiliyor.
        "rubrik_kirilimi": [row.model_dump() for row in outcome.rubric_breakdown],
        "kaynakli_eksik_olcut": (
            outcome.grounded_missing_criterion.model_dump(mode="json")
            if outcome.grounded_missing_criterion
            else None
        ),
    }


def _chunk_id(feedback: dict[str, object] | None, key: str) -> UUID | None:
    raw = (feedback or {}).get(key)
    try:
        return UUID(str(raw)) if raw else None
    except ValueError:
        return None


def _answer_is_displayable(
    answer: Answer, *, question: Question | None, sources: dict[UUID, SourceMaterial]
) -> bool:
    """Revalidate saved AI evidence without rewriting historical answer records."""
    if question is None or (answer.feedback or {}).get("durum") == "tamamlanamadi":
        return False
    try:
        payload = parse_payload(question.type, question.payload)
    except PydanticValidationError:
        return False
    if isinstance(payload, McqPayload) or (
        isinstance(payload, OpenPayload) and payload.format is AnswerFormat.SHORT_ANSWER
    ):
        return True
    evidence = _chunk_id(answer.feedback, "dayanak_chunk_id")
    material = sources.get(evidence) if evidence is not None else None
    return bool(
        evidence == question.source_chunk_id and material is not None and material.text.strip()
    )


def _answer_feedback(
    answer: Answer,
    *,
    question: Question | None,
    sources: dict[UUID, SourceMaterial],
    reveal: bool,
) -> AnswerFeedbackOut:
    """Kaydedilmiş cevabı gösterilebilir geri bildirime çevirir.

    `reveal=False` iken (sınav sürerken) puan da çözüm de gizlenir; kayıt yerinde
    durur, yalnız gösterilmez.

    Alıntı, cevabın kendi **odağıyla** üretilir: aynı chunk iki öğrenciye farklı
    çeldiriciler yüzünden gösteriliyorsa her biri kendi seçimiyle çelişen cümleyi
    görür. Malzeme toplu okunduğu için bu ek sorgu maliyeti getirmez.
    """
    feedback = answer.feedback or {}
    graded = feedback.get("durum") != "tamamlanamadi"
    if not graded:
        return AnswerFeedbackOut(
            question_id=answer.question_id,
            graded=False,
            message=str(feedback.get("mesaj") or "Değerlendirme tamamlanamadı."),
        )
    if not reveal:
        return AnswerFeedbackOut(
            question_id=answer.question_id,
            graded=graded,
            message=None if graded else str(feedback.get("mesaj") or ""),
        )

    if not _answer_is_displayable(answer, question=question, sources=sources):
        return AnswerFeedbackOut(
            question_id=answer.question_id,
            graded=False,
            message=(
                "Bu değerlendirmenin kaynağı şu anda doğrulanamıyor. "
                "Puan ve çözüm gösterilmedi; eğitmeninize bildirebilirsiniz."
            ),
        )

    focus = str(feedback["odak"]) if feedback.get("odak") else None
    why_wrong = _chunk_id(feedback, "neden_yanlis_chunk_id")
    evidence = _chunk_id(feedback, "dayanak_chunk_id")
    missing = feedback.get("eksik_noktalar")

    def reference(chunk_id: UUID | None) -> SourceRefOut | None:
        material = sources.get(chunk_id) if chunk_id else None
        return material.reference(focus=focus) if material else None

    return AnswerFeedbackOut(
        question_id=answer.question_id,
        graded=graded,
        is_correct=answer.is_correct,
        score=answer.score,
        missing_points=[str(item) for item in missing] if isinstance(missing, list) else [],
        why_wrong=reference(why_wrong),
        evidence=reference(evidence),
        grounded_missing_criterion=_grounded_missing_criterion(
            feedback, question=question, sources=sources
        ),
        solution=solution_payload(question.type, question.payload) if question else None,
        rubric_breakdown=_rubric_breakdown(feedback),
        message=str(feedback.get("mesaj")) if feedback.get("mesaj") else None,
    )


def _grounded_missing_criterion(
    feedback: dict[str, object], *, question: Question | None, sources: dict[UUID, SourceMaterial]
) -> GroundedMissingCriterionOut | None:
    """Kaydedilmiş alıntıyı güncel, okunabilir kaynak metniyle yeniden doğrular."""
    raw = feedback.get("kaynakli_eksik_olcut")
    if raw is None or question is None:
        return None
    try:
        claim = GroundedCriterionEvidence.model_validate(raw)
        payload = parse_payload(question.type, question.payload)
        breakdown = _rubric_breakdown(feedback)
    except PydanticValidationError:
        return None
    material = sources.get(claim.chunk_id)
    if (
        material is None
        or claim.chunk_id != question.source_chunk_id
        or claim.chunk_id != _chunk_id(feedback, "dayanak_chunk_id")
        or not grounded_criterion_is_valid(
            claim, rubric=payload_rubric(payload), breakdown=breakdown, source_text=material.text
        )
    ):
        return None
    return GroundedMissingCriterionOut(
        criterion=claim.criterion,
        source=SourceRefOut(
            chunk_id=material.chunk_id,
            file_name=material.file_name,
            location=material.location,
            snippet=claim.quote,
        ),
    )


def _rubric_breakdown(feedback: dict[str, object]) -> list[RubricCriterionScore]:
    """Kaydedilmiş kırılımı okur.

    Kayıt anında yazılmayan (0008 öncesi) cevaplarda anahtar yoktur ve boş liste
    döner; eski cevaplar geriye dönük olarak yeniden puanlanmaz.
    """
    raw = feedback.get("rubrik_kirilimi")
    if not isinstance(raw, list):
        return []
    return [RubricCriterionScore.model_validate(row) for row in raw]


async def _saved_feedback(
    session: AsyncSession,
    answers: Sequence[Answer],
    *,
    questions: dict[UUID, Question] | None = None,
) -> list[AnswerFeedbackOut]:
    """One read projection for detail, totals, history and finish-time mastery."""
    if questions is None:
        questions = await _load_questions(session, [answer.question_id for answer in answers])
    sources = await load_source_material(
        session,
        [
            chunk_id
            for answer in answers
            for key in ("neden_yanlis_chunk_id", "dayanak_chunk_id")
            if (chunk_id := _chunk_id(answer.feedback, key)) is not None
        ],
    )
    return [
        _answer_feedback(
            answer, question=questions.get(answer.question_id), sources=sources, reveal=True
        )
        for answer in answers
    ]


def _feedback_score(results: Sequence[AnswerFeedbackOut]) -> float | None:
    return score_of([GradingOutcome(graded=row.graded, score=row.score) for row in results])


async def _session_out(
    session: AsyncSession,
    exam: ExamSession,
    *,
    settings: Settings,
    now: datetime,
    with_questions: bool = True,
    reveal_score: bool = True,
) -> ExamSessionOut:
    """Oturumu istemci zarfına çevirir.

    `with_questions=False` yalnız liste ucunda kullanılır: orada soru metinleri
    gerekmiyor ve N oturum için N soru sorgusu koşturmanın da anlamı yok.
    """
    paper = await paper_question_ids(session, exam)
    questions = await _load_questions(session, paper) if with_questions else {}
    answers = await _answers_of(session, exam.id)
    answered = {answer.question_id for answer in answers}
    expiry = effective_expiry(
        exam,
        settings=settings,
        cap_minutes=await session_cap_minutes(session, exam, settings=settings),
    )

    score = None
    if exam.finished_at is not None and reveal_score:
        score = _feedback_score(await _saved_feedback(session, answers))

    return ExamSessionOut(
        id=exam.id,
        course_id=exam.course_id,
        mode=exam.mode,
        started_at=exam.started_at,
        expires_at=expiry,
        remaining_seconds=remaining_seconds(expiry, now),
        expired=expiry is not None and now >= expiry,
        finished_at=exam.finished_at,
        score=score,
        question_count=len(paper),
        answered_count=len(answered),
        exam_version_id=exam.exam_version_id,
        exam_blueprint_id=exam.exam_blueprint_id,
        attempt_no=exam.attempt_no,
        questions=[
            ExamQuestionOut(
                id=question_id,
                type=questions[question_id].type,
                payload=public_payload(questions[question_id].type, questions[question_id].payload),
                answered=question_id in answered,
            )
            for question_id in paper
            if question_id in questions
        ],
    )


async def _results_locked(
    session: AsyncSession, context: CourseContext, *, settings: Settings
) -> bool:
    """Only a same-course student exam locks results.

    Callers exposing scores or answers hold the assessment lock; the content-free
    catalog uses this only as an advisory availability indicator.
    """
    if context.is_instructor:
        return False
    return (
        await exam_state.active_exam_session(
            session,
            user_id=context.user_id,
            course_id=context.course_id,
            now=await assessment_now(session),
            settings=settings,
        )
        is not None
    )


async def _require_help_unlocked(
    session: AsyncSession, context: CourseContext, *, settings: Settings
) -> None:
    """Serialize answer-bearing help with exam start, then check the course lock."""
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    if await _results_locked(session, context, settings=settings):
        raise exam_state.ExamLockedError(exam_state.EXAM_LOCK_MESSAGE)


def _require_workspace_enabled(settings: Settings) -> None:
    if not settings.student_assessment_workspace_enabled:
        raise StudentAssessmentWorkspaceDisabledError(
            "Sınav çalışma alanı şu anda kullanıma kapalı."
        )


async def _completed_results_out(
    session: AsyncSession,
    exam: ExamSession,
    *,
    results_locked: bool = False,
    results: list[AnswerFeedbackOut] | None = None,
) -> ExamFinishOut:
    """Read saved assessments; never grade again, write answers or update mastery."""
    if results is None:
        results = await _saved_feedback(session, await _answers_of(session, exam.id))
    unanswered = len(await paper_question_ids(session, exam)) - len(results)
    ungraded = sum(1 for result in results if not result.graded)
    if results_locked:
        return ExamFinishOut(
            session_id=exam.id,
            score=None,
            answered_count=len(results),
            unanswered_count=unanswered,
            ungraded_count=ungraded,
            results_locked=True,
            message=(
                "Oturum tamamlandı. Bu dersteki diğer sınavın bitince veya süresi dolunca "
                "sonuçlarını inceleyebilirsin."
            ),
        )

    total = _feedback_score(results)
    return ExamFinishOut(
        session_id=exam.id,
        score=total,
        answered_count=len(results),
        unanswered_count=unanswered,
        ungraded_count=ungraded,
        message=_finish_message(
            answered=len(results), unanswered=unanswered, ungraded=ungraded, score=total
        ),
        results=results,
    )


# ---------------------------------------------------------------------------
# Uçlar
# ---------------------------------------------------------------------------


async def _start_blueprint_exam(
    blueprint_id: UUID,
    context: CourseContext,
    session: AsyncSession,
    settings: Settings,
) -> ExamSessionOut:
    """Yayınlanmış bir sınava oturum açar (FR-115, FR-116).

    Üç kapı da burada Türkçe konuşur; hepsinin veritabanı tarafında ikinci bir
    katmanı var ve iki katman bağımsız olarak doğru davranmalı (Anayasa II):

    - **Görünürlük.** Öğrenci yayınlanmamış bir blueprint'i `exam_blueprints_read`
      politikası yüzünden zaten göremez; burada 404 döner ve varlığı sızmaz.
    - **Yayın penceresi.** `exam_sessions_self_insert` politikası
      `app.is_exam_open(...)` çağırıyor, yani pencere kapalıyken INSERT'i
      veritabanı da reddeder. Buradaki kontrol yalnız anlaşılır bir cümle
      kurabilmek için var — politika ihlali kısıt adıyla döner (Anayasa V).
    - **Deneme hakkı.** Sayım burada yapılır, yarış `exam_sessions_attempt_key`
      tekil indeksiyle kapanır ve ikinci eşzamanlı istek 409'a çevrilir.

    Süre blueprint'in kendi `duration_minutes`'ıdır; global `exam_duration_minutes`
    bundan sonra yalnız prova akışının varsayılanıdır.
    """
    blueprint = await load_owned(
        session, ExamBlueprint, blueprint_id, context, message="Sınav bulunamadı."
    )

    version = await session.scalar(
        select(ExamVersion).where(
            ExamVersion.blueprint_id == blueprint.id,
            ExamVersion.status == ExamVersionStatus.PUBLISHED,
        )
    )
    if version is None:
        raise ConflictError("Bu sınav henüz yayınlanmadı.")

    now = await assessment_now(session)
    if blueprint.opens_at is not None and now < blueprint.opens_at:
        raise ConflictError("Bu sınav henüz açılmadı; yayın penceresi başlamadan girilemez.")
    if blueprint.closes_at is not None and now >= blueprint.closes_at:
        raise ConflictError("Bu sınavın süresi doldu; yeni oturum başlatılamaz.")

    used = await session.scalar(
        select(func.count(ExamSession.id)).where(
            ExamSession.exam_blueprint_id == blueprint.id,
            ExamSession.user_id == context.user_id,
        )
    )
    used = int(used or 0)
    if used >= blueprint.max_attempts:
        raise ConflictError(
            f"Bu sınav için {blueprint.max_attempts} deneme hakkınız vardı ve hepsini kullandınız."
        )

    exam = ExamSession(
        course_id=context.course_id,
        user_id=context.user_id,
        mode=ExamMode.EXAM,
        started_at=now,
        expires_at=now + timedelta(minutes=blueprint.duration_minutes),
        # Kâğıt `exam_items`'tan okunur; iki kaynak birden yazılamaz.
        question_ids=None,
        exam_version_id=version.id,
        exam_blueprint_id=blueprint.id,
        attempt_no=used + 1,
    )
    session.add(exam)
    try:
        await session.flush()
    except IntegrityError as exc:
        raise ConflictError(
            "Bu sınav için başka bir oturum aynı anda başlatıldı; sayfayı yenileyin."
        ) from exc

    return await _session_out(session, exam, settings=settings, now=now)


@router.post("/exams", response_model=ExamSessionOut, status_code=status.HTTP_201_CREATED)
async def start_exam(
    payload: ExamStartRequest, context: CourseMemberDep, session: SessionDep
) -> ExamSessionOut:
    """Sınav ya da alıştırma oturumu açar.

    İki akış var ve ayrımı `blueprint_id` yapar:

    - **Prova (bugünkü akış).** Onaylı havuzdan rastgele soru çekilir ve oturumun
      `question_ids`'ine sabitlenir. Onaylı havuz boşsa oturum açılmaz: "kaynak
      yoksa cevap yok"un sınav ayağıdır.
    - **Blueprint sınavı (0008).** Kâğıt yayınlanmış sürümün `exam_items`'ından
      gelir; `question_ids` NULL kalır ve oturum `exam_version_id` ile o sürüme
      bağlanır. Sonradan yeni sürüm yayınlanması başlamış oturumu değiştirmez.

    İki akış aynı satırda karışamaz: `exam_sessions_paper_source` kısıtı kâğıdın
    iki kaynağı olmasını ifade edilemez kılıyor.
    """
    settings = get_settings()

    if payload.blueprint_id is not None:
        await acquire_user_assessment_lock(session, user_id=context.user_id)
        return await _start_blueprint_exam(payload.blueprint_id, context, session, settings)

    if payload.mode is ExamMode.PRACTICE:
        await _require_help_unlocked(session, context, settings=settings)

    if payload.topic_id is not None:
        await load_owned(session, Topic, payload.topic_id, context, message="Konu bulunamadı.")

    query = select(Question.id).where(
        Question.course_id == context.course_id,
        Question.status == QuestionStatus.APPROVED,
    )
    if payload.topic_id is not None:
        query = query.where(Question.topic_id == payload.topic_id)

    question_ids = list(
        (await session.execute(query.order_by(func.random()).limit(settings.exam_question_count)))
        .scalars()
        .all()
    )
    if not question_ids:
        raise ConflictError(
            "Bu derste henüz onaylanmış soru yok. Eğitmeniniz soruları onayladıktan "
            "sonra sınav provası başlatabilirsiniz."
        )

    if payload.mode is ExamMode.EXAM:
        await acquire_user_assessment_lock(session, user_id=context.user_id)

    now = await assessment_now(session)
    exam = ExamSession(
        course_id=context.course_id,
        user_id=context.user_id,
        mode=payload.mode,
        started_at=now,
        expires_at=(
            now + timedelta(minutes=settings.exam_duration_minutes)
            if payload.mode is ExamMode.EXAM
            else None
        ),
        question_ids=question_ids,
    )
    session.add(exam)
    await session.flush()

    return await _session_out(session, exam, settings=settings, now=now)


@router.get("/exams", response_model=list[ExamSessionOut])
async def list_exams(
    context: CourseMemberDep,
    session: SessionDep,
) -> list[ExamSessionOut]:
    """Kullanıcının bu dersteki sınav oturumları, en yenisi başta.

    Neden gerekli: oturum kimliği yalnız istemcide tutulduğunda kaybolabiliyordu —
    tarayıcı verisi temizlenince ya da başka bir cihazdan girilince öğrenci devam
    eden sınavına DÖNEMİYORDU. Aynı boşluk ters yönde de açıktı: dönemeyen öğrenci
    yeni bir oturum açıp süreyi baştan alabiliyordu, yani süre sınırı istemcinin
    hafızasına bağlı kalıyordu. Süre sunucunun kararıysa (ve öyle), oturumu bulmak
    da sunucunun işi olmalı.

    Şerit 4 bunu görüp bilerek genişletmedi: brief yalnız `GET .../{session_id}`
    diyordu ve şeridin dışına taşmamak doğru karardı. Karar liderindi, bu.

    Sahiplik ve ders eşleşmesi açıkça filtrelenir. Eğitmen RLS üzerinden kendi
    dersindeki öğrencileri okuyabilse de bu uç yalnız kendi oturumlarını döndürür.

    Sorular gövdede TAŞINMAZ. Liste "hangi oturumlarım var" sorusunu cevaplar;
    soru metinlerini taşımak, bitmemiş bir sınavın sorularını tek listede dışarı
    vermek olurdu ve ekranın bu bilgiye ihtiyacı yok.
    """
    settings = get_settings()
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    reveal_score = not await _results_locked(session, context, settings=settings)
    now = await assessment_now(session)
    rows = (
        await session.execute(
            select(ExamSession)
            .where(
                ExamSession.course_id == context.course_id,
                ExamSession.user_id == context.user_id,
            )
            .order_by(ExamSession.started_at.desc(), ExamSession.id.desc())
        )
    ).scalars()
    return [
        await _session_out(
            session,
            exam,
            settings=settings,
            now=now,
            with_questions=False,
            reveal_score=reveal_score,
        )
        for exam in rows
    ]


@router.get("/exams/catalog", response_model=ExamCatalogOut)
async def exam_catalog(
    context: CourseMemberDep, session: SessionDep, settings: SettingsDep
) -> ExamCatalogOut:
    """Only open, published exams; no papers, draft metadata or answer keys."""
    if not settings.student_assessment_workspace_enabled:
        return ExamCatalogOut(enabled=False, items=[])
    now = await assessment_now(session)
    attempts = (
        select(ExamSession.exam_blueprint_id, func.count(ExamSession.id).label("used"))
        .where(
            ExamSession.course_id == context.course_id,
            ExamSession.user_id == context.user_id,
        )
        .group_by(ExamSession.exam_blueprint_id)
        .subquery()
    )
    rows = await session.execute(
        select(ExamBlueprint, func.coalesce(attempts.c.used, 0))
        .join(
            ExamVersion,
            (ExamVersion.blueprint_id == ExamBlueprint.id)
            & (ExamVersion.course_id == ExamBlueprint.course_id),
        )
        .outerjoin(attempts, attempts.c.exam_blueprint_id == ExamBlueprint.id)
        .where(
            ExamBlueprint.course_id == context.course_id,
            ExamVersion.status == ExamVersionStatus.PUBLISHED,
            or_(ExamBlueprint.opens_at.is_(None), ExamBlueprint.opens_at <= now),
            or_(ExamBlueprint.closes_at.is_(None), ExamBlueprint.closes_at > now),
        )
        .order_by(ExamBlueprint.title, ExamBlueprint.id)
    )
    locked = await _results_locked(session, context, settings=settings)
    return ExamCatalogOut(
        enabled=True,
        items=[
            PublishedExamSummary(
                blueprint_id=blueprint.id,
                title=blueprint.title,
                description=blueprint.description,
                duration_minutes=blueprint.duration_minutes,
                opens_at=blueprint.opens_at,
                closes_at=blueprint.closes_at,
                max_attempts=blueprint.max_attempts,
                used_attempts=int(used),
                remaining_attempts=max(0, blueprint.max_attempts - int(used)),
                can_start=not locked and int(used) < blueprint.max_attempts,
            )
            for blueprint, used in rows.tuples()
        ],
    )


@router.get("/exams/history", response_model=PageOut[ExamSessionOut])
async def exam_history(
    context: CourseMemberDep,
    session: SessionDep,
    settings: SettingsDep,
    page: PageDep,
) -> PageOut[ExamSessionOut]:
    """Owner-only server history; bounded, stable pages without question content."""
    _require_workspace_enabled(settings)
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    reveal_score = not await _results_locked(session, context, settings=settings)
    result = await paginate_keyset(
        session,
        select(ExamSession).where(
            ExamSession.course_id == context.course_id,
            ExamSession.user_id == context.user_id,
        ),
        key_columns=(ExamSession.started_at, ExamSession.id),
        page=page,
        decode=decode_time_cursor,
        encode=lambda exam: encode_time_cursor(exam.started_at, exam.id),
    )
    now = await assessment_now(session)
    return PageOut(
        items=[
            await _session_out(
                session,
                exam,
                settings=settings,
                now=now,
                with_questions=False,
                reveal_score=reveal_score,
            )
            for exam in result.rows
        ],
        next_cursor=result.next_cursor,
    )


@router.get("/exams/{session_id}/results", response_model=ExamFinishOut)
async def exam_results(
    session_id: UUID,
    context: CourseMemberDep,
    session: SessionDep,
    settings: SettingsDep,
) -> ExamFinishOut:
    """Reopen finished results without changing session state or grading again."""
    _require_workspace_enabled(settings)
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    exam = await _load_exam(session, session_id, context)
    if exam.finished_at is None:
        raise ConflictError("Sonuçları görmek için önce oturumu tamamlayın.")
    await _require_help_unlocked(session, context, settings=settings)
    return await _completed_results_out(session, exam)


@router.get("/exams/{session_id}/answers/{question_id}", response_model=AnswerFeedbackOut)
async def saved_practice_answer(
    session_id: UUID,
    question_id: UUID,
    context: CourseMemberDep,
    session: SessionDep,
    settings: SettingsDep,
) -> AnswerFeedbackOut:
    """Read owned practice feedback without grading or changing historical records."""
    _require_workspace_enabled(settings)
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    exam = await _load_exam(session, session_id, context)
    if exam.mode is not ExamMode.PRACTICE:
        raise PermissionDeniedError("Sınav cevapları yalnız tamamlanan sonuç ekranında açılır.")
    await _require_help_unlocked(session, context, settings=settings)
    if question_id not in await paper_question_ids(session, exam):
        raise NotFoundError("Bu soru bu alıştırma oturumunda yok.")
    answer = await session.scalar(
        select(Answer).where(Answer.session_id == exam.id, Answer.question_id == question_id)
    )
    if answer is None:
        raise NotFoundError("Bu soru için kayıtlı cevap bulunamadı.")
    return (await _saved_feedback(session, [answer]))[0]


@router.get("/exams/{session_id}", response_model=ExamSessionOut)
async def get_exam(
    session_id: UUID, context: CourseMemberDep, session: SessionDep
) -> ExamSessionOut:
    """Oturum durumu ve **kalan süre**.

    Bağlantı koparsa öğrenci buraya döner ve kaldığı yerden devam eder: sayaç
    istemcide, süre sunucudadır.
    """
    settings = get_settings()
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    exam = await _load_exam(session, session_id, context)
    return await _session_out(
        session,
        exam,
        settings=settings,
        now=await assessment_now(session),
        reveal_score=not await _results_locked(session, context, settings=settings),
    )


@router.post(
    "/exams/{session_id}/answers",
    response_model=AnswerFeedbackOut,
    status_code=status.HTTP_201_CREATED,
)
async def submit_answer(
    session_id: UUID,
    payload: AnswerSubmitRequest,
    context: CourseMemberDep,
    session: SessionDep,
) -> AnswerFeedbackOut:
    """Cevabı kaydeder ve **aynı işlemde** puanlar.

    Puan cevapla birlikte yazılır çünkü `answers` satırı bir daha güncellenmez
    (Karar 1). `exam` modunda puan yazılır ama döndürülmez; `practice` modunda
    anında geri bildirim olarak döner.
    """
    settings = get_settings()
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    exam = await _load_exam(session, session_id, context)
    if exam.mode is ExamMode.PRACTICE:
        await _require_help_unlocked(session, context, settings=settings)
    now = await assessment_now(session)

    if exam.finished_at is not None:
        raise ConflictError("Bu oturum tamamlandı; yeni cevap kabul edilmiyor.")

    expiry = effective_expiry(
        exam,
        settings=settings,
        cap_minutes=await session_cap_minutes(session, exam, settings=settings),
    )
    if expiry is not None and now >= expiry:
        raise ConflictError("Sınav süresi doldu; cevap kabul edilmiyor.")

    if payload.question_id not in await paper_question_ids(session, exam):
        raise NotFoundError("Bu soru bu sınav oturumunda yok.")

    if exam.mode is ExamMode.EXAM and payload.hint_level > 0:
        raise PermissionDeniedError("Sınav modunda ipucu kapalıdır.")

    existing = await session.scalar(
        select(Answer.id).where(
            Answer.session_id == exam.id, Answer.question_id == payload.question_id
        )
    )
    if existing is not None:
        raise ConflictError("Bu soruyu zaten cevapladınız; soru başına tek deneme hakkı var.")

    question = await session.get(Question, payload.question_id)
    if question is None:
        raise NotFoundError("Soru bulunamadı.")

    # Sağlayıcı burada çözümlenmez: MCQ ve kısa cevap LLM'siz puanlanır ve
    # sağlayıcı arızası sınavı düşürmemeli (grading.grade_answer, FR-020).
    outcome = await grade_answer(session, question, payload.given)

    answer = Answer(
        session_id=exam.id,
        question_id=question.id,
        course_id=exam.course_id,
        given=payload.given,
        is_correct=outcome.is_correct,
        score=outcome.score,
        hint_level=payload.hint_level,
        feedback=_feedback_payload(outcome),
    )
    session.add(answer)
    try:
        await session.flush()
    except IntegrityError as exc:
        # UNIQUE (session_id, question_id): yukarıdaki kontrolle yarışan ikinci istek.
        raise ConflictError("Bu soruyu zaten cevapladınız.") from exc

    if exam.mode is ExamMode.PRACTICE and outcome.graded and outcome.score is not None:
        # FR-017: practice modda mastery ilk cevapta işlenir (bitişi beklemez).
        await record_answer(
            session,
            user_id=context.user_id,
            topic_id=question.topic_id,
            course_id=exam.course_id,
            raw_score=outcome.score,
            hint_level=payload.hint_level,
            alpha=settings.mastery_alpha,
        )

    reveal = exam.mode is ExamMode.PRACTICE
    sources = (
        await load_source_material(
            session,
            [
                chunk_id
                for chunk_id in (outcome.why_wrong_chunk_id, outcome.evidence_chunk_id)
                if chunk_id is not None
            ],
        )
        if reveal
        else {}
    )
    return _answer_feedback(
        answer, question=question if reveal else None, sources=sources, reveal=reveal
    )


@router.post("/exams/{session_id}/hint", response_model=HintOut)
async def request_hint(
    session_id: UUID,
    payload: HintRequest,
    context: CourseMemberDep,
    session: SessionDep,
    settings: SettingsDep,
) -> HintOut:
    """Kademeli ipucu — yalnız `practice` modunda.

    İpucu metni **kaynaktan türetilir**, modelden değil: kademe yükseldikçe sorunun
    dayandığı chunk'tan daha çoğu açılır. Böylece ipucu her zaman gerçek bir
    materyal parçasına dayanır (Anayasa I) ve LLM ayakta olmasa da çalışır.
    """
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    exam = await _load_exam(session, session_id, context)

    if exam.mode is ExamMode.EXAM:
        raise PermissionDeniedError(
            "Sınav modunda ipucu kapalıdır. İpucu almak için alıştırma modunda çalışabilirsiniz."
        )

    await _require_help_unlocked(session, context, settings=settings)

    if exam.finished_at is not None:
        raise ConflictError("Bu oturum tamamlandı.")

    if payload.question_id not in await paper_question_ids(session, exam):
        raise NotFoundError("Bu soru bu sınav oturumunda yok.")

    question = await session.get(Question, payload.question_id)
    if question is None:
        raise NotFoundError("Soru bulunamadı.")

    from app.modules.policy.service import resolve_policy

    policy = await resolve_policy(session, course_id=context.course_id, settings=settings)
    if policy.max_hints <= 0:
        raise PermissionDeniedError("Bu derste ipuçları eğitmeniniz tarafından kapatıldı.")

    refs = await load_source_refs(session, [question.source_chunk_id])
    source = refs.get(question.source_chunk_id)
    if source is None:
        raise NotFoundError("Bu sorunun kaynağı okunamadı; ipucu üretilemiyor.")

    level = min(payload.hint_level, policy.max_hints)
    return HintOut(
        question_id=question.id,
        hint_level=level,
        text=_hint_text(level, source),
        source=source,
    )


#: Kademe → kaynaktan açılacak oran. 1. kademe yalnız konumu söyler, 4. kademe
#: kaynaklı açıklamanın tamamını verir (Sokratik merdivenin ölçme ayağı).
_HINT_FRACTIONS: dict[int, float] = {1: 0.0, 2: 0.25, 3: 0.5, 4: 1.0}


def _hint_text(level: int, source: SourceRefOut) -> str:
    where = f"Bu sorunun dayandığı bölüm: {source.file_name} · {source.location}."
    fraction = _HINT_FRACTIONS.get(level, 0.0)
    if fraction <= 0:
        return f"{where} Önce oraya bakıp kendi cevabını dene."
    cut = max(60, int(len(source.snippet) * fraction))
    excerpt = source.snippet[:cut].rstrip()
    suffix = "" if cut >= len(source.snippet) else "…"
    return f"{where}\n\nKaynaktan: {excerpt}{suffix}"


@router.post("/exams/{session_id}/finish", response_model=ExamFinishOut)
async def finish_exam(
    session_id: UUID, context: CourseMemberDep, session: SessionDep
) -> ExamFinishOut:
    """Oturumu kapatır, puanı açıklar ve soru bazlı geri bildirimi verir (FR-018).

    Cevaplanmamış sorular **boş** sayılır: yanlış değildirler ve paydaya girmezler.
    Değerlendirilememiş cevaplar da paydaya girmez (FR-020) — uydurma puan yerine
    açık bir "değerlendirilemedi" sayısı raporlanır.
    """
    settings = get_settings()
    await acquire_user_assessment_lock(session, user_id=context.user_id)
    exam = await _load_exam(session, session_id, context)
    now = await assessment_now(session)

    if exam.finished_at is not None:
        raise ConflictError("Bu oturum zaten tamamlandı.")

    answers = await _answers_of(session, exam.id)
    questions = await _load_questions(session, [answer.question_id for answer in answers])
    results = await _saved_feedback(session, answers, questions=questions)
    visible = {result.question_id: result for result in results}

    exam.finished_at = now
    # `exam.score` YAZILMIYOR. Puan `answers`'tan türetiliyor (bu dosyanın
    # başındaki 3. kural ve `_session_out`); sütuna yazmak ölü bir yazmaydı ve
    # `0007`'nin kolon GRANT'i onu görünür kıldı — `dou_app` artık yalnız
    # `finished_at` yazabiliyor. Kısıt Şerit 4'ün Karar 2'si: öğrenci kendi
    # oturumunun süresini ve puanını değiştirememeli, ve RLS sütun kısıtı
    # veremediği için koruma GRANT'te.
    await session.flush()

    if exam.mode is ExamMode.EXAM:
        # T037: sınav modunda mastery bitişte, tüm cevaplarla işlenir.
        for answer in answers:
            question = questions.get(answer.question_id)
            projection = visible[answer.question_id]
            if question is None or not projection.graded or projection.score is None:
                continue
            await record_answer(
                session,
                user_id=context.user_id,
                topic_id=question.topic_id,
                course_id=exam.course_id,
                raw_score=projection.score,
                hint_level=answer.hint_level,
                alpha=settings.mastery_alpha,
            )

    return await _completed_results_out(
        session,
        exam,
        results_locked=await _results_locked(session, context, settings=settings),
        results=results,
    )


def _finish_message(*, answered: int, unanswered: int, ungraded: int, score: float | None) -> str:
    if score is None:
        reason = (
            "Hiçbir soru cevaplanmadığı için"
            if answered == 0
            else "Hiçbir cevap değerlendirilemediği için"
        )
        return f"{reason} puan hesaplanmadı. Boş bırakılan sorular yanlış sayılmaz."
    parts = [f"{answered} soru cevaplandı."]
    if unanswered:
        parts.append(f"{unanswered} soru boş bırakıldı; boş sorular puana katılmaz.")
    if ungraded:
        parts.append(f"{ungraded} cevabın değerlendirmesi tamamlanamadı ve puana katılmadı.")
    return " ".join(parts)
