"""Ders bazlı AI politikası."""
