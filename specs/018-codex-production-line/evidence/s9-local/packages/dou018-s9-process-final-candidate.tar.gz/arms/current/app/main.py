"""FastAPI uygulama giriş noktası."""

from __future__ import annotations

import asyncio
import contextlib
import re
import time
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.routing import APIRoute
from fastapi.staticfiles import StaticFiles

from app.api import (
    admin,
    analytics,
    blueprints,
    chat,
    courses,
    dashboard,
    documents,
    exams,
    feedback,
    health,
    internal,
    policy,
    privacy,
    profile,
    questions,
    sources,
)
from app.api.deps import PlatformAdminDep
from app.api.evaluation_runtime import initialize_evaluation_runtime
from app.core.config import get_settings
from app.core.db import dispose_engine
from app.core.errors import (
    AppError,
    app_error_handler,
    unhandled_error_handler,
    validation_error_handler,
)
from app.core.logging import configure_logging, get_logger
from app.core.request_body_limit import MULTIPART_ENVELOPE_BYTES, RequestBodyLimitMiddleware
from app.core.warmup import start_warmup

logger = get_logger("app.request")

_SAFE_REQUEST_ID = re.compile(r"^[A-Za-z0-9_-]{1,128}$")


def _request_log_path(request: Request) -> str:
    """Yalnız eşleşen API rotasının sunucuda tanımlı şablonunu kaydet.

    Parametreler, sorgu dizgesi ve ham adres günlükte yer almaz. Yönlendiriciye
    ulaşmayan istekler, eşleşmeyen yollar ve rota bildirmeyen statik mount'lar
    aynı sabit değeri kullanır; ham adrese geri dönüş yapılmaz. Alt FastAPI
    uygulamasında eşleşme varsa yalnız iç rotanın şablonu kullanılır.
    """
    route = request.scope.get("route")
    return route.path_format if isinstance(route, APIRoute) else "<unmatched>"


API_SECURITY_HEADERS: dict[str, str] = {
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
}

#: Markalı API belge sayfasının kaynakları (`apps/api/static/`).
STATIC_DIR = Path(__file__).resolve().parent.parent / "static"

#: Belge YÜZEYİNİN politikası. JSON uçlarının `default-src 'none'` kuralı
#: bir sayfa için uygulanamaz: kendi CSS'ini ve Swagger paketini yükleyemez,
#: kullanıcı boş ekran görür. Gevşetme yalnız bu yüzeye ve yalnız `'self'`
#: kadardır — CDN yok (paket `static/vendor` altında), inline script yok
#: (başlatma ayrı dosyada), çerçevelenme hâlâ kapalı.
DOCS_SECURITY_HEADERS: dict[str, str] = {
    "Content-Security-Policy": (
        "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; font-src 'self'; connect-src 'self'; "
        "base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
    ),
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
}

#: Belge yüzeyi olan yollar. Ön ek karşılaştırması yapılır çünkü statik
#: varlıklar `/static/...` altında dallanır.
_DOCS_SURFACE_PREFIXES = ("/docs", "/static/", "/openapi.json")


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    configure_logging()
    settings = get_settings()
    logger.info(
        "api başlatıldı",
        extra={"context": {"environment": settings.environment, "version": settings.api_version}},
    )
    # Isıtma BAŞLATILIR, BEKLENMEZ (FR-221). `await` edilseydi üretim
    # sağlayıcısında ~19 sn'lik bir startup oluşur ve orkestratörün startup
    # probe penceresi aşılırdı — çözdüğünden büyük bir arıza. Hazır olup
    # olmadığı `/health/ready` üzerinden bildiriliyor (bkz. core/warmup.py).
    warmup_task = start_warmup()
    yield
    if warmup_task is not None:
        warmup_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await warmup_task
    await dispose_engine()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.api_title,
        version=settings.api_version,
        description=(
            "Ders materyaline bağlı, kaynaklı cevap üreten ders asistanının HTTP "
            "yüzeyi. Her cevap dayandığı sayfayla döner; dayanak yoksa uç cevap "
            "değil gerekçeli ret döndürür. Ders izolasyonu iki katmanda zorlanır: "
            "sunucu tarafında üyelik doğrulaması ve aynı oturumda PostgreSQL satır "
            "düzeyi güvenlik."
        ),
        lifespan=lifespan,
        # Varsayılan Swagger sayfası devre dışı: CDN'den script çeker ve inline
        # script kullanır; bu API'nin politikasında ikisi de çalışmaz. Yerine
        # markalı, kendi varlıklarını barındıran `/docs` sayfası servis edilir.
        docs_url=None,
        redoc_url=None,
        # Sözleşme HERKESE AÇIK DEĞİL: `/openapi.json` aşağıda platform yöneticisi
        # kapısıyla yeniden tanımlanır. Varsayılan uç açık kalsaydı kapı yalnız
        # sayfada olurdu ve şemayı doğrudan çekmek isteyen biri kapıyı atlardı.
        openapi_url=None,
    )

    initialize_evaluation_runtime(app, settings)

    # Son eklenen middleware dışta çalışır: CORS/güvenlik/request-id erken
    # boyut retlerini de sarar. Ayrıştırıcıya yalnız sınırlanmış gövde ulaşır.
    app.add_middleware(
        RequestBodyLimitMiddleware,
        max_bytes=settings.max_upload_bytes + MULTIPART_ENVELOPE_BYTES,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        # Kimlik `Authorization` başlığıyla taşınıyor, çerezle değil; bu bayrak
        # tarayıcıya çerez/kimlik bilgisi göndermesini söyler ve karşılığında
        # `allow_origins` joker olamaz. Kullanılmayan bir gevşetme (R1 bildirdi).
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def security_headers(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        """API JSON yanıtlarına yüzeye uygun, fail-closed tarayıcı politikası ekle."""
        response = await call_next(request)
        path = request.url.path
        headers = (
            DOCS_SECURITY_HEADERS
            if any(path.startswith(prefix) for prefix in _DOCS_SURFACE_PREFIXES)
            else API_SECURITY_HEADERS
        )
        for key, value in headers.items():
            response.headers[key] = value
        return response

    @app.middleware("http")
    async def request_logging(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        supplied_request_id = request.headers.get("X-Request-ID", "")
        request_id = (
            supplied_request_id
            if _SAFE_REQUEST_ID.fullmatch(supplied_request_id)
            else uuid.uuid4().hex
        )
        # `call_next`'ten ÖNCE yazılır: hata handler'ları kimliği buradan okuyor
        # ve zarfa koyuyor (`core/errors.py::request_id_of`). Sonra yazılsaydı
        # yanıt başlığı kimliği taşırdı ama gövde taşımazdı — kullanıcıya
        # gösterilen destek kodu ile logdaki kayıt ayrı düşerdi.
        request.state.request_id = request_id
        started = time.perf_counter()
        response = await call_next(request)
        duration_ms = round((time.perf_counter() - started) * 1000, 1)
        response.headers["X-Request-ID"] = request_id
        logger.info(
            "istek tamamlandı",
            extra={
                "context": {
                    "request_id": request_id,
                    "method": request.method,
                    "path": _request_log_path(request),
                    "status": response.status_code,
                    "duration_ms": duration_ms,
                }
            },
        )
        return response

    app.add_exception_handler(AppError, app_error_handler)
    # Şema doğrulaması da projenin tek hata zarfını kullanır; aksi hâlde istemci
    # FastAPI'nin İngilizce `{"detail": [...]}` biçimini ayrıca tanımak zorunda kalır.
    app.add_exception_handler(RequestValidationError, validation_error_handler)
    app.add_exception_handler(Exception, unhandled_error_handler)

    app.include_router(health.router)
    app.include_router(profile.router)
    app.include_router(dashboard.router)
    app.include_router(admin.router)
    app.include_router(courses.router)
    app.include_router(documents.router)
    app.include_router(sources.router)
    app.include_router(privacy.router)
    app.include_router(policy.router)
    app.include_router(questions.router)
    app.include_router(chat.router)
    app.include_router(feedback.router)
    app.include_router(exams.router)
    app.include_router(blueprints.router)
    app.include_router(analytics.router)
    # İç worker tetiği OpenAPI'den bilinçli olarak gizlidir; sır yoksa 404,
    # doğru sırla bir ingestion turu çalıştırır.
    app.include_router(internal.router)

    @app.get("/openapi.json", include_in_schema=False)
    async def openapi_spec(admin: PlatformAdminDep) -> dict[str, Any]:
        """API sözleşmesi — yalnız platform yöneticisi.

        Şema, ürünün tüm yüzeyini (uçlar, alanlar, hata kodları) tek dosyada
        anlatır; dışarıya açık bırakmak saldırı yüzeyini haritalamayı kolaylaştırır.
        `PlatformAdminDep` yetkiyi `platform_admins` tablosundan doğrular ve
        REDDEDİLEN denemeler dahil her erişimi audit tablosuna yazar — yani bu
        kapı yalnız engellemez, iz de bırakır.
        """
        return app.openapi()

    @app.get("/docs", include_in_schema=False)
    def api_docs() -> FileResponse:
        """Markalı API belge sayfası (kendi varlıkları, CDN yok).

        Sayfanın KABUĞU herkese açıktır ve içinde sözleşme yoktur: şemayı
        tarayıcıdan `/openapi.json` çağrısıyla ister ve o çağrı yönetici
        jetonu gerektirir. Kapıyı sunucuda tutmanın sebebi bu — sayfayı
        gizlemek koruma değildir, şemayı korumak korumadır.
        """
        return FileResponse(STATIC_DIR / "docs.html")

    # Statik varlıklar EN SONA monte edilir: `app.mount` bir alt-uygulamadır ve
    # router'lardan önce monte edilseydi `/static` ön ekiyle çakışan hiçbir uç
    # kalmasa bile sıralama okunmaz olurdu. Dizin yoksa (bazı test ortamları)
    # montaj atlanır; API bu sayfa olmadan da çalışır.
    if STATIC_DIR.is_dir():
        app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
    return app


app = create_app()
