"""S9 süreç deneyinin sabit kaynakları ve içeriksiz sonuç yardımcıları."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
REPO = Path("/Users/muratates/code/dou-synapse-018-codex-production-line")
PYTHON = REPO / "apps/api/.venv/bin/python"
ARMS = ("current", "s9", "s9b", "s9c")
SCENARIOS = (
    ("http-h11", "http", "h11"),
    ("http-httptools", "http", "httptools"),
    ("startup-failure", "startup_failure", "h11"),
    ("shutdown-failure", "shutdown_failure", "h11"),
)
MAX_LOG_BYTES = 1024 * 1024


class ProbeFailure(Exception):
    """Yalnız çalıştırıcıdaki sabit kontrol kodu; serbest istisna metni dönmez."""


def require(condition: bool, code: str) -> None:
    if not condition:
        raise ProbeFailure(code)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: Any) -> None:
    require(not path.exists(), "OUTPUT_ALREADY_EXISTS")
    temporary = path.with_suffix(path.suffix + ".writing")
    with temporary.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    temporary.replace(path)


def verify_sources() -> dict[str, Any]:
    manifest = json.loads((HERE / "manifest.json").read_text())
    require(manifest["arm_order"] in [list(ARMS[:3]), list(ARMS)], "ARM_ORDER")
    if "s9c" in manifest["arm_order"]:
        extension = manifest.get("s9c_extension", {})
        require(
            len(extension.get("prior_three_arm_manifest_sha256", "")) == 64, "S9C_PARENT_BINDING"
        )
        require(
            digest(Path(extension["logging_source_manifest_path"]))
            == extension["logging_source_manifest_sha256"],
            "S9C_LOGGING_SOURCE_BINDING",
        )
    for relative, expected in manifest["package_files"].items():
        require(digest(HERE / relative) == expected, "PACKAGE_SOURCE_CHANGED")
    for absolute, expected in manifest["current_runtime_sources"].items():
        require(digest(Path(absolute)) == expected, "CURRENT_RUNTIME_SOURCE_CHANGED")
    for absolute, expected in manifest["framework_sources"].items():
        require(digest(Path(absolute)) == expected, "FRAMEWORK_SOURCE_CHANGED")
    for absolute, expected in manifest["frozen_candidate_manifests"].items():
        require(digest(Path(absolute)) == expected, "FROZEN_CANDIDATE_CHANGED")
    return manifest


def read_logs(directory: Path) -> tuple[str, list[dict[str, Any]]]:
    raw_parts = []
    parsed = []
    for name in ("stdout.log", "stderr.log"):
        path = directory / name
        require(path.stat().st_size <= MAX_LOG_BYTES, "EXCESSIVE_PROCESS_LOG")
        raw = path.read_text(errors="replace")
        raw_parts.append(raw)
        for line in raw.splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                parsed.append(value)
    return "\n".join(raw_parts), parsed
