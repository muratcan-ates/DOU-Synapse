"""Root'un çalıştıracağı 12 sıralı gerçek Uvicorn deneyi; importta yürütülmez."""

from __future__ import annotations

import argparse
import ast
import hashlib
import http.client
import json
import os
import re
import socket
import subprocess
import time
from pathlib import Path
from typing import Any

from common import (
    HERE,
    PYTHON,
    SCENARIOS,
    ProbeFailure,
    digest,
    read_logs,
    require,
    verify_sources,
    write_json,
)

PUBLIC_ERROR_MESSAGE = "İşlem tamamlanamadı. Lütfen daha sonra tekrar deneyin."


def environment(stage: Path, passfile: Path) -> dict[str, str]:
    # İzinli ortam sıfırdan kurulur; ambient PG/servis/hostaddr/proxy/sırlar taşınmaz.
    return {
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
        "LANG": "en_US.UTF-8",
        "PYTHONPATH": str(stage),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONUNBUFFERED": "1",
        "ENVIRONMENT": "local",
        "DEV_AUTH_ENABLED": "true",
        "API_VERSION": "0.1.0",
        "SUPABASE_JWT_SECRET": "",
        "SUPABASE_JWT_ISSUER": "",
        "DATABASE_URL": "postgresql+psycopg://dou_app:synthetic_probe_only@127.0.0.1:9/s9_never_connect",
        "WORKER_DATABASE_URL": "postgresql+psycopg://dou_worker:synthetic_probe_only@127.0.0.1:9/s9_never_connect",
        "PGPASSFILE": str(passfile),
        "EMBEDDING_PROVIDER": "hashing",
        "EMBEDDING_WARMUP_ENABLED": "false",
        "LLM_FAKE_PROVIDER": "true",
        "EVAL_RUNTIME_ENABLED": "false",
        "GROQ_API_KEY": "",
        "GEMINI_API_KEY": "",
        "OPENAI_API_KEY": "",
        "HF_HUB_OFFLINE": "1",
        "HF_DATASETS_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
        "HTTP_PROXY": "",
        "HTTPS_PROXY": "",
        "ALL_PROXY": "",
        "NO_PROXY": "127.0.0.1",
    }


def fetch(port: int, path: str, request_id: str, payload: bytes | None = None) -> dict[str, Any]:
    # http.client proxy keşfi ve otomatik redirect yapmaz; numeric endpoint sabittir.
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    try:
        method = "POST" if payload is not None else "GET"
        headers = {"X-Request-ID": request_id, "Connection": "close"}
        if payload is not None:
            headers["Content-Type"] = "application/json"
        connection.request(method, path, body=payload, headers=headers)
        response = connection.getresponse()
        body = response.read(65537)
        require(len(body) <= 65536, "RESPONSE_TOO_LARGE")
        parsed = json.loads(body)
        if payload is not None:
            require(response.status == 500, "ERROR_STATUS")
            require(
                parsed
                == {
                    "error": {
                        "code": "internal_error",
                        "message": PUBLIC_ERROR_MESSAGE,
                        "request_id": request_id,
                    }
                },
                "GENERIC_ERROR_ENVELOPE",
            )
            # Gerçek mevcut middleware hata yolunda yanıt başlığını ekleyemiyor.
            require(response.getheader("X-Request-ID") is None, "BASELINE_ERROR_HEADER_CHANGED")
        else:
            require(
                response.status == 200
                and parsed == {"status": "ok", "environment": "local", "version": "0.1.0"},
                "LIVE_RESPONSE",
            )
            require(response.getheader("X-Request-ID") == request_id, "LIVE_REQUEST_ID")
        fixture = json.loads((HERE / "fixture.json").read_text())
        require(
            not any(marker in body.decode() for marker in fixture.values()), "PRIVATE_HTTP_RESPONSE"
        )
        return {
            "status": response.status,
            "request_id": request_id,
            "x_request_id": response.getheader("X-Request-ID"),
            "body_sha256": hashlib.sha256(body).hexdigest(),
            "body_bytes": len(body),
            "generic_contract_verified": payload is not None,
        }
    finally:
        connection.close()


def check_frames(event: dict[str, Any], arm: str) -> None:
    summary = event.get("exception")
    require(isinstance(summary, dict), "STRUCTURED_EXCEPTION_MISSING")
    require(set(summary) == {"error_type", "frames", "frames_truncated"}, "EXCEPTION_SCHEMA")
    require(summary["error_type"] == "RuntimeError", "ERROR_TYPE")
    frames = summary["frames"]
    require(isinstance(frames, list) and 0 < len(frames) <= 8, "APP_FRAME_COUNT")
    require(type(summary["frames_truncated"]) is bool, "FRAME_TRUNCATION_TYPE")
    root = HERE / "arms" / arm / "app"
    for frame in frames:
        require(set(frame) == {"path", "function", "line"}, "FRAME_SCHEMA")
        relative = Path(frame["path"])
        require(not relative.is_absolute() and ".." not in relative.parts, "FRAME_NOT_RELATIVE")
        require(relative.suffix == ".py", "FRAME_NOT_PYTHON")
        source = root / relative
        require(source.resolve().is_relative_to(root), "FRAME_OUTSIDE_APP")
        require(source.is_file(), "FRAME_UNKNOWN_SOURCE")
        text = source.read_text()
        names = {"<module>", "<lambda>", "<listcomp>", "<dictcomp>", "<setcomp>", "<genexpr>"}
        names.update(
            n.name
            for n in ast.walk(ast.parse(text))
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        )
        require(frame["function"] in names, "FRAME_UNKNOWN_FUNCTION")
        require(
            type(frame["line"]) is int and 1 <= frame["line"] <= len(text.splitlines()),
            "FRAME_LINE_RANGE",
        )


def audit(
    directory: Path,
    arm: str,
    name: str,
    mode: str,
    protocol: str,
    pid: int,
    port: int,
    exit_code: int,
    responses: list[dict[str, Any]],
    seconds: float,
) -> dict[str, Any]:
    raw, records = read_logs(directory)
    binding = json.loads((directory / "binding.json").read_text())
    receipt = json.loads((directory / "receipt.json").read_text())
    require(binding["pid"] == pid == receipt["pid"], "PID_BINDING")
    require(binding["arm"] == arm and binding["mode"] == mode, "SCENARIO_BINDING")
    require(binding["source_manifest_sha256"] == digest(HERE / "manifest.json"), "MANIFEST_BINDING")
    require(binding["fixture_sha256"] == digest(HERE / "fixture.json"), "FIXTURE_BINDING")
    manifest = json.loads((HERE / "manifest.json").read_text())
    require(binding["versions"] == manifest["runtime_versions"], "FRAMEWORK_VERSION_BINDING")
    require(binding["python_major_minor"] == [3, 12], "PYTHON_VERSION_BINDING")
    require(
        binding["transport"]
        == {
            "h11": "uvicorn.protocols.http.h11_impl.H11Protocol",
            "httptools": "uvicorn.protocols.http.httptools_impl.HttpToolsProtocol",
        }[protocol],
        "TRANSPORT_BINDING",
    )
    for module, source in binding["loaded"].items():
        expected = HERE / "arms" / arm / (module.replace(".", "/") + ".py")
        require(
            source == {"path": str(expected), "sha256": digest(expected)}, "LOADED_SOURCE_BINDING"
        )
    require(
        set(binding["loaded"]) == {"app.main", "app.core.errors", "app.core.logging"},
        "LOADED_SOURCE_SET",
    )
    require(
        receipt["counters"] == {"database": 0, "outbound_socket": 0, "embedding": 0, "llm": 0},
        "DEPENDENCY_CALL_ATTEMPT",
    )
    require(
        receipt["configured"]
        == {
            "json_formatter": True,
            "error_enabled": True,
            "error_handlers": 0,
            "error_propagates": True,
        },
        "ERROR_HANDLER_CHAIN",
    )
    require(receipt["control_thread_stopped"] is True, "CONTROL_THREAD_ALIVE")
    expected_exit = 3 if mode == "startup_failure" else 0
    require(exit_code == expected_exit == receipt["exit_code"], "PROCESS_EXIT_CONTRACT")
    require(receipt["server_started"] is (mode != "startup_failure"), "SERVER_STARTED_STATE")
    require(receipt["control_stop_received"] is (mode != "startup_failure"), "CONTROL_STOP_STATE")
    fixture = json.loads((HERE / "fixture.json").read_text())
    presence = {key: marker in raw for key, marker in fixture.items()}
    expected_private = arm == "current" or (arm == "s9" and mode != "http")
    require(
        all(presence.values()) if expected_private else not any(presence.values()),
        "CANARY_CONTRAST",
    )
    require(
        not any(r.get("logger") == "uvicorn.access" for r in records), "ACCESS_CHANNEL_REOPENED"
    )
    errors = [r for r in records if r.get("level") in {"ERROR", "CRITICAL"}]
    require(len(errors) == 2, "ERROR_EVENT_COUNT")
    startup = any(
        r.get("logger") == "uvicorn.error" and r.get("message") == "Application startup complete."
        for r in records
    )
    shutdown = any(
        r.get("logger") == "uvicorn.error" and r.get("message") == "Application shutdown complete."
        for r in records
    )
    require(startup is (mode != "startup_failure"), "STARTUP_SUCCESS_EVENT")
    require(shutdown is (mode == "http"), "SHUTDOWN_SUCCESS_EVENT")
    if mode == "http":
        app_errors = [r for r in errors if r.get("logger") == "app.error"]
        server_errors = [r for r in errors if r.get("logger") == "uvicorn.error"]
        require(len(app_errors) == len(server_errors) == 1, "TWO_EXCEPTION_CHANNELS")
        support_id = "s9-support-" + name
        if arm == "current":
            require(app_errors[0]["message"] == "beklenmeyen hata", "CURRENT_APP_ERROR_EVENT")
            require(
                server_errors[0]["message"] == "Exception in ASGI application\n",
                "CURRENT_SERVER_ERROR_EVENT",
            )
            for event in errors:
                require(
                    all(
                        marker in json.dumps(event, ensure_ascii=False)
                        for marker in fixture.values()
                    ),
                    "CURRENT_EACH_CHANNEL_CANARY",
                )
        else:
            require(
                app_errors[0]["context"]
                == {"error_code": "internal_error", "request_id": support_id},
                "SUPPORT_ID_CONTEXT",
            )
            require(
                server_errors[0]["context"] == {"error_code": "asgi_application_error"},
                "SERVER_ERROR_CONTEXT",
            )
            for event in errors:
                require(
                    set(event) == {"ts", "level", "logger", "message", "context", "exception"},
                    "EXCEPTION_EVENT_SCHEMA",
                )
                check_frames(event, arm)
    else:
        require(all(r.get("logger") == "uvicorn.error" for r in errors), "LIFESPAN_ERROR_CHANNEL")
        phase = "startup" if mode == "startup_failure" else "shutdown"
        if arm in {"s9b", "s9c"}:
            require(
                [r.get("context") for r in errors]
                == [{"error_code": "uvicorn_error"}, {"error_code": f"application_{phase}_failed"}],
                "MINIMIZED_LIFESPAN_EVENTS",
            )
            require(
                all(set(r) == {"ts", "level", "logger", "message", "context"} for r in errors),
                "LIFESPAN_EVENT_SCHEMA",
            )
        else:
            require(
                all(marker in errors[0]["message"] for marker in fixture.values()),
                "LIFESPAN_RAW_CONTROL",
            )
            require(
                errors[1]["message"] == f"Application {phase} failed. Exiting.",
                "LIFESPAN_PHASE_EVENT",
            )
    request_events = [
        r
        for r in records
        if r.get("logger") == "app.request" and r.get("message") == "istek tamamlandı"
    ]
    require(
        len(request_events) == (0 if mode == "startup_failure" else 1), "REQUEST_COMPLETION_COUNT"
    )
    if request_events:
        context = request_events[0].get("context")
        require(
            set(context) == {"request_id", "method", "path", "status", "duration_ms"},
            "REQUEST_METADATA_SCHEMA",
        )
        require(
            context["request_id"] == "s9-health-" + name
            and context["path"] == "/health/live"
            and context["status"] == 200
            and context["method"] == "GET",
            "SAFE_REQUEST_METADATA",
        )
    return {
        "arm": arm,
        "scenario": name,
        "mode": mode,
        "protocol": protocol,
        "pid": pid,
        "port": port,
        "exit_code": exit_code,
        "seconds": round(seconds, 6),
        "responses": responses,
        "canary_presence": presence,
        "expected_private_control": expected_private,
        "two_error_channels_or_lifespan_events": len(errors),
        "startup_success_preserved": startup,
        "shutdown_success_preserved": shutdown,
        "configured_json_boundary": True,
        "receipt": receipt,
        "binding": binding,
        "log_sha256": {n: digest(directory / n) for n in ("stdout.log", "stderr.log")},
        "sidecar_sha256": {
            n: digest(directory / n) for n in ("binding.json", "configured.json", "receipt.json")
        },
    }


def run_one(out: Path, arm: str, name: str, mode: str, protocol: str) -> dict[str, Any]:
    directory = out / f"{arm}-{name}"
    directory.mkdir(mode=0o700)
    passfile = directory / "empty.pgpass"
    passfile.touch(mode=0o600, exist_ok=False)
    env = environment(HERE / "arms" / arm, passfile)
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(("127.0.0.1", 0))
    listener.listen(32)
    port = listener.getsockname()[1]
    control_read, control_write = os.pipe()
    proc = None
    responses = []
    started = time.monotonic()
    try:
        with (
            (directory / "stdout.log").open("x") as stdout,
            (directory / "stderr.log").open("x") as stderr,
        ):
            # Sabit Python/child yolu, sabit kol/senaryo, doğrulanan özel çıktı; shell yok.
            proc = subprocess.Popen(  # noqa: S603
                [
                    str(PYTHON),
                    str(HERE / "child.py"),
                    "--arm",
                    arm,
                    "--mode",
                    mode,
                    "--protocol",
                    protocol,
                    "--output",
                    str(directory),
                    "--socket-fd",
                    str(listener.fileno()),
                    "--control-fd",
                    str(control_read),
                ],
                cwd=directory,
                env=env,
                pass_fds=(listener.fileno(), control_read),
                stdout=stdout,
                stderr=stderr,
            )
            os.close(control_read)
            control_read = -1
            if mode == "startup_failure":
                deadline = time.monotonic() + 25
                while proc.poll() is None:
                    read_logs(directory)
                    require(time.monotonic() < deadline, "STARTUP_FAILURE_TIMEOUT")
                    time.sleep(0.02)
            else:
                deadline = time.monotonic() + 25
                while not (directory / "ready.json").exists():
                    require(proc.poll() is None, "CHILD_EXITED_BEFORE_READY")
                    read_logs(directory)
                    require(time.monotonic() < deadline, "READY_TIMEOUT")
                    time.sleep(0.02)
                require(
                    json.loads((directory / "ready.json").read_text())
                    == {"pid": proc.pid, "address": ["127.0.0.1", port]},
                    "OWN_LISTENER_READY",
                )
                responses.append(fetch(port, "/health/live", "s9-health-" + name))
                if mode == "http":
                    payload = json.dumps(
                        json.loads((HERE / "fixture.json").read_text()), separators=(",", ":")
                    ).encode()
                    responses.append(
                        fetch(port, "/__s9_probe__/error", "s9-support-" + name, payload)
                    )
                require(os.write(control_write, b"S") == 1, "CONTROL_PIPE_WRITE")
                os.close(control_write)
                control_write = -1
                proc.wait(timeout=12)
    finally:
        listener.close()
        if control_read >= 0:
            os.close(control_read)
        if control_write >= 0:
            os.close(control_write)
        if proc is not None and proc.poll() is None:
            # Hata/timeout temizliği yalnız bu Popen nesnesinin çocuğunu öldürür.
            # Bu yol bir başarılı deney olarak raporlanmaz.
            proc.kill()
            proc.wait(timeout=5)
    require(proc is not None, "CHILD_NOT_CREATED")
    return audit(
        directory,
        arm,
        name,
        mode,
        protocol,
        proc.pid,
        port,
        proc.returncode,
        responses,
        time.monotonic() - started,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    out = args.output
    require(out.parent == Path("/private/tmp/dou018-evidence"), "OUTPUT_PARENT")
    require(re.fullmatch(r"s9-process-[a-z0-9-]{1,40}", out.name) is not None, "OUTPUT_NAME")
    require(
        out.parent.resolve() == out.parent and not out.exists(), "OUTPUT_TARGET_EXISTS_OR_SYMLINK"
    )
    os.umask(0o077)
    manifest = verify_sources()
    out.mkdir(mode=0o700)
    report = {
        "status": "running",
        "results": [],
        "manifest_sha256": digest(HERE / "manifest.json"),
        "baseline_two_module_git": manifest["baseline_two_module_git"],
        "scope": (
            "synthetic exception induction; actual Uvicorn sockets and copied actual app, "
            "no DB/model/provider parity"
        ),
    }
    started = time.monotonic()
    exit_code = 2
    try:
        for arm in manifest["arm_order"]:
            for name, mode, protocol in SCENARIOS:
                report["active_case"] = {"arm": arm, "scenario": name}
                verify_sources()
                result = run_one(out, arm, name, mode, protocol)
                report["results"].append(result)
                write_json(out / f"{arm}-{name}" / "audit.json", result)
        for name, _mode, _ in SCENARIOS:
            selected = [r for r in report["results"] if r["scenario"] == name]
            require(len(selected) == len(manifest["arm_order"]), "PAIRED_ARM_COUNT")
            require(
                all(r["responses"] == selected[0]["responses"] for r in selected),
                "PAIRED_HTTP_CONTRACT_CHANGED",
            )
        verify_sources()
        report["status"] = "PASS"
        exit_code = 0
    except Exception as error:
        report["status"] = "FAIL"
        report["reason"] = (
            str(error) if isinstance(error, ProbeFailure) else "UNEXPECTED_PROCESS_CHECK_FAILURE"
        )
        report["error_type"] = type(error).__name__
    finally:
        try:
            verify_sources()
            report["source_unchanged"] = True
        except Exception:
            report["source_unchanged"] = False
            report["status"] = "FAIL"
            exit_code = 2
        report["seconds"] = round(time.monotonic() - started, 6)
        write_json(out / "result.json", report)
        print(json.dumps({"status": report["status"], "result": str(out / "result.json")}))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
