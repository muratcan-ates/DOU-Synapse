"""Root için sabit eski/aday kolları; DB/ağ/model/sunucu açmadan ASGI testleri.

Bu hazırlık sırasında çalıştırılmadı. Normal paket conftest'i yüklenmez ve
istem dışı DB/ağ denemesi assertion ile reddedilip sayaçta görünür.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import socket
import sys
from pathlib import Path

ROOT = Path("/Users/muratates/code/dou-synapse-018-codex-production-line")
HERE = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--arm",
        choices=["baseline", "candidate", "errors_only", "formatter_only"],
        required=True,
    )
    args = parser.parse_args()
    manifest = json.loads((HERE / "manifest.json").read_text())
    selected = {
        "logging": HERE
        / (
            "files/apps/api/app/core/logging.py"
            if args.arm in {"candidate", "formatter_only"}
            else "baseline/logging.py"
        ),
        "errors": HERE
        / (
            "files/apps/api/app/core/errors.py"
            if args.arm in {"candidate", "errors_only"}
            else "baseline/errors.py"
        ),
    }
    for path in selected.values():
        assert (
            hashlib.sha256(path.read_bytes()).hexdigest()
            == manifest["package_files"][str(path.relative_to(HERE))]
        )
    for relative, expected in manifest["current_import_source_sha256"].items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, (
            "Kaynak değişti; root açık yeniden bağlama yapmalı."
        )
    os.environ.update(
        ENVIRONMENT="local",
        DEV_AUTH_ENABLED="true",
        SUPABASE_JWT_SECRET="",
        LLM_FAKE_PROVIDER="true",
        EMBEDDING_PROVIDER="hashing",
        EVAL_RUNTIME_ENABLED="false",
        GROQ_API_KEY="",
        GEMINI_API_KEY="",
        OPENAI_API_KEY="",
        PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / "apps/api"))
    import app.core
    import psycopg
    import pytest

    attempts = {"db": 0, "network": 0}

    def no_database(*args, **kwargs):
        attempts["db"] += 1
        raise AssertionError("Bu çalıştırıcı DB bağlantısı yapmaz.")

    def no_network(*args, **kwargs):
        attempts["network"] += 1
        raise AssertionError("Bu çalıştırıcı ağ bağlantısı yapmaz.")

    psycopg.Connection.connect = no_database
    psycopg.AsyncConnection.connect = no_database
    socket.create_connection = no_network
    socket.socket.connect = no_network
    socket.socket.connect_ex = no_network

    for name, path in selected.items():
        full_name = "app.core." + name
        spec = importlib.util.spec_from_file_location(full_name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[full_name] = module
        setattr(app.core, name, module)
        spec.loader.exec_module(module)
    result = pytest.main(
        [
            "--noconftest",
            "-p",
            "no:cacheprovider",
            "-p",
            "pytest_asyncio.plugin",
            "-o",
            "asyncio_mode=auto",
            "-o",
            "asyncio_default_fixture_loop_scope=function",
            "-q",
            str(HERE / "files/apps/api/tests/test_exception_log_privacy.py"),
        ]
    )
    print(
        json.dumps(
            {
                "version": "s9-no-db-01",
                "arm": args.arm,
                "pytest_exit": int(result),
                "attempts": attempts,
            }
        )
    )
    assert attempts == {"db": 0, "network": 0}
    return int(result)


if __name__ == "__main__":
    raise SystemExit(main())
