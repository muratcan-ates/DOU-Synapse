# S9 aday — beklenmeyen hata günlüklerinde içerik azaltma

8 Eylül 2026. **Kaynak incelemesi ve geçici aday hazırlığıdır.** Repo düzenlenmedi; DB, ağ, model, sunucu veya pytest çalıştırılmadı. Aşağıdaki sonuçlar çalışmış bir saldırı/test veya üretim kabulü değildir. Kullanıcının teknik güvenlik geliştirme yetkisi kapsamında `dou-synapse-role-security` ve `references/privacy-lifecycle.md` uygulandı. Yasal uygunluk sertifikası veya saklama/hukuki sebep kararı verilmez.

## Somut bulgu ve önkoşul

**HTTP500 hata nesnesi uygulama ve sunucu günlüklerine iki kanaldan taşınır.** `apps/api/app/core/errors.py:258–267`, sabit öğrenci yanıtı üretirken `exc_info=exc` ile gerçek hatayı `app.error` logger'ına verir. `core/logging.py:89–90` bunu `formatException()` ile metne çevirir. Bu metin hata mesajı, açık cause/örtük context zinciri, notes, ExceptionGroup üyeleri, dosya adları ve kaynak satırlarını içerebilir. Mevcut regex'ler keyfi öğrenci yanıtını veya her URL/query/opaque-token biçimini tanımaz.

Kurulu Starlette `middleware/errors.py:164–187`, güvenli500 yanıtından **sonra aynı hatayı tekrar yükseltir**. Uvicorn `protocols/http/h11_impl.py:415–423` ve `httptools_impl.py:421–432`, `Exception in ASGI application` sabit mesajı ve aynı `exc_info` ile ikinci kayıt üretir. `configure_logging()` Uvicorn handler'larını temizleyip root'a propagate ettirdiği için bu ikinci kayıt da mevcut JSON formatter'dan geçer. S8 yalnız `uvicorn.access` kanalını kapattı; hata kanalı bilinçli olarak açık.

Önkoşul, bir hatanın öğrenci içeriğini/istek URL'sini/başlığını/sağlayıcının yansıttığı veriyi taşımasıdır. Bu kayıt alanı kaynak düzeyinde doğrulanmıştır; her gerçek API rotasında kimliksiz uzaktan tetiklenebildiği iddia edilmez. Hazırlanan sentetik endpoint, böyle bir bağımlılık/uygulama hatasını üretip gerçek main/Starlette500 yolunu sınar. Log saklama, erişim ve başka hizmete aktarım koşulları ayrıca bilinmiyor.

Mevcut uygulamadaki dört `logger.exception` çağrısı da tarandı: `errors.py`, `core/warmup.py:100`, `modules/assessment/grading.py:492`, `question_gen.py:661`. Hepsi sabit mesaj kullanıyor; doğrudan `str(exc)`/`exc` argümanı eklemiyor. Ancak değerlendirme ve soru üretiminde completion hatası serbest sağlayıcı metni taşıyabilir. **Sadece handler mesajını sabitlemek veya yalnız regex eklemek bu kanalı kapatmaz.**

## Minimal üretim adayı

Yalnız iki üretim dosyası ve yeni odak test dosyası var:

- `files/apps/api/app/core/logging.py`: `exc_info` bulunan kayıt ayrı, izinli bir JSON şeması kullanır. `formatException`, `str(exc)`, `repr`, cause/context/notes/group üyeleri, locals ve kaynak satırı okunmaz. Mesaj ve olay kodu mevcut sabit çağrı şablonlarından seçilir; tanınmayan mesaj/logger için sabit fallback vardır. `msg`, `args`, keyfi `extra/context`, `exc_text`, `stack_info` aynı veriyi yeniden taşıyamaz. Normal, exception içermeyen mesajların mevcut redaction/JSON davranışı korunur.
- İstisna özeti yalnız sabit built-in `error_type`, en fazla8 uygulama frame'i ve `frames_truncated` taşır; tarama en fazla64 traceback düğümü. Dış hata sınıfının keyfi ismi yerine `Exception` kullanılır. Frame alanları yalnız uygulama kökünün izinli paketlerinde mevcut `.py` dosyası, kaynak AST'sinde gerçekten bulunan işlev adı ve geçerli satır numarasıdır. Mutlak host path, dış modül path'i, bulunmayan/uydurulmuş işlev veya kaynak satırı taşınmaz. AST yalnız ad listesi için okunur, kod yürütmez; en fazla128 dosyalık süreç önbelleği vardır. Dağıtılan kaynak değişince normal süreç yeniden başlatması varsayılır.
- `files/apps/api/app/core/errors.py`: aynı genel500 zarfı/status korunur. Handler aynı `request_id`yi bir kez seçip hem içeriksiz kayda hem yanıta bağlar; sabit `internal_error` olay kodu ekler. Exception nesnesi mesaj/args/context içine konmaz. `main.py`, Starlette yeniden-yükseltmesi ve Uvicorn error logger'ının açık kalması değiştirilmez.

Yeni exception JSON alanı string trace yerine nesnedir. Bu operasyonel günlük şeması değişikliğidir; varsa dış log tüketicileri root tarafından gözden geçirilmelidir. Logdan serbest provider hata metnini kaldırmak bilinçli teşhis daralmasıdır; olay kodu, destek kimliği ve izinli kaynak konumu kalır.

## Root için sentetik yeniden üretim ve kabul

`files/apps/api/tests/test_exception_log_privacy.py` **18 parametrik vaka** içerir; hazırlanmıştır, çalıştırılmamıştır. İlgili sınırlar:

1. Generic handler'a öğrenci cevabı, URL'deki opaque token, cause, notes ve ExceptionGroup gönder; yayımlanan JSON'da canary yok,500 gövdesi hâlâ aynı sabit Türkçe mesaj ve request_id olsun.
2. Aynı hatayı `msg`, biçimlendirme args, Exception argümanı, keyfi extra/context, önceden biçimlendirilmiş `exc_text/stack_info` alanına koy; gerçek handler/formatter çıktısında hepsi kaybolmalı. Filtreyi atlayıp formatter'ı doğrudan kullanmak aynı içeriksiz sınırı korumalı.
3. `__str__` çağrılırsa hata veren exception ve canary içeren dinamik sınıf adı; güvenli kayıt için metin biçimlendirmesi gerekmemeli, keyfi tür adı çıkmamalı.
4. İçinde canary bulunan gerçek sentetik uygulama kaynak satırı; JSON yalnız `core/synthetic.py`, `sentinel`, satır2 taşırken dosyanın mutlak temp yolu/satır metni taşınmasın. Uydurulmuş dış co_filename ve kaynakta olmayan co_name düşürülsün.100 seviyeli traceback tarama/çıktı sınırına uysun.
5. Gerçek `uvicorn.Config` logger kurulumu ardından projenin `configure_logging()` çağrısı: uvicorn.error ve uvicorn parent handler'ları boş, root'a propagate, root'ta tek JsonFormatter olmalı. Startup INFO mesajı korunurken aynı server error kaydının canary'si çıkmamalı. Config oluşturmak server/socket çalıştırmaz.
6. Gerçek `main.create_app()` üstüne yalnız test içinde sentetik POST endpoint eklenir. Gövde/query/header içeriği hata/cause/notes içine girer. Gerçek Starlette500 ve yeniden-yükseltme yürür; dış ASGI test sınırı aynı sabit Uvicorn logger çağrısını yapar. Her kanalda birer ERROR, sabit500 yanıtı, aynı destek kimliği ve sıfır canary aranır. **Bu son dış sınır gerçek Uvicorn ağ sunucusu değildir; ayrı server ölçümü gerekir.**

`run_no_db_tests.py`, yalnız dört sabit kolu yükler; repo dosyalarını değiştirmez. Normal conftest kapalı, mevcut pytest-asyncio eklentisi açık, gerçek psycopg sync/async ve socket bağlantıları reddedilip sayılır. Sahte sağlayıcı/boş anahtarlar, EVAL_RUNTIME kapalı; ASGITransport lifespan açmaz. Root önce eski ve adayı ayrı stdout/stderr/sonuç dosyalarına yönlendirerek koşabilir:

```text
python run_no_db_tests.py --arm baseline
python run_no_db_tests.py --arm candidate
python run_no_db_tests.py --arm errors_only
python run_no_db_tests.py --arm formatter_only
```

Bu komutlar **bu hazırlıkta çalıştırılmadı**. Başarısız testte canary/ham sentetik trace pytest çıktısında görünebilir; bunlar yalnız sentetik değerlerdir. Doğal beklenen ayrım:

- Eski iki dosya, yayımlanan özel değer oracle'larında kırmızı kalmalı.
- Yalnız errors.py düzeltmesi, eski formatter ve dış Uvicorn kanalındaki sızıntı nedeniyle kırmızı kalmalı.
- Yalnız formatter düzeltmesi, veri azaltmasını sağlayabilir; handler'ın log/yanıt destek kimliği kontratı henüz eksik kalabilir. Bu kontrolün her testte kırmızı olması gerekmiyor; test bazında gerçek sonuç saklanır.
- Birleşik aday aynı somut oracle'ları geçmeli. `xfail`, beklenen AssertionError'ı yakalayıp başarıya çevirme veya eski sonucu yeniden adlandırma yoktur.

Ardından root, S8 gerçek Uvicorn v2 deneyinin **ayrı** kopyasında aynı eski/aday source binding ve private-pipe normal kapanış protokolünü kullanabilir: fake/local ayarlar, sıcak başlama kapalı, DB guard0, yalnız inherited127.0.0.1 socket, startup ready sonrasında canary POST→500, health→200. Tam stdout ve stderr yakalanmalı; eski kaynakta her iki exception kanalı canary üretmeli, adayda her ikisi de içeriksiz kalmalı. Gerçek pid/HTTP yanıtı/normalexit0, sourcehash, request_id, root handler yapılandırması ve uvicorn.error startup/shutdown mesajlarının korunması kaydedilmeli. Genel hata zarfı ve eski S8 request/access-log testleri tekrar korunmalı. Root gerçek ölçümden sonra .ai/ledger/bulgu kaydını kendi sahipliğinde günceller.

Runner manifest'i mevcut main/config/db gibi ortak import kaynaklarına da bağlıdır; OPS veya başka iş bu kaynakları değiştirirse otomatik kabul etmez. Root yeni ortak kaynakları inceleyip **ayrı ölçüm manifestinde** yeniden bağlamalıdır. Geçici formatter dosyası kendi app kökünü kullanır; bu saf overlay deneyi üretimdeki tüm frame kökünü temsil etmez. Metadata kuralları sentetik gerçek kaynak dosyalarıyla sınanır; son stage/gerçek server koşusunda kaynakların aynı uygulama ağacına kurulması daha güçlü kanıttır.

## Açık ve özellikle korunmuş sınırlar

- **Lifespan düz metin yolu açık:** kurulu Starlette `routing.py:646–653` traceback'i `message['message']` içine string olarak koyar; Uvicorn `lifespan/on.py:115–135` bunu `exc_info` olmadan `logger.error(message)` ile yayımlar. Bu adayın exception nesnesi dalı onu yakalamaz. Ayrı startup/shutdown sınırı düzenlemesi/testi gerekir. Uvicorn error kanalını tümden kapatmak teşhisi yok edeceği için yapılmadı.
- `exc_info` olmayan keyfi mesaj/args/context veya sonradan bağlanan başka handler/harici process/proxy/hosting günlükleri için bütün içerik sızıntıları kapandı iddiası yoktur. Regex maskelerinin kapsamı genişletilmedi ve kusursuz redaction iddiası yapılmaz.
- `X-Request-ID` bugün izinli karakterlerle istemciden gelebilir; ilişkilendirilebilir ve özel değer taşıyabilir. Bu önceki S8 açık sınırıdır. S9 bu sözleşmeyi sessizce değiştirmez ve günlükleri “anonim” diye adlandırmaz.
- AppError'ın kullanıcıya gösterilebilir mesajları, validation alan etiketleri, cevap içerikleri, veri erişimi/RLS, auth hesap silme ve saklama politikaları bu patch ile yeniden tasarlanmaz.
- Kurulu framework kaynaklarının hashleri kaydedilir; sürüm değişiminde gerçek yeniden-yükseltme/handler davranışı tekrar doğrulanmalı. Test hazırlığı gerçek PG, provider, üretim dağıtımı veya yasal kabul değildir.
