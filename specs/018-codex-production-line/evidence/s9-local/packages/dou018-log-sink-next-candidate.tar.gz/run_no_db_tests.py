"""Source-bound S9B/S9C offline comparison; execution belongs to the root agent."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path("/Users/muratates/code/dou-synapse-018-codex-production-line")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str, path: Path) -> object:
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=("baseline_s9b", "candidate_s9c"), required=True)
    arm = parser.parse_args().arm
    manifest = json.loads((HERE / "manifest.json").read_text())
    for relative, expected in manifest["package_files"].items():
        assert digest(HERE / relative) == expected, "S9C candidate file binding changed"
    for absolute, expected in manifest["import_source_sha256"].items():
        assert digest(Path(absolute)) == expected, "S9C import source binding changed"
    selected = HERE / (
        "baseline/logging.py" if arm == "baseline_s9b" else "files/apps/api/app/core/logging.py"
    )
    errors_source = Path(manifest["errors_source_path"])
    os.environ.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / "apps/api"))
    import psycopg
    import pytest
    import app.core

    attempts = {"db": 0, "network": 0}

    def no_database(*args, **kwargs):
        attempts["db"] += 1
        raise AssertionError("S9C offline test attempted a database connection")

    def no_network(*args, **kwargs):
        attempts["network"] += 1
        raise AssertionError("S9C offline test attempted a network connection")

    psycopg.Connection.connect = no_database
    psycopg.AsyncConnection.connect = no_database
    socket.create_connection = no_network
    socket.socket.connect = no_network
    socket.socket.connect_ex = no_network
    app.core.logging = load("app.core.logging", selected)
    app.core.errors = load("app.core.errors", errors_source)
    code = pytest.main([
        "--noconftest", "-p", "no:cacheprovider", "-p", "pytest_asyncio.plugin",
        "-o", "asyncio_mode=auto", "-o", "asyncio_default_fixture_loop_scope=function",
        "-q", str(HERE / "files/apps/api/tests/test_log_sink_privacy.py"),
    ])
    print(json.dumps({
        "version": "s9c-offline-01",
        "arm": arm,
        "pytest_exit": int(code),
        "attempts": attempts,
        "selected_logging_sha256": digest(selected),
        "errors_source_sha256": digest(errors_source),
        "manifest_sha256": digest(HERE / "manifest.json"),
        "application_main_loaded": "app.main" in sys.modules,
    }))
    assert attempts == {"db": 0, "network": 0}
    assert "app.main" not in sys.modules
    return int(code)


if __name__ == "__main__":
    raise SystemExit(main())
