# S9C — private-data-safe failure of the owned logging handler

Prepared 8 September 2026; **not executed**. No repository, S9/S9B package or existing evidence was changed. No pytest, module import, database, network, server, provider or dependency installation was run during preparation. Text-only source/AST inventory and file hashes are preparation, not runtime proof.

This is a narrow delta over the frozen S9B formatter. `baseline/logging.py` is an exact S9B copy. S9's frozen `errors.py` is reused by path/hash for response tests and is not edited. `s9b-to-s9c.patch` applies over S9B, not independently to the old repository logging module.

## Problem and change

`/private/tmp/dou018-s9-independent-review.md` records the concrete P2 boundary: standard StreamHandler handles output/formatter failures by calling `handleError`, which defaults to a stderr traceback and raw Message/Arguments diagnostic. A safely projected S9B lifespan error still retains its private original record; a subsequent sink failure can print that original to stderr.

Only the configured root handler class changes. The ordinary formatter, filter, event schema, source metadata allowlist, known errno/task-count diagnostics and logger/channel configuration remain S9B behavior. No global `logging.raiseExceptions` switch is changed and no additional external handler is modified.

`PrivacySafeStreamHandler` retains format → stream.write → flush for a normal record. An ordinary Exception during those operations produces at most one fixed ASCII JSON line directly through stderr:

```json
{"level":"ERROR","logger":"app.logging","message":"log emission failed","context":{"error_code":"logging_output_failed"}}
```

No original record, error, args, exception text, source path, request ID or timestamp is inspected to build the fallback. The fallback neither invokes another logger nor flushes another stream. If its single write also raises an ordinary Exception, it returns without a third output path. Both emission and fallback have guards against recursive entry into this same owned handler. The existing Handler lock serializes normal calls; reentrant calls from that handler's sink/formatter are dropped, which is preferable to unbounded recursive logging during failure.

KeyboardInterrupt and SystemExit (and other BaseException process-control signals) deliberately propagate from format/write/flush/fallback, with guards reset by finally. An ordinary logger-raised RecursionError is treated as an emission failure so it cannot replace the generic application500 envelope. This does not guarantee recovery after true interpreter stack/memory exhaustion. Arbitrary filters, third-party handlers and custom in-process Python hooks remain separate trust boundaries; this is not a sandbox for hostile code.

If stdout is broken, that original event may be lost: the fixed marker is a logging-failure signal, not a replacement for the original diagnostic. If stderr is also broken, no output is promised. External log consumers must tolerate the deliberately minimal fallback schema without ts/exception fields. Normal startup, shutdown and known server-error events remain available whenever the main sink works.

## Prepared 27-case offline suite

- Six paired write/flush/formatter failures for plain Uvicorn and exc_info records, with raw stdout and stderr canary scans.
- Three failures of the fallback itself, each requiring exactly one fallback attempt and no escaping ordinary exception.
- One bounded reentrant fallback case. The old arm is also bounded by its fixture; this is not a recursive stress/OOM test.
- Eight tests of the actual S9 generic500 handler under write/flush/formatter/formatter-RecursionError failures, with healthy or broken fallback. The unchanged status, generic body, code and exact support ID are checked. These call the real shared handler directly; they do not claim a real HTTP listener or the complete main/Uvicorn error boundary.
- Six KeyboardInterrupt/SystemExit tests at write, formatter and fallback. Each checks the identical control exception propagates and that the handler can emit a later known event if the test catches that signal.
- One local unprintable-object robustness check for both str/repr. This does not claim a remote student can construct Python objects.
- Two normal-event tests with logging.raiseExceptions initially false/true, verifying it stays unchanged and normal INFO/WARNING/ERROR output and the server error channel remain available.

The same assertions run on old S9B and S9C. Existing S9/S9B tests are not copied or weakened; root should run their full 18+35 contracts against the integrated final formatter separately. Expected old-arm failures must occur at privacy/response/boundedness assertions, not fixture/import/hash errors. This candidate's 27 cases have not yet run.

## Root execution

The standalone runner uses no repository conftest, only pytest-asyncio, and a source-pinned overlay in its own process. It imports the selected formatter plus frozen S9 errors, not app.main, Settings, LLM, embedding or a worker. It rejects/counts psycopg sync/async and socket connection calls. Those counters are additional controls for this narrow test inventory, not an operating-system sandbox for arbitrary libraries.

Run each arm in a separate root-owned private output directory with full stdout/stderr retained, using the existing API environment:

```text
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-log-sink-next-candidate/run_no_db_tests.py --arm baseline_s9b
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-log-sink-next-candidate/run_no_db_tests.py --arm candidate_s9c
```

The baseline uses the same frozen S9 errors source so the changed variable is only logging.py. Both arms must report DB/network attempts zero and application_main_loaded false. Preserve each selected-source hash, manifest hash and actual pytest outcome; do not relabel prepared tests as passed. A stale source binding requires root's explicit separate receipt/rebind decision, not editing the frozen original package.

The root's separate actual-process harness remains necessary for main/Starlette/Uvicorn500, lifecycle errors and healthy shutdown. A real sink-failure scenario should capture stdout and stderr separately and distinguish intentional sink loss from missing output. A safe fallback must not be mistaken for successfully delivered ordinary logs. No production, all-handler privacy, legal compliance or hosted-CI acceptance is claimed here.
