# S10 gerçek PG audit kabul adayı

Durum: yalnız hazırlık; **test, DB, HTTP, Bun, uygulama veya helper yürütülmedi**. Python AST parse dışında çalışma kanıtı yoktur. Root, kendi provision ettiği sentetik DB'de ve önceki owned API durduktan sonra bu paketi çalıştırır. Paket repo/özgün aday kaynaklarını düzenlemez.

## Güven ve dosya bağı

Hedef root'un açıkça tahsis ettiği `/private/tmp/dou018-evidence/s10-e2e-provision-01/pins.json` kaydıdır: numeric `127.0.0.1:55448`, DB `dou018_s10_e2e_01`, OID `1878520`, cluster `7683042491268153327`, mevcut DBA `muratates`, API origin `http://127.0.0.1:8019`. Tek başlangıç audit satırı, root'un eklediği `9b395d62-87b4-4fa1-870f-fea5b5fd4255` kaydı olmalıdır. A/B ve korunan P aynı sentetik AYSE aktörüdür; P'nin aktörü doğrudan salt okunur SELECT ile tekrar doğrulanır, hücre değeri rapora eklenmez.

Bu hedefe çalışma yetkisi JSON'un varlığından/SHA'sından çıkarılmaz: root'un tahsis ve bağımsız provisioning ölçümü temelidir. Manifest yalnız o açık yetkinin exact hedef ve kaynak bağını taşır. Başka DB'ye yöneltmek için dosyaya rastgele yeni OID yazmak yeterli değildir; yeni root tahsisi ve yeni aday gerekir. Aynı adı taşıyan yeniden oluşturulmuş DB de OID farkında reddedilir. Başlangıçta P dışında satır varsa runner bunu temizlemeye çalışmaz ve durur.

`repo_runtime_sha256` bütün gerçek uygulama Python kaynaklarıyla guard/owned adapter ve üç web helper dosyasını sabitler. Bun, birebir kopyalanmış `AuditCapture`, `temizle`, `fixtures` dosyalarını kullanır. Stub, SQL modeli veya collector taklidi kullanılmaz. API gerçek repodaki `run_owned_e2e.py --serve-owned` yolu ile başlar; hazır olma ve kapatma da aynı modülün helper'larıdır. Root'un son adapter/collector düzeltmeleri manifestteki hash ile uyuşmalıdır.

## Çalıştırma

API Python ortamıyla, henüz var olmayan özel sonuç dizini kullanılır:

```sh
/Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python \
  /private/tmp/dou018-s10-db-audit-candidate/run.py \
  --repo /Users/muratates/code/dou-synapse-018-codex-production-line \
  --pins /private/tmp/dou018-evidence/s10-e2e-provision-01/pins.json \
  --pins-sha256 '<manifestteki authorized_pins_sha256>' \
  --passfile /private/tmp/dou018-evidence/s10-e2e-provision-01/empty.pgpass \
  --bun /Users/muratates/.bun/bin/bun \
  --pg-bin /opt/homebrew/opt/postgresql@16/bin \
  --output /private/tmp/dou018-s10-db-audit-result-01 \
  --execute
```

`--execute` yoksa yalnız plan yazılır. PSQL yolu, DB host/hostaddr/port/role/passfile açık verilir; ortam yönlendirmesi ve provider sırları aktarılmaz. Mevcut app/worker yerel fixture rolleri owned adapter'dan gelir; rol/parola/GRANT/RLS değişikliği yoktur. Gerçek API yalnız local auth, hashing embedding ve fake provider ayarlarıyla çalışır. SQL bağlantı3s/statement5s/lock2s; kontrol ack30s ve own child kapatma süreleri sınırlıdır. Ready helper'ın mevcut bounded beklemesi korunur; istek sırasını kurmak için `sleep` kullanılmaz.

## Faz 1: interleaved A/B ve temizlik reddi

1. Root Python gerçek guard `begin` ile A ve B için ayrı private collector scope/baseline oluşturur. Target aynı, runId farklıdır; iki baseline da P'ye eşit olmalı.
2. Parent tam portu önce bind eder, listening FD'yi kendi API child'ına verir. Başka servisin health yanıtı kabul edilemez. Kalıcı Bun child başlar; komutlar yeni nonce ve kesin sıra ile stdin/stdout JSON üzerinden doğrulanır. Serbest cleanup logları özel stderr'e gider, ack diye yorumlanmaz.
3. Gerçek `AuditCapture.fetch` sırası **A1 → B1 → A2 → B2**. Her HTTP200 ve gövde tamamlandıktan sonra child ack verir; root Python yeni salt okunur tam audit snapshot'ını alır. Her aşama önceki tüm rowID/hashleri koruyup tam bir yeni UUID eklemeli. Bu deterministik interleaving'dir; aynı anda iki bağımsız HTTP isteğinin yürütüldüğü iddiası değildir.
4. P∪A∪B noktasında capture'lar henüz `finish()` görmemiştir. Gerçek `temizle(onayli:true, A)` tam `INCOMPLETE_CAPTURE` sebebiyle reddedilmeli. Yanlış target scope ile aynı işlem `WRONG_SCOPE` sebebiyle reddedilmeli. İki denemeden sonra tüm rowID→fullSHA haritası P∪A∪B ile aynı olmalıdır. Kaynakta bu kontroller ilk psql çağrısından önce gerçekleşir; gerçek gözlem satırların değişmediği ve doğru hatanın geldiğidir, DB statement tracing yapıldığı iddia edilmez.
5. A/B `finish()` sonrası her collector tam iki makbuz taşımalı. Önce dry-run kendi runId'sinde sıfır ders doğrular, sonra özgün `temizle(onayli:true)` çalışır. A temizliği tam A1/A2 UUID'lerini silmeli ve sonuç P∪B olmalı; B temizliği tam B1/B2'yi silmeli ve sonuç P olmalı. Aynı aktörün P ve diğer koşu kayıtları tam içerik hashleriyle korunmalıdır.
6. Bun explicit sonuç yazıp exit0 verir. Root kendi API'sine adapter'ın özel pipe'ından durma isteği gönderir ve gerçek wait sonucunu alır. Yalnız `graceful-pipe-and-wait` + exit0 kabul edilir. Ardından A ve B'nin gerçek guard `finish` çağrıları exit0/PASS ve tam P haritası vermelidir.

## Faz 2: collector dışı gerçek yanıt

Faz 1 kapanıp A/B hesapları tamamlandıktan sonra ayrı O baseline ve yeni owned API child'ı oluşturulur. Tek HTTP200 `/admin/overview` yanıtı ve gövdesi gerçek transportla tamamlanır; bu defa collector `begin/record` çağrıları bilinçli yapılmaz. Boş capture `finish()` olur, gerçek temizle 0 makbuz/0 silme sonucu verir. Python snapshot tam bir yeni O UUID'sini bulmalıdır.

Sonra Bun explicit exit0, API gerçek graceful pipe+wait exit0. Guard `finish` **exit1/FAIL** vermeli; missing/changed baseline sıfır, `unexpectedNewRows` tam O UUID→SHA, `deleteExecuted:false` olmalıdır. Guard sonrasında bağımsız salt okunur snapshot yine P∪O'yu göstermelidir. Bu beklenen guard başarısızlığı, deneyin PASS koşuludur. O satırı otomatik silinmez; sonraki DB kullanımı için root ayrı karar verir. Runner'ın P'yi değiştiren, kaybolmuş baseline'ı yeniden ekleyen veya toplu audit temizleyen kurtarma yolu yoktur.

## Kanıtlar ve sınırlar

- Her ara snapshot bütün audit satırlarının UUID→kanonik tam satır SHA'sıdır; hücre içerikleri/kişisel metin tekrar dökülmez. HTTP response yalnız server requestId, status, body byte sayısı ve bodySHA ile kaydedilir.
- Guard'ın `playwrightExitCode` adlı mevcut alanı burada controlled Bun driver'ın gerçek exit kodunu taşır. Yan sidecar/phase kaydı driver'ı açıkça tanımlar; bu koşu Playwright veya tam E2E çalışması değildir.
- Her faz own API PID, gerçek exit, stop şekli, Bun ack/sonuç, stdout/stderr ve kaynak önce/son hashleri saklanır. Tüm çıktı yeni0700/0600 dizinde; var olan kanıtın üzerine yazılmaz. Fail halinde ilgili API/child'lar yalnız kendi sahip olunan süreçleri olarak durdurulur, satırlar bırakılır.
- Korunan P'yi UPDATE/DELETE eden baseline mutantı ve geniş-fallback cleanup mutantı bu dar dilimde yoktur. Bunlar ayrı fresh hedefte hazırlanmalı; P'yi deney içinde eski varsayılan değerlere döndürme yapılmaz.
- Snapshot eşliği bütün audit statement girişimlerini veya başka tablolarda hiç yazı olmadığını kanıtlamaz. Asıl kontrol exact makbuz silmesinin başka koşuya ve P'ye etkisi ile global omitted kalıntının yakalanmasıdır. Gerçek model, hosting, üretim/KVKK/GDPR sertifikasyonu iddiası yoktur.
