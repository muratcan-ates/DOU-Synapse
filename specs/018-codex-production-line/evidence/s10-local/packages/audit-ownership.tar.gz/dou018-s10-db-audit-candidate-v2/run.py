"""Root'un önceden provision ettiği tek sentetik hedefte üç gerçek audit kabulü.

Varsayılan plan. Kaynaklar ve hedef pinleri doğrulanmadan süreç/DB/HTTP başlamaz.
Yalnız özgün temizle yolu A/B makbuzlarını siler; omitted satır özellikle korunur.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import queue
import re
import signal
import socket
import subprocess
import sys
import threading
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4

PACKAGE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value: bool, code: str) -> None:
    if not value:
        raise RuntimeError(code)


def write(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def copy_tree(source: Path, target: Path) -> None:
    target.mkdir(mode=0o700)
    for path in sorted(source.rglob("*")):
        destination = target / path.relative_to(source)
        require(not path.is_symlink(), "SOURCE_SYMLINK")
        if path.is_dir():
            destination.mkdir(mode=0o700)
        else:
            with destination.open("xb") as stream:
                stream.write(path.read_bytes())


class ControlledBun:
    """Tek own child'ın JSON kanalını nonce ve kesin faz sırasıyla okur."""

    def __init__(self, executable: Path, work: Path, config: Path, env: dict[str, str], directory: Path):
        self.lines: queue.Queue[bytes] = queue.Queue(maxsize=32)
        self.output = (directory / "control.jsonl").open("xb")
        self.error = (directory / "bun.stderr.txt").open("xb")
        self.process = subprocess.Popen([str(executable), str(work / "exercise.ts"), str(config)],
            cwd=work, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=self.error, start_new_session=True)

        def read() -> None:
            while True:
                line = self.process.stdout.readline(4097)
                if not line:
                    self.lines.put(b"")
                    return
                self.output.write(line)
                self.output.flush()
                if len(line) > 4096 or not line.endswith(b"\n"):
                    self.lines.put(b'{"event":"invalid_control_line"}\n')
                    return
                self.lines.put(line)

        self.reader = threading.Thread(target=read, daemon=True, name="s10-owned-bun-control")
        self.reader.start()

    def receive(self) -> dict[str, object]:
        line = self.lines.get(timeout=30)
        require(bool(line), "BUN_CONTROL_EOF")
        result = json.loads(line)
        require(type(result) is dict, "BUN_CONTROL_SCHEMA")
        return result

    def command(self, value: str) -> dict[str, object]:
        nonce = uuid4().hex
        self.process.stdin.write((json.dumps({"command": value, "nonce": nonce}) + "\n").encode())
        self.process.stdin.flush()
        result = self.receive()
        require(set(result) == {"event", "nonce", "command", "detail"} and result["event"] == "ack"
            and result["nonce"] == nonce and result["command"] == value, "BUN_COMMAND_ACK")
        return result["detail"]

    def finish(self) -> int:
        self.process.stdin.close()
        return self.process.wait(timeout=15)

    def close(self) -> None:
        if self.process.poll() is None:
            # Yalnız bu Popen'ın yeni oluşturulmuş process group'u; psql child
            # dâhil kendi deneyine aittir. Başka PID/port/process adı taranmaz.
            os.killpg(self.process.pid, signal.SIGTERM)
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(self.process.pid, signal.SIGKILL)
                self.process.wait(timeout=10)
        self.reader.join(timeout=2)
        require(not self.reader.is_alive(), "BUN_CONTROL_READER_NOT_STOPPED")
        self.output.close()
        self.error.close()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--pins", required=True, type=Path)
    parser.add_argument("--pins-sha256", required=True)
    parser.add_argument("--passfile", required=True, type=Path)
    parser.add_argument("--bun", required=True, type=Path)
    parser.add_argument("--pg-bin", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"status": "PLAN", "actual_api_phases": 2, "DB_HTTP_process_started": False}))
        return 0
    os.umask(0o077)
    manifest = json.loads((PACKAGE / "manifest.json").read_text())
    for name, expected in manifest["files"].items():
        require(sha(PACKAGE / name) == expected["sha256"], "PACKAGE_SOURCE_HASH")
    repo = args.repo.resolve(strict=True)
    for name, expected in manifest["repo_runtime_sha256"].items():
        require(sha(repo / name) == expected, "INTEGRATED_SOURCE_HASH")
    require(args.pins_sha256 == manifest["authorized_pins_sha256"], "ROOT_AUTHORIZED_PINS_SHA")
    require(args.bun.is_absolute() and args.bun.is_file() and args.pg_bin.is_absolute()
        and (args.pg_bin / "psql").is_file(), "EXPLICIT_LOCAL_TOOLS")
    output = args.output
    require(output.is_absolute() and output.resolve() == output and not output.exists(), "NEW_PRIVATE_OUTPUT_REQUIRED")
    output.mkdir(mode=0o700)
    sys.path.insert(0, str(repo / "scripts"))
    import e2e_audit_guard as guard
    import run_owned_e2e as owned
    require(owned.guard is guard, "SINGLE_GUARD_MODULE")
    pins = guard.read_pins(args.pins, args.pins_sha256)
    require(pins == manifest["authorized_pins"], "ROOT_AUTHORIZED_TARGET")
    protected = manifest["protected_audit_id"]
    run_prefix = "s10" + uuid4().hex[:12]
    before_sources = owned.source_hashes(repo)
    write(output / "source-before.json", before_sources)
    result: dict[str, object] = {
        "status": "FAIL", "package_manifest_sha256": sha(PACKAGE / "manifest.json"),
        "target": {"databaseOid": pins["databaseOid"], "cluster": pins["cluster"]},
        "protected_audit_id": protected, "phases": {},
        "scope": "actual local PG/API + original collector/cleanup; no Playwright, provider, hosting or legal-compliance claim",
        "automatic_omitted_row_delete": False,
    }

    def snapshot(path: Path) -> dict[str, str]:
        rows = guard.snapshot(pins, args.passfile)
        write(path, {"rows": rows})
        return rows

    def guard_call(directory: Path, run_id: str, phase: str, quiescence: Path | None = None) -> int:
        argv = [sys.executable, str(repo / "scripts/e2e_audit_guard.py"), "--pins", str(args.pins),
            "--pins-sha256", args.pins_sha256, "--passfile", str(args.passfile),
            "--directory", str(directory), "--run-id", run_id, "--phase", phase, "--execute"]
        if quiescence is not None:
            argv.extend(["--quiescence-receipt", str(quiescence)])
        with directory.with_name(directory.name + f"-{phase}.log").open("xb") as log:
            child = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, timeout=20, check=False)
        return child.returncode

    def begin(directory: Path, names: list[str]) -> dict[str, object]:
        sides = {}
        for name in names:
            audit_dir = directory / f"audit-{name}"
            run_id = run_prefix + name.lower()
            require(guard_call(audit_dir, run_id, "begin") == 0, "REAL_GUARD_BEGIN")
            baseline = json.loads(guard.private_read(audit_dir / "baseline.json"))
            require(baseline["rows"] == protected_rows, "BASELINE_PROTECTED_ONLY")
            sides[name] = {"scope": baseline["scope"], "directory": str(audit_dir / "capture")}
        require(len({side["scope"]["targetId"] for side in sides.values()}) == 1, "SHARED_TARGET_ID")
        return sides

    def phase(mode: str, action: object) -> dict[str, object]:
        directory = output / mode
        directory.mkdir(mode=0o700)
        (directory / "api-cwd").mkdir(mode=0o700)
        sides = begin(directory, ["A", "B"] if mode == "interleaved" else ["O"])
        work = directory / "work"
        copy_tree(PACKAGE / "web", work)
        config = directory / "exercise-config.json"
        write(config, {"mode": mode, "sides": sides, "receipt": str(directory / "bun-result.json")})
        env = {key: os.environ[key] for key in ["PATH", "LANG", "TZ"] if key in os.environ}
        env.update(PGHOST="127.0.0.1", PGHOSTADDR="127.0.0.1", PGPORT=str(pins["port"]),
            PGUSER=pins["dbaRole"], PGPASSFILE=str(args.passfile), PG_BIN=str(args.pg_bin),
            PGCONNECT_TIMEOUT="3", PGOPTIONS="-c statement_timeout=5000 -c lock_timeout=2000 -c search_path=pg_catalog")
        api = None
        driver = None
        api_code = None
        driver_code = None
        stop_kind = "not-started"
        phase_receipt: dict[str, object] = {"status": "FAIL", "driver": "controlled-real-API-Bun-exercise", "mode": mode}
        result["phases"][mode] = phase_receipt
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # İki ardışık own fazda TIME_WAIT yeniden bind'i engellemesin. REUSEPORT
        # verilmez; başka canlı listener aynı portu tutuyorsa bind yine reddeder.
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        with (directory / "api.log").open("xb") as api_log:
            try:
                listener.bind(("127.0.0.1", urlsplit(pins["apiOrigin"]).port))
                listener.listen(128)
                api = subprocess.Popen([sys.executable, str(repo / "scripts/run_owned_e2e.py"),
                    "--serve-owned", str(listener.fileno())], env=owned.child_environment(repo, pins, directory, 3119),
                    cwd=directory / "api-cwd", pass_fds=(listener.fileno(),), stdin=subprocess.PIPE,
                    stdout=api_log, stderr=subprocess.STDOUT)
                listener.close()
                owned.wait_ready(api, pins["apiOrigin"])
                driver = ControlledBun(args.bun, work, config, env, directory)
                require(driver.receive() == {"event": "ready", "mode": mode}, "REAL_DRIVER_READY")
                phase_receipt["experiment"] = action(driver, directory)
                require(driver.command("done") == {"completed": True}, "DRIVER_COMPLETE_ACK")
                driver_code = driver.finish()
                require(driver_code == 0, "DRIVER_EXIT")
            finally:
                listener.close()
                try:
                    if driver is not None:
                        driver.close()
                finally:
                    if api is not None:
                        api_code, stop_kind = owned.stop_owned_api(api)
                        phase_receipt.update(ownedApiPid=api.pid, ownedApiExitCode=api_code,
                            stopObservation=stop_kind, driverExitCode=driver_code)
                        write(directory / "own-process-stop.json", phase_receipt.copy())
        require(api is not None and api_code == 0 and stop_kind == "graceful-pipe-and-wait", "REAL_GRACEFUL_PIPE_WAIT_REQUIRED")
        outcomes = {}
        for name, side in sides.items():
            run_id = side["scope"]["runId"]
            quiescence = directory / f"quiescence-{name}.json"
            # Alan adı mevcut guard sözleşmesindendir; bu dosyanın driver'ı
            # Playwright değil yukarıdaki gerçek API/Bun deneyidir.
            write(quiescence, {"version": 1, "runId": run_id, "targetId": side["scope"]["targetId"],
                "ownedApiPid": api.pid, "ownedApiExitCode": api_code,
                "playwrightExitCode": driver_code, "state": "stopped"})
            audit_dir = directory / f"audit-{name}"
            code = guard_call(audit_dir, run_id, "finish", quiescence)
            accounting = json.loads(guard.private_read(audit_dir / "final-accounting.json"))
            if mode == "interleaved":
                require(code == 0 and accounting["status"] == "PASS" and accounting["afterRows"] == protected_rows, "INTERLEAVED_FINAL_ACCOUNTING")
            else:
                expected = phase_receipt["experiment"]["omittedRows"]
                require(code == 1 and accounting["status"] == "FAIL" and not accounting["missingBaselineIds"]
                    and not accounting["changedBaselineIds"] and accounting["unexpectedNewRows"] == expected
                    and accounting["deleteExecuted"] is False, "OMITTED_EXTRA_FAIL_REQUIRED")
                retained = snapshot(directory / "retained-after-guard.json")
                require(retained == (protected_rows | expected), "OMITTED_ROW_NOT_RETAINED")
            outcomes[name] = {"exitCode": code, "status": accounting["status"],
                "accountingSha256": sha(audit_dir / "final-accounting.json")}
        phase_receipt.update(status="PASS", guardOutcomes=outcomes)
        write(directory / "phase-result.json", phase_receipt)
        return phase_receipt

    def extra_one(before: dict[str, str], after: dict[str, str]) -> dict[str, str]:
        added = set(after) - set(before)
        require(len(added) == 1 and all(after.get(key) == value for key, value in before.items()), "EXACT_ONE_NEW_IMMUTABLE_AUDIT")
        return {key: after[key] for key in added}

    def interleaved(driver: ControlledBun, directory: Path) -> dict[str, object]:
        previous = snapshot(directory / "00-before-requests.json")
        require(previous == protected_rows, "INITIAL_INTERLEAVED_ROWS")
        by_run = {"A": {}, "B": {}}
        request_ids = set()
        for step, command in enumerate(["A1", "B1", "A2", "B2"], start=1):
            response = driver.command(command)
            require(response["status"] == 200 and response["captured"] is True
                and response["requestId"] not in request_ids, "REAL_UNIQUE_CAPTURED_RESPONSE")
            request_ids.add(response["requestId"])
            current = snapshot(directory / f"0{step}-after-{command}.json")
            by_run[command[0]].update(extra_one(previous, current))
            previous = current
        union = protected_rows | by_run["A"] | by_run["B"]
        require(previous == union and all(len(rows) == 2 for rows in by_run.values()), "P_A_B_EXACT_UNION")
        for step, command in enumerate(["incomplete", "wrongscope"], start=5):
            rejection = driver.command(command)
            require(rejection == {"rejected": True, "code": "INCOMPLETE_CAPTURE" if command == "incomplete" else "WRONG_SCOPE"}, "EXPECTED_CLEANUP_REJECTION")
            require(snapshot(directory / f"0{step}-after-{command}.json") == union, "REJECTED_CLEANUP_CHANGED_ROWS")
        require(driver.command("finish") == {"receiptsA": 2, "receiptsB": 2}, "EXACT_CAPTURE_COUNTS")
        for command, expected, removed in [
            ("cleanA", protected_rows | by_run["B"], by_run["A"]),
            ("cleanB", protected_rows, by_run["B"]),
        ]:
            cleaned = driver.command(command)
            require(set(cleaned["listedAuditIds"]) == set(removed) and set(cleaned["deletedAuditIds"]) == set(removed)
                and cleaned["coursesListed"] == cleaned["coursesDeleted"] == 0, "EXACT_OWNED_ROWS_REMOVED")
            require(snapshot(directory / f"after-{command}.json") == expected, "OTHER_RUN_OR_PROTECTED_ROW_CHANGED")
        return {"status": "PASS", "observedRequestCount": 4, "capturedRows": by_run,
            "protectedRows": protected_rows, "incompleteRejectedRowsUnchanged": True,
            "wrongScopeRejectedRowsUnchanged": True, "interleaving": ["A1", "B1", "A2", "B2"]}

    def omitted(driver: ControlledBun, directory: Path) -> dict[str, object]:
        before = snapshot(directory / "00-before-omitted.json")
        require(before == protected_rows, "OMITTED_BASELINE")
        observed = driver.command("omitted")
        require(observed["response"]["status"] == 200 and observed["response"]["captured"] is False, "REAL_OMITTED_RESPONSE")
        require(observed["cleanup"] == {"listedAuditIds": [], "deletedAuditIds": [], "coursesListed": 0, "coursesDeleted": 0}, "EMPTY_CAPTURE_CLEANUP_RESULT")
        after = snapshot(directory / "01-after-omitted-empty-cleanup.json")
        missing = extra_one(before, after)
        return {"omittedRows": missing, "HTTPStatus": 200, "captureReceiptCount": 0,
            "requestId": observed["response"]["requestId"], "bodySha256": observed["response"]["bodySha256"]}

    try:
        protected_rows = snapshot(output / "initial-protected.json")
        require(set(protected_rows) == {protected}, "EXPECTED_ONLY_ROOT_PROTECTED_ROW")
        # Bu tek doğrudan SELECT, P'nin A/B ile aynı sentetik aktöre ait olduğunu
        # ölçer. Hücre verisi yeniden raporlanmaz; DB/rol önce snapshot'ta sabittir.
        import psycopg
        with psycopg.connect(host=pins["host"], hostaddr=pins["host"], port=pins["port"],
            dbname=pins["databaseName"], user=pins["dbaRole"], passfile=str(args.passfile),
            connect_timeout=3, sslmode="disable",
            options="-c statement_timeout=5000 -c default_transaction_read_only=on") as connection:
            actor = connection.execute("SELECT actor_user_id::text FROM public.platform_admin_access_audit WHERE id = %s", (protected,)).fetchone()
            require(actor == ("11111111-1111-1111-1111-111111111111",), "PROTECTED_SAME_SYNTHETIC_ACTOR")
        phase("interleaved", interleaved)
        phase("omitted", omitted)
        result["status"] = "PASS"
    except Exception as error:
        code = str(error)
        result["errorCode"] = code if re.fullmatch(r"[A-Z_]{1,80}", code) else "REAL_AUDIT_EXERCISE_FAILED"
        result["errorType"] = type(error).__name__
    after_sources = owned.source_hashes(repo)
    write(output / "source-after.json", after_sources)
    result["sourceUnchanged"] = before_sources == after_sources
    if before_sources != after_sources:
        result["status"] = "FAIL"
    result["filesSha256"] = {str(path.relative_to(output)): sha(path) for path in sorted(output.rglob("*")) if path.is_file()}
    write(output / "result.json", result)
    print(json.dumps({"status": result["status"], "resultSha256": sha(output / "result.json"),
        "omitted_row_automatically_deleted": False}))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    try:
        exit_code = main()
    except Exception as error:
        code = str(error)
        print(json.dumps({"status": "FAIL", "errorType": type(error).__name__,
            "errorCode": code if re.fullmatch(r"[A-Z_]{1,80}", code) else "HARNESS_SETUP_FAILED"}))
        exit_code = 2
    raise SystemExit(exit_code)
