/** Gerçek API ve özgün temizle/AuditCapture yolları; yalnız parent komut bariyerleri. */
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { createInterface } from "node:readline";

import { AuditCapture, loadAuditReceipts, type AuditScope } from "./support/audit-receipts";
import { temizle } from "./support/cleanup";

type Side = { scope: AuditScope; directory: string };
type Config = { mode: "interleaved" | "omitted"; sides: Record<string, Side>; receipt: string };
const config = JSON.parse(readFileSync(process.argv[2]!, "utf8")) as Config;
const actor = "11111111-1111-1111-1111-111111111111";
const authorization = `Bearer dev:${actor}`;
const captures = new Map<string, AuditCapture>();
const observations: object[] = [];
const hash = (value: Uint8Array) => createHash("sha256").update(value).digest("hex");
function requireValue(value: unknown, code: string): asserts value {
  if (!value) throw new Error(code);
}

for (const [name, side] of Object.entries(config.sides)) {
  captures.set(name, new AuditCapture(side.directory, side.scope));
}

function envFor(name: string): NodeJS.ProcessEnv {
  const side = config.sides[name]!;
  return { ...process.env, E2E_RUN_ID: side.scope.runId,
    E2E_DATABASE_NAME: side.scope.databaseName, E2E_API_URL: side.scope.apiOrigin,
    E2E_AUDIT_TARGET_ID: side.scope.targetId, E2E_AUDIT_DIR: side.directory };
}

async function call(name: string, captured: boolean) {
  const side = config.sides[name]!;
  const url = `${side.scope.apiOrigin}/admin/overview`;
  const response = captured
    ? await captures.get(name)!.fetch(url, { headers: { Authorization: authorization } })
    : await fetch(url, { headers: { Authorization: authorization }, redirect: "error" });
  requireValue(response.status === 200, "EXPECTED_REAL_HTTP_200");
  requireValue(response.url === url, "RESPONSE_TARGET_MISMATCH");
  const requestId = response.headers.get("X-Request-ID");
  requireValue(requestId && /^[0-9a-f]{12}4[0-9a-f]{3}[89ab][0-9a-f]{15}$/.test(requestId), "SERVER_REQUEST_ID_REQUIRED");
  const body = new Uint8Array(await response.arrayBuffer());
  requireValue(body.length > 0 && body.length < 100_000, "RESPONSE_BODY_BOUND");
  return { status: response.status, requestId, bodySha256: hash(body), bodyBytes: body.length, captured };
}

async function clean(name: string) {
  const side = config.sides[name]!;
  const options = { runId: side.scope.runId, databaseName: side.scope.databaseName, env: envFor(name) };
  const listed = await temizle({ ...options, onayli: false });
  requireValue(listed.listed.length === 0, "UNEXPECTED_RUN_COURSES");
  const result = await temizle({ ...options, onayli: true });
  requireValue(result.listed.length === 0 && result.deleted.length === 0, "UNEXPECTED_COURSE_DELETE");
  return { listedAuditIds: result.listedAudits.map((row) => row.id).sort(),
    deletedAuditIds: result.deletedAudits.map((row) => row.id).sort(),
    coursesListed: result.listed.length, coursesDeleted: result.deleted.length };
}

async function rejection(name: string, wrongScope: boolean) {
  const side = config.sides[name]!;
  const env = envFor(name);
  if (wrongScope) env.E2E_AUDIT_TARGET_ID = side.scope.targetId === "0".repeat(64) ? "1".repeat(64) : "0".repeat(64);
  try {
    await temizle({ onayli: true, runId: side.scope.runId, databaseName: side.scope.databaseName, env });
  } catch (error) {
    const expected = wrongScope ? "Audit hedefi/koşusu ayrıştı." : "Tamamlanmamış audit toplayıcısı var.";
    requireValue(error instanceof Error && error.message === expected, "UNEXPECTED_REJECTION_REASON");
    return { rejected: true, code: wrongScope ? "WRONG_SCOPE" : "INCOMPLETE_CAPTURE" };
  }
  throw new Error("CLEANUP_DID_NOT_REJECT");
}

const commands = config.mode === "interleaved"
  ? ["A1", "B1", "A2", "B2", "incomplete", "wrongscope", "finish", "cleanA", "cleanB", "done"]
  : ["omitted", "done"];
let cursor = 0;
function emit(value: object) { process.stdout.write(`${JSON.stringify(value)}\n`); }
// temizle'nin normal ayrıntılı çıktısı özel stderr dosyasına gider; kontrol
// kanalı yalnız tam JSON satırı taşır, serbest log satırı ack sanılmaz.
console.log = (...args: unknown[]) => process.stderr.write(args.map(String).join(" ") + "\n");
emit({ event: "ready", mode: config.mode });

try {
  for await (const line of createInterface({ input: process.stdin, crlfDelay: Infinity })) {
    const command = JSON.parse(line) as { command: string; nonce: string };
    requireValue(command.command === commands[cursor] && /^[0-9a-f]{32}$/.test(command.nonce), "COMMAND_SEQUENCE");
    cursor += 1;
    let detail: object;
    if (/^[AB][12]$/.test(command.command)) {
      detail = await call(command.command[0]!, true);
    } else if (command.command === "incomplete" || command.command === "wrongscope") {
      detail = await rejection("A", command.command === "wrongscope");
    } else if (command.command === "finish") {
      captures.get("A")!.finish(); captures.get("B")!.finish();
      detail = { receiptsA: loadAuditReceipts(config.sides.A!.directory, config.sides.A!.scope).length,
        receiptsB: loadAuditReceipts(config.sides.B!.directory, config.sides.B!.scope).length };
    } else if (command.command === "cleanA" || command.command === "cleanB") {
      detail = await clean(command.command.slice(-1));
    } else if (command.command === "omitted") {
      // Gerçek yanıt tamamlanır; begin/record çağrıları kasıtlı yoktur. Boş
      // collector'ın 0/0 sonucu global satır eksiksizliği sayılmamalıdır.
      const response = await call("O", false);
      captures.get("O")!.finish();
      requireValue(loadAuditReceipts(config.sides.O!.directory, config.sides.O!.scope).length === 0, "OMITTED_CAPTURE_NOT_EMPTY");
      detail = { response, cleanup: await clean("O") };
    } else {
      detail = { completed: true };
    }
    observations.push({ command: command.command, ...detail });
    emit({ event: "ack", nonce: command.nonce, command: command.command, detail });
    if (command.command === "done") break;
  }
  requireValue(cursor === commands.length, "CONTROLLER_EOF_BEFORE_COMPLETE");
  writeFileSync(config.receipt, JSON.stringify({ status: "PASS", mode: config.mode, observations }) + "\n", { flag: "wx", mode: 0o600 });
} catch (error) {
  const message = error instanceof Error && /^[A-Z_]{1,80}$/.test(error.message) ? error.message : "EXERCISE_FAILED";
  writeFileSync(config.receipt, JSON.stringify({ status: "FAIL", mode: config.mode, code: message, observations }) + "\n", { flag: "wx", mode: 0o600 });
  emit({ event: "failure", code: message });
  process.exitCode = 1;
}
