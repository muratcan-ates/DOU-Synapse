# S10 root/CI audit muhasebesi — incelenebilir aday

Durum: yalnız geçici hazırlık. Repo/DB/ağ/sunucu/test değişikliği veya çalıştırması yok. Yeni Python kaynağı yalnız AST ile parse edildi; psycopg/CLI/SQL veya Playwright yürütülmedi. Mevcut S10 ürün adayı ve önceki S9 paketleri değişmedi. Bu paket entegrasyon önerisidir; root'un owned-process/provisioning adaptörü tamamlanmadan CI'a doğrudan uygulanamaz.

## Gözlenen açık ve en dar kapanış

S9 root çalıştırıcısı `/private/tmp/dou018_s9_e2e_run.py` gerçek cluster/OID'yi eski provisioning kaydıyla karşılaştırıyor, ancak bu kimliği browser collector'a taşımıyor ve bütün audit satırlarını başlangıç/son karşılaştırmıyor. S10 adayı `audit-receipts.ts:51–60` bir targetId biçimi istiyor; bu biçim tek başına DB sahipliğini kanıtlamaz. Mevcut CI `.github/workflows/ci.yml:398–403` ephemeral DB oluşturuyor; kimlik makbuzu henüz yok. API ayrı adımda background başlatılıyor (419), bu yüzden sonraki adım aynı parent'ın `wait()` çıkış makbuzunu üretemiyor.

`files/scripts/e2e_audit_guard.py` begin/finish adlı iki **salt okunur DB** evresi sunar. Varsayılanı plan çıktısıdır; DB çalışması için root açıkça `--execute` geçirir. Hiçbir DELETE, CREATE, ALTER, rol/grant değişimi, DB düşürme veya süreç sonlandırma içermez. Yeni bağımlılık yok; mevcut API Python ortamındaki psycopg kullanılır.

## Önceden güvenilir pins ve target makbuzu

Root önce yeni, yalnız bu koşuya ait sentetik DB'yi kendi provisioning akışıyla yaratır. Eski `d-e2e-provision-01` OID1466906 yalnız tarihsel örnektir; yeni koşunun hedefi diye kopyalanmaz. Gerçek yeni provisioning sonucu doğrulandıktan sonra 0600 `pins.json` üretir. Şema:

```json
{
  "version": 1,
  "issuer": "root-owned-fresh-database",
  "ownership": "exclusive-synthetic",
  "provisionSha256": "<önceden doğrulanmış provisioning dosyasının 64hex özeti>",
  "host": "127.0.0.1",
  "port": 55448,
  "databaseName": "<yeni sentetik E2E DB adı>",
  "databaseOid": "<kök provision adımının ölçtüğü OID>",
  "cluster": "<kök provision adımının ölçtüğü system_identifier>",
  "dbaRole": "<mevcut yerel test DBA rolü>",
  "apiOrigin": "http://127.0.0.1:<bu koşunun API portu>"
}
```

Bunlar doldurulacak alanlardır; örnek dosya çalıştırılabilir güven makbuzu değildir. Root çağrısı pins byte SHA'sını da geçirir. Bu SHA imza/sır/yetki değildir. Güven, root'un yeni DB'yi kendi yetkili akışında provision etmesi ve önceden sabitlediği kimliği incelemesinden gelir. DB'ye bağlanıp rastgele kimliği öğrenmek, JSON'a `exclusive-synthetic` yazmak veya aynı dosyanın SHA'sını hesaplamak kendi başına güven sağlamaz.

Guard açık numeric endpoint + hostaddr + DB/rol/passfile ile bağlanır; ortam PG yönlendirmelerini temizler. Read-only repeatable-read işleminde gerçek database adı/OID/cluster, current_user/session_user ve zaten sahip olunan DBA superuser rolünü karşılaştırır. Recovery/standby hedefini reddeder. `dou_app`/`dou_worker` audit tablosunu göremediği için bunlara yeni izin VERİLMEZ; mevcut test/provision DBA'sı kullanılır. Bağlantı3s, statement5s, lock2s sınırı vardır. Kaynakta SQL parse/runtime başarısı henüz ölçülmedi.

Doğrulamadan sonra deterministic `target.json` yazılır. `E2E_AUDIT_TARGET_ID` bu **tam dosyanın byte SHA'sıdır**. Target runId taşımaz; aynı gerçek hedefteki özel iki-koşu deneyinde aynı hedef bağı, farklı runId/capture dizinleri mümkündür. Beklenen tam hedef alanları yanlışsa begin hiçbir baseline/collector başarı makbuzu üretmez.

## Kayıt muhasebesi

Begin tüm `public.platform_admin_access_audit` satırlarını tek read-only snapshot'ta alır. `to_jsonb(a)` bütün sütunları kapsar; TimeZone UTC ve Python canonical JSON ile her tam satır SHA256'ya dönüşür. Artefakta yalnız row UUID→SHA haritası yazılır; aktör, requestId, zaman veya başka hücre değerleri tekrar dökülmez. 20000 audit satırı üst sınırı aşılırsa başarısız olur. Başlangıçtaki korunan satırlar boş varsayılmaz.

Root'un 0700 guard dizini içinde `capture/scope.json`, `sessions/`, `receipts/` hazırlanır. `environment.json` beş E2E değişkenini taşır; root yalnız bu kesin anahtarları parse ederek child env'ine ekler, shell-source yapmaz. Böylece global-setup'ın rastgele temp dizin yolunu logdan çekmeye ihtiyaç yoktur. `integration/global-setup.patch`, mevcut S10 staged global setup'ına uygulanacak dar deltadır: parent'ın dizini/scope'u, DB kimlik sondası yazılmadan önce doğrulanır. S10 içindeki API-read/psql-write sentinel yönü aynen kalır.

Playwright'ın aynı-koşu temizliği exact rowID+makbuz birleşimini korur. Root, Playwright bittiğinde başarılı/başarısız olmasına bakmadan **kendi API Popen sürecine** normal durma ister ve gerçek çıkışını bekler. Yalnız kendi kaydettiği child/port/çalıştırma kaynağı kullanılır; process adı/porttarama ile başka servis öldürülmez. API zaten başkasına aitse veya durma/commit durumu belirsizse başarı verilmez. Geç audit commit'leri bitmeden post-snapshot almak sıfır-kalıntı kanıtı değildir.

Root kendi gerçek wait sonucundan private quiescence JSON üretir:

```json
{"version":1,"runId":"<aynı koşu>","targetId":"<target byte SHA>","ownedApiPid":12345,"ownedApiExitCode":0,"playwrightExitCode":0,"state":"stopped"}
```

Bu dosya gözlemi yapan root'un makbuzudur, guard'ın kendi gözlemi değildir. PID'nin varlığını kontrol etmek veya kendi kendine bu alanları yazmak gerçek wait yerine geçmez. SIGTERM API'nin normal Uvicorn kapanışını yürütmeli; zorunlu kill/belirsiz durum `stopped/exit0` diye yeniden adlandırılmaz. Guard süreç kontrol etmez.

Finish aynı pins/target/run bağını ve quiescence makbuzunu doğrular, sonra yeni read-only snapshot alır. Başlangıçtaki her rowID ve tam satır SHA'sı aynı olmalı; yeni kalan UUID olmamalı. Eksilen/değişen baseline veya yeni satır **FAIL** olur. Beklenmeyen satırlar yalnız UUID+SHA olarak kaydedilir ve DB'de bırakılır; aktör/zaman/UUID öneki geniş DELETE yoktur. Playwright nonzero sonucu audit haritası aynı olsa bile PASS'e çevrilmez. Son JSON'u tekrar yazmak yasaktır; ayrı yeni koşu klasörü gerekir.

Bu iki snapshot, pencerede oluşup sonradan yetkisiz ayrı bir DBA tarafından silinen geçici satırları kanıtlamaz. Normal kabul, root'un tek-sahipli fresh DB'si ve aynı koşunun denetlenmiş exact-receipt cleanup'ı varsayımı içindedir. Tek tablo satır muhasebesi DB'nin bütün tablolarının kabulü değildir. Diğer koşu/servislerin girdiği ortak bir DB'de bu guard doğru biçimde yeni-satır FAIL verir; normal koşuda bu sınır gevşetilmez.

## CI için güven üreticisi ve lifecycle önerisi

`integration/ci-e2e-step.proposal.yml` uygulanmış workflow değildir; root'un yeni `run_owned_e2e.py` adaptörü için kesin arayüz önerisidir. API ve Playwright aynı Python parent içinde çalışmalı. Mevcut e2e service, image pin'i, 30dakika job sınırı ve API/worker rol ayrımı korunur. PGHOST/PGHOSTADDR numeric127.0.0.1, PGPORT5432 açık olur.

CI bootstrap güveni bir DB adından öğrenilmez: GitHub'ın job service context'inden gelen **container ID** kullanılır. İzinli service ID'nin çalışan, workflow'da pinli PostgreSQL imajına ait olduğu sadece gerekli `docker inspect` alanlarından doğrulanır (Config.Env dökülmez). Aynı container içinde read-only `pg_control_system()` ile cluster alınır; `dou_synapse` önceden yokken CREATE başarılı olmalı; aynı container içinde yeni OID okunur. Bu owned-create sonucu private provisioning makbuzuna gider. Ardından host numeric route'un cluster/OID'si container içi ölçümle eşleşmeden göç/seed/API/test başlamaz. Sonrasında mevcut sıralı migration/local-dev-setup/seed uygulanır; grants genişlemez. CI service/job sahipliği güven çıpasıdır, yeni target SHA tek başına değildir.

Root adapterı pins/baseline üretir, API'yi owned Popen ile başlatır, mevcut ready kapısını korur, Bun'u çalıştırır, collector cleanup sonucu ve Bun exit'ini kaydeder; finally kendi API child'ını durdurur/bekler ve finish çağırır. API başlatma/ready/test hata yollarında da guard'ın başarısı üst sonucun başarısızlığını silemez. Local helper de aynı adaptör/lifecycle sözleşmesini kullanır. `always()` arşiv adımı özel collector ve guard dosyalarını saklar; temizlik yetkisi vermez. Hosted doğrulama root entegrasyonu sonrası ayrıca yapılır.

## Root tarafından yürütülecek kabul vakaları

1. Yeni trusted synthetic hedef: begin→gerçek E2E→own API normal exit→finish. Başlangıçtaki bir protected audit satırı korunur; hiçbir kalıntı yoksa PASS.
2. Yanlış cluster/OID/rol/port veya A'nın pins/target'ını B scope'unda kullanma: begin/finish FAIL; audit DELETE veya sentinel/API yazımı başlamaz. Rastgele 64hex targetId tek başına kabul ettirilmez.
3. Aynı actor için bir protected satır P ve iki interleaved run A/B: gerçek API ile A/B auditleri ve ayrı collector makbuzları üret; yanıtlar gelene kadar olay bariyerleri kullan, sleep yarışı kurma. Ortak özel deneyin ara snapshot'ı P∪A∪B. Yalnız A cleanup sonrası tam harita P∪B; yalnız B cleanup sonrası P. P ve B'nin içerik SHA'sı A temizliğinde aynı kalmalı. Bu, normal finish'i A sırasında B'yi görmezden gelecek biçimde gevşetme gerekçesi değildir; ayrı koordineli DB deneyi olur.
4. Collector atlanan gerçek admin isteği: gerçek API200/403 sonrasında audit commit'i gerçekleşsin; yanıt kimliği collector'a kaydedilmesin. Own API durduktan sonra finish yeni UUID nedeniyle FAIL; satır yerinde kalmalı. Geniş fallback DELETE mutantı ayrıca bu korunma kontrolünü kırmızı yapmalı.
5. Bilinen yanıt kaybı/incomplete session: gerçek API yanıtı alınmışken istemciye teslimi engelleyen kontrollü bariyer, collector incomplete/teardown FAIL. Son snapshot yine uygulanır; temizlenemeyen satır belgelenir, otomatik genelleme yapılmaz.
6. Baseline satırını değiştiren veya silen test mutantı, yalnız yeni-satır sayısı0 olsa da content/missing oracle'ını kırmızı yapmalı. SQL hash yerine yalnız COUNT(*) kullanma mutantı bu testi kaçırır; bu nedenle rowID+tam içerik SHA gerekli.
7. Başarısız Bun/ready/API kapanışı, eksik/uyuşmayan stop makbuzu ve bağlantı kaybı: hiçbiri PASS'e dönmemeli. Kaynak/görevler arası karışım, sahte güven makbuzu veya sonradan geniş silme ile yeşile çevrilmez.

Kök kaynak hash listesine yeni guard, owned orchestrator, global hooks, audit-receipts/fixture, CI ve provisioning helper da eklenmeli; eski S9 hash fonksiyonu yalnız app/e2e dosyalarına bakıyordu. Bu adayın AST parse'ı, SQL/gerçek PG/proses/CI test başarısı değildir.

## En dar sahiplik

- Bu paket: yeni `scripts/e2e_audit_guard.py`, S10 staged global-setup dar önerisi, integration YAML/plan.
- Root: fresh DB producer, owned API/Bun lifecycle adaptörü, CI son uygulaması, quiescence/provisioning makbuzlarının güvenilir üretimi, kaynak hashleri/evidence/.ai/spec ve bütün DB/test çalışmaları.
- S10 ürün sahibi: audit-receipts/fixture/cleanup kontratları ve mevcut unit testleri; bu paket bu dosyalara dokunmadı.
- SQL migration, RLS, uygulama/worker rol izinleri: değişiklik yok.
