"""Compare frozen owned-controller lifecycle behavior with real Uvicorn children.

No database or product application is imported. Each child imports a private,
minimal ASGI fixture as app.main:app. This measures the unmodified controller's
socket/pipe/exit behavior, not DOU-Synapse product startup or shutdown. Default
mode is a plan. Only the root executor may opt into --execute.
"""

from __future__ import annotations

import argparse
import hashlib
import http.client
import importlib.metadata
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time


FIXTURE_SOURCE = '''"""Private synthetic ASGI lifecycle fixture; no DB or provider code."""
import os

CASE = os.environ["OWNED_LIFECYCLE_CASE"]

async def app(scope, receive, send):
    if scope["type"] == "lifespan":
        while True:
            message = await receive()
            if message["type"] == "lifespan.startup":
                if CASE == "startup-failed":
                    await send({"type": "lifespan.startup.failed", "message": "synthetic startup failure"})
                    return
                await send({"type": "lifespan.startup.complete"})
            elif message["type"] == "lifespan.shutdown":
                if CASE == "shutdown-failed":
                    await send({"type": "lifespan.shutdown.failed", "message": "synthetic shutdown failure"})
                else:
                    await send({"type": "lifespan.shutdown.complete"})
                return
    elif scope["type"] == "http":
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            if message["type"] == "http.request" and not message.get("more_body", False):
                break
        body = b'{"status":"ready","fixture":true}'
        status = 200 if scope["path"] == "/health/ready" else 404
        await send({"type": "http.response.start", "status": status,
                    "headers": [(b"content-type", b"application/json"),
                                (b"content-length", str(len(body)).encode("ascii"))]})
        await send({"type": "http.response.body", "body": body})
'''


class ProbeError(Exception):
    """Fixed, content-free probe failure code."""


def require(condition: bool, code: str) -> None:
    if not condition:
        raise ProbeError(code)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_source(path: Path, expected: str) -> Path:
    require(path.is_absolute() and path.resolve(strict=True) == path, "SOURCE_CANONICAL_PATH")
    require(path.is_file() and not path.is_symlink(), "SOURCE_REGULAR_FILE")
    require(sha(path) == expected, "SOURCE_HASH_MISMATCH")
    return path


def write_json(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def cleanup_owned(process: subprocess.Popen[bytes]) -> tuple[int | None, str]:
    if process.poll() is not None:
        return process.wait(), "already-exited"
    process.terminate()
    try:
        return process.wait(timeout=2), "forced-terminate"
    except subprocess.TimeoutExpired:
        process.kill()
        try:
            return process.wait(timeout=2), "forced-kill"
        except subprocess.TimeoutExpired:
            return process.poll(), "owned-child-not-reaped"


def arm(controller: Path, case: str, directory: Path) -> dict[str, object]:
    directory.mkdir(mode=0o700)
    fixture = directory / "fixture"
    fixture.mkdir(mode=0o700)
    package = fixture / "app"
    package.mkdir(mode=0o700)
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "main.py").write_text(FIXTURE_SOURCE, encoding="utf-8")
    env = {key: os.environ[key] for key in ("PATH", "LANG", "TZ") if key in os.environ}
    env.update(PYTHONPATH=str(fixture), PYTHONDONTWRITEBYTECODE="1",
               OWNED_LIFECYCLE_CASE=case)
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    process = None
    code = None
    cleanup = "not-needed"
    error_code = None
    ready = False
    attempts = 0
    successful_http = 0
    stop_sent = False
    started = time.monotonic()
    try:
        listener.bind(("127.0.0.1", 0))
        listener.listen(128)
        port = listener.getsockname()[1]
        with (directory / "child.log").open("xb") as log:
            process = subprocess.Popen(
                [sys.executable, str(controller), "--serve-owned", str(listener.fileno())],
                cwd=fixture, env=env, pass_fds=(listener.fileno(),), stdin=subprocess.PIPE,
                stdout=log, stderr=subprocess.STDOUT,
            )
            listener.close()
            if case == "startup-failed":
                code = process.wait(timeout=10)
            else:
                deadline = time.monotonic() + 10
                while time.monotonic() < deadline:
                    require(process.poll() is None, "CHILD_EXITED_BEFORE_READY")
                    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=0.25)
                    attempts += 1
                    try:
                        connection.request("GET", "/health/ready")
                        response = connection.getresponse()
                        body = response.read()
                        successful_http += 1
                        require(response.status == 200 and
                                body == b'{"status":"ready","fixture":true}', "FIXTURE_HTTP_CONTRACT")
                        ready = True
                        break
                    except (OSError, http.client.HTTPException):
                        time.sleep(0.025)
                    finally:
                        connection.close()
                require(ready, "FIXTURE_READY_TIMEOUT")
                require(process.stdin is not None, "CONTROL_PIPE_MISSING")
                process.stdin.write(b"stop\n")
                process.stdin.flush()
                process.stdin.close()
                stop_sent = True
                code = process.wait(timeout=10)
    except ProbeError as error:
        error_code = str(error)
    except subprocess.TimeoutExpired:
        error_code = "OWNED_CHILD_TIMEOUT"
    except Exception:
        error_code = "ARM_FAILED"
    finally:
        listener.close()
        if process is not None and process.poll() is None:
            code, cleanup = cleanup_owned(process)
        if process is not None and process.stdin is not None and not process.stdin.closed:
            try:
                process.stdin.close()
            except OSError:
                error_code = error_code or "CONTROL_PIPE_CLOSE_FAILED"
    result = {
        "case": case, "exitCode": code, "errorCode": error_code,
        "readyObserved": ready, "controlStopSent": stop_sent,
        "httpAttempts": attempts, "httpResponses": successful_http,
        "ownedPid": None if process is None else process.pid,
        "ownedChildReaped": process is not None and process.poll() is not None,
        "cleanup": cleanup, "seconds": round(time.monotonic() - started, 6),
        "fixtureSourceSha256": sha(package / "main.py"),
        "logSha256": sha(directory / "child.log") if (directory / "child.log").is_file() else None,
    }
    write_json(directory / "observation.json", result)
    return result


def run(args: argparse.Namespace) -> int:
    controllers = {
        "baseline": read_source(args.baseline, args.baseline_sha256),
        "candidate": read_source(args.candidate, args.candidate_sha256),
    }
    for controller in controllers.values():
        read_source(controller.with_name("e2e_audit_guard.py"), args.guard_sha256)
    require(sys.version_info[:2] == (3, 12), "PYTHON_3_12_REQUIRED")
    uvicorn_version = importlib.metadata.version("uvicorn")
    require(uvicorn_version == args.uvicorn_version, "UVICORN_VERSION_MISMATCH")
    source_paths = {
        "probe": Path(__file__).resolve(),
        **{name: path for name, path in controllers.items()},
        **{f"{name}Guard": path.with_name("e2e_audit_guard.py") for name, path in controllers.items()},
    }
    before = {name: sha(path) for name, path in source_paths.items()}
    if not args.execute:
        print(json.dumps({"status": "PLAN", "cases": 6, "databaseCalls": 0,
                          "childProcessesStarted": 0, "httpCalls": 0,
                          "sources": before, "uvicornVersion": uvicorn_version}))
        return 0
    output = args.output
    require(output.is_absolute() and output.resolve() == output, "OUTPUT_CANONICAL_PATH")
    output.mkdir(mode=0o700, exist_ok=False, parents=False)
    write_json(output / "source-before.json", before)
    observed = {}
    for name, path in controllers.items():
        for case in ("normal", "startup-failed", "shutdown-failed"):
            key = f"{name}-{case}"
            observed[key] = arm(path, case, output / key)
    after = {name: sha(path) for name, path in source_paths.items()}
    checks = {}
    for name in controllers:
        normal = observed[f"{name}-normal"]
        startup = observed[f"{name}-startup-failed"]
        shutdown = observed[f"{name}-shutdown-failed"]
        checks[f"{name}NormalExit0"] = normal["exitCode"] == 0 and normal["readyObserved"]
        checks[f"{name}StartupRejected"] = type(startup["exitCode"]) is int and startup["exitCode"] != 0
        checks[f"{name}StartupBeforeHttp"] = startup["httpAttempts"] == 0 and not startup["controlStopSent"]
        checks[f"{name}ShutdownObservedAfterReady"] = shutdown["readyObserved"] and shutdown["controlStopSent"]
    checks["baselineShutdownFalseSuccessReproduced"] = observed["baseline-shutdown-failed"]["exitCode"] == 0
    checks["candidateShutdownFailureExit1"] = observed["candidate-shutdown-failed"]["exitCode"] == 1
    checks["allChildrenReaped"] = all(value["ownedChildReaped"] for value in observed.values())
    checks["noProbeErrorOrForcedCleanup"] = all(value["errorCode"] is None and value["cleanup"] == "not-needed" for value in observed.values())
    checks["sourceUnchanged"] = before == after
    result = {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks, "observations": observed, "sourcesBefore": before,
        "sourcesAfter": after, "uvicornVersion": uvicorn_version,
        "pythonVersion": list(sys.version_info[:3]), "databaseCalls": 0,
        "childProcessesStarted": len(observed),
        "externalHttpCalls": 0,
        "scope": "Unmodified owned-controller + real Uvicorn + private minimal ASGI fixture; not product app, DB, browser, provider or hosted acceptance",
    }
    write_json(output / "result.json", result)
    print(json.dumps({"status": result["status"], "checks": checks,
                      "databaseCalls": 0, "childProcessesStarted": len(observed)}))
    return 0 if result["status"] == "PASS" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--baseline-sha256", required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--candidate-sha256", required=True)
    parser.add_argument("--guard-sha256", required=True)
    parser.add_argument("--uvicorn-version", default="0.52.4")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    os.umask(0o077)
    try:
        return run(args)
    except ProbeError as error:
        print(json.dumps({"status": "FAIL", "errorCode": str(error)}))
        return 2
    except Exception:
        print(json.dumps({"status": "FAIL", "errorCode": "PROBE_FAILED"}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
