"""Private synthetic ASGI lifecycle fixture; no DB or provider code."""
import os

CASE = os.environ["OWNED_LIFECYCLE_CASE"]

async def app(scope, receive, send):
    if scope["type"] == "lifespan":
        while True:
            message = await receive()
            if message["type"] == "lifespan.startup":
                if CASE == "startup-failed":
                    await send({"type": "lifespan.startup.failed", "message": "synthetic startup failure"})
                    return
                await send({"type": "lifespan.startup.complete"})
            elif message["type"] == "lifespan.shutdown":
                if CASE == "shutdown-failed":
                    await send({"type": "lifespan.shutdown.failed", "message": "synthetic shutdown failure"})
                else:
                    await send({"type": "lifespan.shutdown.complete"})
                return
    elif scope["type"] == "http":
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            if message["type"] == "http.request" and not message.get("more_body", False):
                break
        body = b'{"status":"ready","fixture":true}'
        status = 200 if scope["path"] == "/health/ready" else 404
        await send({"type": "http.response.start", "status": status,
                    "headers": [(b"content-type", b"application/json"),
                                (b"content-length", str(len(body)).encode("ascii"))]})
        await send({"type": "http.response.body", "body": body})
