"""Offline contracts for stop_owned_api; no DB, network or child processes.

Run with the repository's Python 3.12 interpreter and explicit controller/guard
hash environment. Importing the controller does not execute its main function.
The frozen baseline may be run separately as a negative control; do not rewrite
its failing assertions as successful candidate results.
"""

from __future__ import annotations

import hashlib
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import unittest


def load_controller():
    source = Path(os.environ["OWNED_CONTROLLER_PATH"])
    expected = os.environ["OWNED_CONTROLLER_SHA256"]
    guard = source.with_name("e2e_audit_guard.py")
    expected_guard = os.environ["OWNED_GUARD_SHA256"]
    if not source.is_absolute() or source.resolve(strict=True) != source:
        raise RuntimeError("CONTROLLER_CANONICAL_PATH")
    for path, digest in ((source, expected), (guard, expected_guard)):
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError("CONTROLLER_SOURCE_HASH_MISMATCH")
    for name, path in (("e2e_audit_guard", guard), ("owned_controller_under_test", source)):
        spec = importlib.util.spec_from_file_location(name, path)
        if spec is None or spec.loader is None:
            raise RuntimeError("CONTROLLER_IMPORT_SPEC")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules["owned_controller_under_test"]


class FakePipe:
    def __init__(self, owner, failed_stage):
        self.owner = owner
        self.failed_stage = failed_stage

    def operation(self, stage):
        self.owner.calls.append(stage)
        if stage == self.failed_stage:
            raise OSError("synthetic-control-pipe-failure")

    def write(self, value):
        if value != b"stop\n":
            raise AssertionError("wrong control bytes")
        self.operation("write")

    def flush(self):
        self.operation("flush")

    def close(self):
        self.operation("close")


class FakeProcess:
    def __init__(self, waits, failed_stage=None, already_exited=None):
        self.calls = []
        self.waits = list(waits)
        self.returncode = already_exited
        self.stdin = FakePipe(self, failed_stage)
        self.started_live = already_exited is None

    def poll(self):
        self.calls.append("poll")
        return self.returncode

    def wait(self, timeout=None):
        self.calls.append(("wait", timeout))
        if self.started_live and timeout is None:
            raise AssertionError("an initially live child must never have an unbounded wait")
        if not self.waits:
            raise AssertionError("unexpected additional wait")
        value = self.waits.pop(0)
        if value == "timeout":
            raise subprocess.TimeoutExpired("synthetic-owned-child", timeout)
        self.returncode = value
        return value

    def terminate(self):
        self.calls.append("terminate")

    def kill(self):
        self.calls.append("kill")


class StopOwnedContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.controller = load_controller()

    def test_normal_pipe_and_observed_exit(self):
        process = FakeProcess([0])
        self.assertEqual(self.controller.stop_owned_api(process, 0.1), (0, "graceful-pipe-and-wait"))
        self.assertEqual(process.calls, ["poll", "write", "flush", "close", ("wait", 0.1)])

    def test_write_failure_timeout_still_terminates_and_reaps(self):
        process = FakeProcess(["timeout", 0], failed_stage="write")
        self.assertEqual(self.controller.stop_owned_api(process, 0.1), (0, "forced-terminate"))
        self.assertEqual(process.calls, ["poll", "write", ("wait", 0.1), "terminate", ("wait", 10)])
        self.assertEqual(process.returncode, 0)

    def test_flush_failure_two_timeouts_still_kills_and_reaps(self):
        process = FakeProcess(["timeout", "timeout", -9], failed_stage="flush")
        self.assertEqual(self.controller.stop_owned_api(process, 0.1), (-9, "forced-kill"))
        self.assertEqual(process.calls, ["poll", "write", "flush", ("wait", 0.1), "terminate", ("wait", 10), "kill", ("wait", 10)])
        self.assertEqual(process.returncode, -9)

    def test_failed_write_then_exit0_is_never_clean(self):
        process = FakeProcess([0], failed_stage="write")
        self.assertEqual(self.controller.stop_owned_api(process, 0.1), (0, "control-pipe-failed"))
        self.assertNotIn("terminate", process.calls)

    def test_failed_close_then_exit0_is_never_clean(self):
        process = FakeProcess([0], failed_stage="close")
        self.assertEqual(self.controller.stop_owned_api(process, 0.1), (0, "control-pipe-failed"))

    def test_timeout_after_normal_write_preserves_actual_signal_exit(self):
        process = FakeProcess(["timeout", -15])
        self.assertEqual(self.controller.stop_owned_api(process, 0.1), (-15, "forced-terminate"))
        self.assertEqual(process.returncode, -15)

    def test_already_exited_child_is_not_claimed_as_normal_stop(self):
        process = FakeProcess([7], already_exited=7)
        self.assertEqual(self.controller.stop_owned_api(process, 0.1), (7, "exited-before-stop"))
        self.assertEqual(process.calls, ["poll", ("wait", None)])

    def test_unreapable_child_cannot_produce_success(self):
        process = FakeProcess(["timeout", "timeout", "timeout"], failed_stage="write")
        with self.assertRaises(subprocess.TimeoutExpired):
            self.controller.stop_owned_api(process, 0.1)
        self.assertIn("terminate", process.calls)
        self.assertIn("kill", process.calls)
        self.assertIsNone(process.returncode)
        self.assertFalse(process.waits)


if __name__ == "__main__":
    unittest.main(verbosity=2)
