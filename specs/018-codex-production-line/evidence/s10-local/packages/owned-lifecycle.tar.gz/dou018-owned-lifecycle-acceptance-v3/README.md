# Owned-controller lifecycle acceptance candidate

Prepared without executing tests, network requests, DB calls or child processes. Only Python AST parsing was performed. The repository and frozen first adapter were not edited.

The latest statically read repository controller hash was `d0db75dce445efc26a1d77944bcd680e023c3750597f1420bfeee2938f1ffd6a` (it supersedes root's intermediate `2bea1ba...` with CSS hash coverage, GitHub job context and explicit blank Supabase values). Its `serve_owned()` and `stop_owned_api()` fixes match the reviewed intermediate version. Guard hash remains `68196f59ff4da42378cc7b310c0bc4ccd95c5acb97ca3b3928dc8e2546b495b4`. Root must approve and supply the actual current controller hash if it changes again; do not bypass a hash refusal.

## Static follow-up to the first review

- The common bounded wait → terminate → wait → kill → wait path now also handles pipe write/flush/close OSError. A failed control pipe retains a non-clean label even if the child subsequently returns 0.
- Uvicorn is explicitly configured with `lifespan="on"`; exit0 additionally requires the exact stop message, startup/shutdown events, and all three failure fields false. This prevents the identified shutdown-failed → exit0 conversion in the supported runtime. The tests below still need execution.
- Components, CSS, Next config and tsconfig are in the source map. Before DB begin, the running controller and guard must be the exact files under the supplied repository. This closes the earlier repo-external helper attribution error. It does not establish expected-source equality by itself; root's independently frozen input hashes remain necessary.
- Explicit empty Supabase values and disabled Next telemetry narrow the synthetic browser environment. General Bun/Next dotenv reloading and browser process-group survival after leader failure are not exercised by this lifecycle probe. Treat those as separate operational acceptance boundaries; the original 180b review is preserved at `/private/tmp/dou018-owned-adapter-review.md`.

## Offline stop contracts

Eight unittest methods import the real source after its controller/guard hash checks. Synthetic Popen/pipe doubles deliberately raise write/flush/close errors and bounded wait timeouts. They do not claim OS process cleanup. Tests reject an unbounded wait for any initially live fake process. The frozen baseline is expected to fail the write/flush timeout and unreapable-child fallback assertions; preserve its real result separately, without changing assertions to make it pass.

Root candidate command (no DB/network/process spawning by these tests):

```sh
OWNED_CONTROLLER_PATH=/Users/muratates/code/dou-synapse-018-codex-production-line/scripts/run_owned_e2e.py \
OWNED_CONTROLLER_SHA256=d0db75dce445efc26a1d77944bcd680e023c3750597f1420bfeee2938f1ffd6a \
OWNED_GUARD_SHA256=68196f59ff4da42378cc7b310c0bc4ccd95c5acb97ca3b3928dc8e2546b495b4 \
/Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python \
/private/tmp/dou018-owned-lifecycle-acceptance/test_stop_contracts.py
```

For the separate negative control, use controller path `/private/tmp/dou018-owned-adapter-candidate/files/scripts/run_owned_e2e.py` and SHA `180b5e5e0191451b5bbe053ff7a93d4cd397e87eebe3e5cc49a0a8516c989920`. The guard SHA is the same. Capture stdout/stderr and the real process exit independently; baseline failures are intended negative evidence, not candidate failures or a numeric leak count.

## Six real child observations, root executor only

`probe_owned_lifecycle.py` starts each frozen controller's actual `--serve-owned` branch as a direct Python child. It supplies a socket already bound to numeric loopback and a private stdin pipe. An isolated `app.main:app` fixture implements ASGI startup, a fixed health response and shutdown. No controller/guard/Uvicorn function is monkeypatched. **The ASGI fixture deliberately replaces the product app import; this is controller/runtime acceptance, not real DOU-Synapse product startup/shutdown, DB, browser, provider or hosted proof.**

Both versions receive normal, startup-failed and shutdown-failed fixture cases. Expected observations:

| Case | Frozen 180b | Candidate |
|---|---|---|
| Normal, ready then stop pipe | Actual exit0 | Actual exit0 |
| Actual ASGI startup.failed | Nonzero, no HTTP sent | Nonzero, no HTTP sent |
| Actual ASGI shutdown.failed after ready | Old false-success exit0 | Actual exit1 |

The paired result passes only when the old defect is reproduced, the new contract is met, all six owned children are reaped without fallback, no probe error occurs, and controller/guard/probe hashes are unchanged. The result contains literal observed exit codes; it never normalizes signals into 0. Each child has a private log plus observation JSON, and the suite records before/after hashes. Failed observations remain in the new output directory.

Default mode only reports PLAN; it creates no output directory and starts no child/socket/HTTP/DB. Root adds `--execute` only when the heavy-test slot is available:

```sh
/Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python \
/private/tmp/dou018-owned-lifecycle-acceptance/probe_owned_lifecycle.py \
  --baseline /private/tmp/dou018-owned-adapter-candidate/files/scripts/run_owned_e2e.py \
  --baseline-sha256 180b5e5e0191451b5bbe053ff7a93d4cd397e87eebe3e5cc49a0a8516c989920 \
  --candidate /Users/muratates/code/dou-synapse-018-codex-production-line/scripts/run_owned_e2e.py \
  --candidate-sha256 d0db75dce445efc26a1d77944bcd680e023c3750597f1420bfeee2938f1ffd6a \
  --guard-sha256 68196f59ff4da42378cc7b310c0bc4ccd95c5acb97ca3b3928dc8e2546b495b4 \
  --uvicorn-version 0.52.4 \
  --output /private/tmp/dou018-owned-lifecycle-measured-01 \
  --execute
```

Requirements: existing Python 3.12 environment with the already installed Uvicorn 0.52.4; no new dependency installation. The root output path must be new and canonical. Parent starts only its own direct children, binds only `127.0.0.1:0`, reads the assigned socket's port and uses no proxy. It clears ambient app/PG/provider environment by constructing a small child environment and uses a private fixture cwd. A failure triggers bounded termination of only the child Popen handle; it does not scan PIDs, ports or databases.

Per child: readiness or startup wait ≤10 seconds, graceful stop ≤10 seconds, emergency cleanup terminate/kill waits ≤2 seconds each. These are failure ceilings; ordinary execution should be short but has not been measured. Local HTTP attempts/responses and child exit codes are observed. `externalHttpCalls: 0` and `databaseCalls: 0` describe this bounded harness/fixture code path; they are not a system-wide syscall/network audit. Real product E2E, broad socket policy, control-pipe OS fault injection, forced signals, and browser-group cleanup remain separate root-owned acceptance work.

V2 measured follow-up: measured01 recorded -6/Fatal Python in both startup-failure cases even though nonzero oracle passed. Original artifacts remain unchanged. This candidate additionally requires exact candidate startup exit1 and absence of Fatal Python diagnostic, and independently binds baseline/candidate guards (candidate guard formatting has verified AST/import equivalence). No runtime probe executed when preparing V2.

V3 oracle correction: measured02 candidate startup exited3 without Fatal Python, while assumed exit1 check failed. Installed Uvicorn0.52.4 server._serve invokes sys.exit(STARTUP_FAILURE), config STARTUP_FAILURE=3. V3 keeps exact exit3, candidate fatal-diagnostic absence, other checks unchanged. Runtime source SHA 7c1dbd656835c9cdd6f92078ffc80bcc6007824ab322aff15435bd89c068e0be. Previous nonzero/PASS and assumed1/FAIL receipts are preserved. Child-start count now uses actual non-null ownedPid. No product source changed for this oracle correction.
