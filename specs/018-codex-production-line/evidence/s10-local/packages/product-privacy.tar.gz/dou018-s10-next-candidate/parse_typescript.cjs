/* Yalnız statik TypeScript sözdizimi; uygulama/test modülleri yüklenmez. */
const fs = require('node:fs');
const path = require('node:path');
const ts = require('/Users/muratates/code/dou-synapse-018-codex-production-line/apps/web/node_modules/typescript');
const root = path.join(__dirname, 'files/apps/web');
function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const value = path.join(dir, entry.name);
    return entry.isDirectory() ? walk(value) : value.endsWith('.ts') ? [value] : [];
  });
}
const files = walk(root);
const diagnostics = files.flatMap(file => ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TS).parseDiagnostics.map(diagnostic => ({file: path.relative(__dirname,file), code: diagnostic.code, message: ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n')})));
const report = { kind: 'syntax-only-not-typecheck-or-test', files: files.length, diagnostics };
fs.writeFileSync(path.join(__dirname, 'typescript-syntax.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
process.exitCode = diagnostics.length ? 1 : 0;
