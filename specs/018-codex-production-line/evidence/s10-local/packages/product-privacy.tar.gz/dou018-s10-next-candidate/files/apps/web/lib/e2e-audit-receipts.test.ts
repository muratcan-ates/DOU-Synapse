import { describe, expect, test } from "bun:test";
import { readFileSync, readdirSync, rmSync } from "node:fs";
import { join } from "node:path";

import {
  AuditCapture, expectedAuditScope, initializeAuditCapture, loadAuditReceipts,
  receiptFromResponse, validateAuditDirectory, type AuditScope,
} from "../e2e/audit-receipts";

const scope: AuditScope = {
  version: 1, runId: "abc123xy", databaseName: "dou_synapse_e2e_s10",
  apiOrigin: "http://127.0.0.1:8018", targetId: "a".repeat(64),
};
const actorId = "11111111-1111-1111-1111-111111111111";
const id = "fedcba98765443218fedcba987654321";
const observation = {
  url: `${scope.apiOrigin}/admin/overview`, method: "GET",
  authorization: `Bearer dev:${actorId}`, status: 200, requestId: id,
};

function withDirectory(callback: (directory: string) => void): void {
  const directory = initializeAuditCapture(scope);
  try { callback(directory); }
  finally { rmSync(directory, { recursive: true }); }
}

describe("E2E audit yanıt sahipliği", () => {
  test("root hedef makbuzu yoksa fail-closed; API origin sınırı dardır", () => {
    expect(() => expectedAuditScope(scope.runId, scope.databaseName, {})).toThrow();
    expect(() => expectedAuditScope(scope.runId, scope.databaseName, {
      E2E_AUDIT_TARGET_ID: scope.targetId, E2E_API_URL: "https://name:secret@example.invalid",
    })).toThrow();
    expect(expectedAuditScope(scope.runId, scope.databaseName, {
      E2E_AUDIT_TARGET_ID: scope.targetId, E2E_API_URL: scope.apiOrigin,
    })).toEqual(scope);
  });

  test("yalnız gerçek origin/izinli rota ve sunucu v4 hex kimliği makbuz olur", () => {
    expect(receiptFromResponse(observation, scope.apiOrigin)).toEqual({
      requestId: id, actorId, action: "GET /admin/overview", result: "allowed",
    });
    expect(receiptFromResponse({ ...observation, status: 403 }, scope.apiOrigin)?.result).toBe("denied");
    expect(receiptFromResponse({ ...observation, url: "http://127.0.0.1:18018/admin/overview" }, scope.apiOrigin)).toBeNull();
    expect(receiptFromResponse({ ...observation, url: `${scope.apiOrigin}/courses` }, scope.apiOrigin)).toBeNull();
    for (const requestId of ["e2e-abc123-42-1", "Name_Student01234", "", undefined]) {
      expect(() => receiptFromResponse({ ...observation, requestId }, scope.apiOrigin)).toThrow();
    }
    expect(() => receiptFromResponse({ ...observation, status: 500 }, scope.apiOrigin)).toThrow();
    expect(() => receiptFromResponse({ ...observation, authorization: "Bearer secret" }, scope.apiOrigin)).toThrow();
  });

  test("aynı route.fetch/browser makbuzu tekilleşir; hiçbir ham başlık/sorgu saklanmaz", () => {
    withDirectory((directory) => {
      const capture = new AuditCapture(directory, scope);
      const key = {};
      capture.begin(key, observation.url, observation.method, observation.authorization);
      capture.record({ ...observation, url: `${observation.url}?private=SYNTHETIC_QUERY` }, key);
      capture.record(observation);
      capture.finish();
      expect(loadAuditReceipts(directory, scope)).toHaveLength(1);
      for (const name of readdirSync(join(directory, "receipts"))) {
        const raw = readFileSync(join(directory, "receipts", name), "utf8");
        expect(raw).not.toContain("Bearer");
        expect(raw).not.toContain("SYNTHETIC_QUERY");
        expect(raw).not.toContain("authorization");
      }
    });
  });

  test("ayrı koşu veya hedefteki makbuzlar temizlik yetkisine dönüşmez", () => {
    withDirectory((directory) => {
      for (const mismatch of [
        { ...scope, runId: "another123" },
        { ...scope, databaseName: "dou_synapse_e2e_other" },
        { ...scope, targetId: "b".repeat(64) },
        { ...scope, apiOrigin: "http://127.0.0.1:8019" },
      ]) expect(() => validateAuditDirectory(directory, mismatch)).toThrow();
    });
  });

  test("aynı aktörün iki koşusunda diğer koşunun dosyaları korunur", () => {
    const firstDirectory = initializeAuditCapture(scope);
    const otherScope = { ...scope, runId: "another123" };
    const secondDirectory = initializeAuditCapture(otherScope);
    try {
      const first = new AuditCapture(firstDirectory, scope);
      const second = new AuditCapture(secondDirectory, otherScope);
      first.record(observation);
      second.record({ ...observation, requestId: "12345678123442348234123456789abc" });
      first.finish(); second.finish();
      const before = loadAuditReceipts(secondDirectory, otherScope);
      expect(loadAuditReceipts(firstDirectory, scope).map((row) => row.requestId)).toEqual([id]);
      expect(loadAuditReceipts(secondDirectory, otherScope)).toEqual(before);
      expect(() => loadAuditReceipts(secondDirectory, scope)).toThrow();
    } finally {
      rmSync(firstDirectory, { recursive: true });
      rmSync(secondDirectory, { recursive: true });
    }
  });

  test("yanıt kaybı veya durmuş worker 0/0 yeşile dönüşemez", () => {
    withDirectory((directory) => {
      const capture = new AuditCapture(directory, scope);
      const key = {};
      capture.begin(key, observation.url, observation.method, observation.authorization);
      expect(() => loadAuditReceipts(directory, scope)).toThrow();
      capture.fail(key);
      expect(() => capture.finish()).toThrow();
      expect(() => loadAuditReceipts(directory, scope)).toThrow();
    });
  });

  test("aynı server-ID farklı aktör/sonuçla yeniden kullanılırsa reddedilir", () => {
    withDirectory((directory) => {
      const capture = new AuditCapture(directory, scope);
      capture.record(observation);
      capture.record({ ...observation, status: 403 });
      capture.finish();
      expect(() => loadAuditReceipts(directory, scope)).toThrow();
    });
  });

  test("Node fetch katkısı gerçek yanıtın gövdesini değiştirmeden makbuzu yazar", async () => {
    const directory = initializeAuditCapture(scope);
    const original = globalThis.fetch;
    try {
      globalThis.fetch = (async (input: RequestInfo | URL) => {
        expect(String(input)).toBe(observation.url);
        return new Response('{"error":{"code":"forbidden"}}', {
          status: 403, headers: { "X-Request-ID": id },
        });
      }) as typeof fetch;
      const capture = new AuditCapture(directory, scope);
      const response = await capture.fetch(observation.url, {
        headers: { Authorization: observation.authorization },
      });
      expect(response.status).toBe(403);
      expect(await response.json()).toEqual({ error: { code: "forbidden" } });
      capture.finish();
      expect(loadAuditReceipts(directory, scope)[0]?.result).toBe("denied");
    } finally {
      globalThis.fetch = original;
      rmSync(directory, { recursive: true });
    }
  });
});

test("bugünkü audit çağrı noktaları toplayıcıya bağlıdır; yeni literal rota inceleme ister", () => {
  // Kaynak envanteri ek nöbetçidir; dinamik URL çözümlemesi veya gerçek PG kanıtı değildir.
  const directory = join(import.meta.dir, "../e2e");
  const names = readdirSync(directory).filter((name) => name.endsWith(".spec.ts"));
  const users = names.filter((name) => /\/admin|\/openapi\.json/.test(
    readFileSync(join(directory, name), "utf8"),
  ));
  expect(users.sort()).toEqual(["admin-readiness.spec.ts", "portal.spec.ts"]);
  for (const name of users) {
    expect(readFileSync(join(directory, name), "utf8")).toContain('from "./audit-fixture"');
  }
  expect(readFileSync(join(directory, "portal.spec.ts"), "utf8"))
    .toContain('auditCapture.fetch(`${API}/admin/overview`');
  expect(readFileSync(join(directory, "admin-readiness.spec.ts"), "utf8"))
    .toContain("auditCapture.record({");
});
