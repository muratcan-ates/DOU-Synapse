# Root'un kabul sonrası birleştireceği belge metni

S10 yerel adayında destek kodu her HTTP isteği için sunucuda üretilir. `X-Request-ID` istemci başlığı görmezden gelinir; yanıt başlığı ve hata zarfının `error.request_id` alan adları değişmez. Genel 500'ün mevcut middleware dışı başlık sınırı devam eder; destek kodu hata gövdesi ile `app.error` kaydında eşleşir. Yeni bir HTTP tekrarının kodu değişir, bu kod idempotency veya kullanıcı kimliği değildir.

İç `ServerRequestId` tipi yalnız sunucunun UUID4 üretimiyle oluşturulur. Günlükte maskeleme muafiyeti yalnız `app.request` ve `app.error` kayıtlarının doğrudan `context.request_id` alanına ve tam iç tipe aittir. UUID biçimli sıradan metin ve diğer alanlar genel maskeyi korur. Bu ayrım keyfi Python çalıştırmaya karşı sınır değildir ve audit aktörü/zamanıyla ilişkili kodu anonim yapmaz.

Platform admin audit'in geçmiş kayıtları korunur; `request_logs` şemasına alan eklenmez. Tarayıcı testleri server yanıt kimliklerini sentetik aktör, sabit işlem ve sonuçla özel koşu makbuzlarına kaydeder. Temizlik yalnız bu makbuzların tam satır kimliklerini kapsar. Yanıt kaybı ve collector dışındaki yazımlar için ayrı root başlangıç/son DB muhasebesi zorunludur; makbuz sayısı sıfır diye sıfır kalıntı iddia edilmez.

Bu metin aday politikasıdır. Gerçek S10 test sonuçları, kaynak hashleri ve açık hosted/harici istemci etkileri root kabul kaydı oluşunca eklenmelidir; S9 tarihsel kanıtları yeniden yazılmaz.
