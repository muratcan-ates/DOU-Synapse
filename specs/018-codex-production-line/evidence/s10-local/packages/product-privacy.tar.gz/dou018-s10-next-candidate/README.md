# S10 — Sunucu destek kimliği ve E2E audit sahipliği adayı

Durum: yalnız hazırlanmış staged kaynak. Repo, DB, model, gerçek sunucu veya ağ değişmedi/çalıştırılmadı. Pytest/Bun test/Playwright ve mypy **koşulmadı**. Python dosyaları `ast.parse` ile, TypeScript dosyaları yerel compiler parser ile yalnız sözdizimi olarak okundu. 12 Python dosyasında Ruff check/format statik kontrolü geçti; bunlar kabul testi değildir. İlk format çağrısı repo cache dizinine yazma denemesinde durdu, `--no-cache` ile yalnız aday dosyalar üzerinde tekrarlandı. Root S9'u tamamlamadan entegrasyon yok. Önceki S9/S9B/S9C süreç raporları ve donmuş paketler değiştirilmedi.

`base/` hazırlık sırasında okunan gerçek çalışma ağacı dosyalarının kopyasıdır. `files/` yalnız yeni/değişen dosyaları içerir. `change.patch` bu iki kümenin farkıdır. `manifest.json` her ikisinin SHA256 değerlerini ve kaynak bağlamını kaydeder; Git commit adı tek başına kirli çalışma ağacını temsil etmez.

## 1. Dar ürün davranışı

- `core/request_context.py` içindeki `ServerRequestId` metin girdisi kabul etmez: bir `uuid4()` çekilişinin `.hex` değeriyle kurulur. `request_id_of()` yalnız **tam** iç türe güvenir ve nesneyi aynı request state'te saklar. Alt sınıf ve sıradan string yenilenir.
- `main.py` istemci `X-Request-ID` başlığını okumaz. Yeni HTTP denemesi yeni sunucu kimliği alır; aynı istek middleware/handler/audit/log boyunca aynı iç nesneyi kullanır. JSON/header/SQL serileştirmesi eşit metin değerini taşır; DB adaptasyonunun gerçek doğrulaması root testindedir.
- `errors.py` mevcut helper erişimini koruyup iç modüle aktarır. Hata zarfının alanları, Türkçe mesajları ve HTTP durumları değişmez. Üretim web arayüzü zaten hata gövdesindeki destek kodunu gösterir ve istemci kimliği üretmez; ürün frontend'ine dokunulmaz.
- **Semantik uyumluluk farkı:** İstemci kimliği artık echo edilmez. Başlığı göndermek 400 üretmez; görmezden gelinir. Harici caller'ın echo'ya dayanıp dayanmadığı bilinmiyor. İsim/tip/gövde değişmediği için API v2 gerekmez; değişiklik notu ve harici istemci envanteri gerekir.
- Genel 500'ün mevcut başlık sınırı korunur: ServerErrorMiddleware dış handler'ı gövdede kod taşır, mevcut akışta `X-Request-ID` yanıt başlığı yoktur. Bu aday ayrıca header düzeltmesi veya yeni completion log eklemez. App.error ile gövde eşitliği test edilir.
- `request_logs` tablosunda request_id yoktur; şema/göç, kota/cache/idempotency anahtarı ve akademik veri davranışı değişmez. Platform audit mevcut `request_id text` alanında kalır, tarihsel satırlar dönüştürülmez.

## 2. TCKN maskesiyle çakışan geçerli UUID

Genel log kalıbı `(?<!\d)\d{11}(?!\d)`, geçerli `abcdef12-3456-4abc-8def-12345678901a` UUID'sinin son bölümünü maskeler. Bu, rastgele destek kodunun yanıt/audit ile günlükte farklılaşmasına yol açabilir.

Çözüm RNG yeniden çekme veya bütün UUID metinlerine muafiyet değildir. Yalnız `app.request` / `app.error` **doğrudan** `context.request_id` alanında **tam `ServerRequestId` tipi** korunur. Diğer logger, başka alan, nested alan, düz string UUID ve alt sınıf maskelenmeye devam eder. İstisna formatter yolu ile normal filtre/formatter yolu ayrı sınanır. JSON'dan veya HTTP başlığından gelen sıradan metin bu tipe dönüşmez. Bu ayrım keyfi Python yürütme yetkisine karşı bir güvenlik sınırı değildir.

UUID hâlâ audit aktörü/zamanıyla ilişkilidir; anonimlik veya hukuki uyum sertifikası değildir. Kayıtların toplayıcıda saklanması ve dış proxy günlükleri bu yerel adayın kanıtı değildir.

## 3. E2E yanıt makbuzları ve temizlik

Mevcut admin çağrıları `portal.spec.ts` ve `admin-readiness.spec.ts` içindedir. İkisi özel `audit-fixture.ts` test fixture'ını kullanır; browser context request/response/requestfailed olayları izlenir. Portal'ın doğrudan Node fetch'i `auditCapture.fetch` kullanır. `route.fetch()` ile alınan gerçek upstream overview yanıtı ayrıca `auditCapture.record()` ile kaydedilir; browser'a fulfill edilen aynı ID tekilleştirilir. Üç spec'teki eski istemci başlığı kaldırılır; `role-aware-agent` yeni collector'a bağlanmaz çünkü audit rotası kullanmıyor.

Bugün `APIRequestContext` üzerinden admin çağrısı yok. Yeni çağrı eklenirse response korunarak şu katkı gerekir; Playwright'ın özel iç yöntemlerini monkeypatch etmedik:

```ts
const response = await request.get(`${API}/admin/overview`, { headers });
auditCapture.record({ url: response.url(), method: "GET",
  authorization: headers.Authorization, status: response.status(),
  requestId: response.headers()["x-request-id"] });
```

Bu katkının `request.get` öncesi/başarısız response takibi de fixture sahibi tarafından eklenmeli; tek kayıt satırı kaybolan yanıtı kanıtlamaz. Yeni audit çağrı envanteri ve hata testi zorunludur. Mevcut iki literal rota sahibini denetleyen kaynak testi yalnız ek nöbetçidir, dinamik URL veya tam kapsam kanıtı değildir.

Toplayıcı yalnız yapılandırılmış API origin'i ve SQL helper'ın sabit action kümesini kabul eder. Authorization yalnız bilinen **sentetik** AYSE/BURAK dev aktörünü bellekte seçmek için okunur, saklanmaz. Makbuzda dört alan vardır: server requestId, sentetik actorId, sabit action, allowed/denied. Prompt, gövde, token, ham header, query ve exception metni yoktur. Bu testlerin ölçülmüş 200/403 kapı sözleşmesi dışındaki yanıtlar tahmin edilmez, collector fail-closed olur.

`global-setup` mevcut DB/API sentinel doğrulamasını korur. Özel 0700 dizin ve 0600 dosyalar kullanılır. Her test collector session'ı başlamadan önce `complete:false` kaydı yazar; yanıtı kaybolan/başarısız/bekleyen istek veya yarım yazım varsa loader/teardown başarısızdır. Normal kapanışta session tamamlanır. Bu yerel test artefaktları root tarafından arşivlenir; otomatik geniş dosya temizliği eklenmedi.

`cleanup.ts` artık yalnız açık runId + o koşunun makbuz diziniyle çalışır. Audit SQL'de `request_id` öneki veya bütün UUID'ler seçilmez. Her makbuzun **tam requestId + actorId + action + result** birleşimi aranır; yalnız önceden listelenen **tam audit row ID** ve aynı birleşimle DELETE yapılır. Boş makbuz SQL'i `FALSE` olur. Bilinen bir makbuzun eksik/çift satırı, başka koşu satırı veya hedef uyuşmazlığı silme öncesinde reddedilir. Sonuç tekrar doğrulanır. Var olan korunan dersler ve run-scoped course kontrolü korunur.

Manuel `e2e:clean` artık `--run` ve makbuz/target env olmadan tüm koşulara yayılmaz. Başarılı silmeden sonra aynı eski makbuzu tekrar kullanmak eksik satır hatası verir; bu araç genel idempotent süpürücü değildir.

## 4. Root / CI sahibinde açık kalan gerçek hedef ve eksiksizlik işi

Okunan `/private/tmp/dou018_ops_e2e_run.py` ve `dou018_d_e2e_run_v2.py`, root provisioning kaydına göre PG cluster system_identifier + DB OID'yi kontrol eder, PG env'i temizleyip numeric endpoint'e sabitler. Ancak bu kimlik makbuzunu Playwright'a vermez ve audit başlangıç/son satır muhasebesi yapmaz. Bu yardımcılar ve CI workflow'u **değiştirilmedi**.

Aday `E2E_AUDIT_TARGET_ID` (64 küçük hex SHA256) gerektirir. Bu değer root'un **önceden güvenilir yolla doğruladığı** hedef kimlik makbuzunun byte hash'i olmalıdır. Gizli anahtar veya tek başına kimlik doğrulama değildir; sadece makbuz/koşu/hedef artefakt bağını taşır. Collector kendisi hedef öğrenip güvenmez. Değer yoksa global setup DB sentinel yazmadan durur. CI ve root helper sahibinin bunu sağlaması entegrasyon ön koşuludur.

Root'un hazır hedef kaydında en az database adı/OID, cluster system_identifier, numeric host/port ve kaynak receipt hash'i bulunmalı; root kendi açık PG routing/env izolasyonunu korumalı. Çalışma öncesi ve sonrası aynı gerçek hedefi read-only doğrulamalı. Sonuç klasörüne hedef receipt'i ve hash'i koyup `E2E_AUDIT_TARGET_ID` olarak geçirmeli. Global setup'ın yazdırdığı özel `E2E_AUDIT_DIR` yolunu ayrıca arşivlemeli.

**Makbuz tek başına bütün DB yazımlarını kanıtlamaz.** Yanıt API commit'inden sonra kaybolabilir; collector'dan önce çöken veya collector kullanmayan bir çağrı görülemeyebilir. Root fresh/exclusively owned E2E DB'de audit başlangıç satır kimlikleri ve son satır kimlikleri karşılaştırmasını tamamlamalı. İki eşzamanlı koşu kabulünde her koşunun makbuzu ve başlangıçtaki korunan satırlar ayrı hesaplanmalı. Beklenmeyen yeni satır silinmez; koşu başarısız/açık kalır. Aktör/zaman penceresine veya bütün UUID'lere geniş fallback yasaktır.

`temizle()` başarısı yalnız **yakalanmış** makbuzların temizliğidir; root'un genel başarı kodu bu eksiksizlik muhasebesi olmadan verilmemeli. CLI logu bu sınırı açıkça yazar. Bu root katkısı tamamlanmadan S10 tam E2E kabulü veya sıfır kalıntı iddiası yapılmaz.

## 5. Sıralı kabul planı — root yürütür

1. S9 son commit sonrası `base` hash'leri ile current dosyaları karşılaştır; farklıysa kör copy yapma, adayın o dosyasını yeniden kaynakla bağla. Değişiklikleri root inceleyip ayrı aşamada uygulasın. Yeni modül/logging risk kapsamı `.ai/spec` ve findings kaydına root tarafından eklensin.
2. API cwd'de Ruff/mypy + biçim; web cwd'de Bun unit ve tsc. API Ruff statik sonucu aşağıda kayıtlıdır; mypy/Bun test/tsc ve gerçek testler hazırlanırken çalışmadı.
3. DB'siz paket: `pytest --noconftest tests/test_server_request_id.py tests/test_request_log_privacy.py tests/test_exception_log_privacy.py tests/test_exception_request_id_redaction.py tests/test_log_sink_privacy.py`. Gerçek body-limit fixture ve error-envelope DB senaryoları normal root izole test DB slotunda çalışmalı.
4. İzole gerçek PG: yeni `test_admin_audit_uses_server_id_shared_with_response_and_emitted_log` dört parametrik vaka; iki izinli istemci metni (ASCII isim/öğrenci canary + geçerli UUID), allowed/denied, sabit digit-run sunucu UUID'si. `dou_app` gerçek audit insert, aynı body/header/log/DB metni; RLS/rol negatifleri ve mevcut portal kapıları korunmalı. Psycopg'in iç str alt tipini gerçekten doğru adapte ettiği bu kanıtta ölçülür.
5. Yeni kaynak bağlı gerçek h11 + httptools Uvicorn deneyi: 200/401/403/404/405/413/422/500, başlık yok/ASCII/UUID/tekrarlı başlık, body/log/audit korelasyonu ve S9C sink hata sınırı. Eski S9 raporu değişmez. Sunucu kimlikleri taze olduğundan bütün response byte hash'lerinin iki kol arasında aynı olması beklenmez; ham hash saklanır, yalnız ID alanı ayrı doğrulanarak kalan sözleşme karşılaştırılır.
6. Root helper/CI hedef receipt + audit muhasebesi katkısı sonrası gerçek E2E. Özellikle admin route.fetch/fulfill, doğrudan Node 403 ve browser yanıtları sayılmalı; her makbuz bir audit satırıyla eşleşmeli.
7. Yeni izole DB'de iki interleaved run ve aynı aktörlü korunan non-E2E audit satırı: A'nın makbuzuyla temizlik A satırlarını siler, B+korunan satır içerik/hash aynı kalır. A runDir'ini B target/run ile kullanma reddedilir. Bilinen yanıt kaybı/session incomplete temizliği reddeder. Collector'ın tamamen atlandığı yazım root başlangıç/son hesabını kırmızı yapar, geniş silme uygulanmaz. Bu PG davranışı unit SQL metin assertion'larından çıkarılamaz.
8. Son API/E2E paketleri, kaynak hashleri ve bağımsız kabul notu; hosted collector/proxy ve hukuki anonimlik kapsamı açık kalır.

## 6. Beklenen olumsuz kontroller

- Header echo'nun eski blok olarak geri gelmesi: izinli ASCII/UUID HTTP canary ve body/header/log korelasyonu kırmızı.
- Helper exact-type kontrolünün düz string'e güvenmesi: plain-state ve doğrudan handler testleri kırmızı; bunu tek başına HTTP exploit kanıtı diye sunma, middleware başlığı okumuyor.
- Trusted context kimliğinin yeniden genel maskelemeden geçirilmesi: digit-run UUID HTTP/log/audit eşitliği kırmızı.
- UUID biçimine veya `isinstance(str)`'e genel muafiyet: sıradan UUID/TCKN, başka logger/alan ve alt sınıf negatifleri kırmızı.
- Süreç genelinde tek ID cache: sekiz bariyerli ASGI isteğinde tekil kimlik kontrolü kırmızı. Aynı request içinde tekrar üretim: aynı nesne/tek çekiliş kontrolü kırmızı.
- Cleanup run/target sınırını kaldırma: farklı scope dosya testleri; SQL row-ID/makbuz sınırını kaldırma: gerçek iki koşu/korunan PG satırı kontrolü kırmızı. Unit testin SQL string kontrolü tek başına gerçek row güvenliği değildir.

Önceki rastgele UUID desteği ve yeni server UUID desteği UUID başına kişisel veri yokluğu iddia etmez; amaç istemcinin bu alana seçtiği keyfi veriyi doğrudan taşımasını durdurmaktır.
