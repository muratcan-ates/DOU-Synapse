/** Ağ yerine yalnız testin açık fetch taklidini kullan; sayaçları özel makbuza yaz. */
import { writeFileSync } from "node:fs";

const receipt = process.env.S10_OFFLINE_RECEIPT;
if (!receipt) throw new Error("OFFLINE_RECEIPT_REQUIRED");
let unmockedFetchAttempts = 0;
let mockAssignments = 0;
let mockCalls = 0;
const blocked = (async () => {
  unmockedFetchAttempts += 1;
  throw new Error("OFFLINE_UNMOCKED_FETCH_FORBIDDEN");
}) as typeof fetch;
let current = blocked;

// Gerçek fetch referansı test koduna hiç verilmez. Sabit test kaynağı başka bir
// transport çağırmaz; bu dar kontrol bütün Bun/native modülleri için sandbox değildir.
Object.defineProperty(globalThis, "fetch", {
  configurable: false,
  get() { return current; },
  set(value: typeof fetch) {
    if (value === blocked) { current = blocked; return; }
    if (typeof value !== "function") throw new Error("OFFLINE_MOCK_FUNCTION_REQUIRED");
    mockAssignments += 1;
    current = (async (...args: Parameters<typeof fetch>) => {
      mockCalls += 1;
      return value(...args);
    }) as typeof fetch;
  },
});

process.on("exit", () => {
  writeFileSync(receipt, JSON.stringify({
    schema: "s10-bun-offline-transport-v1", bunVersion: Bun.version,
    unmockedFetchAttempts, mockAssignments, mockCalls,
    actualFetchReferenceExposed: false,
  }) + "\n", { flag: "wx", mode: 0o600 });
});
