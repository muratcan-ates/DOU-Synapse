"""Altı özgün tuple testini tek normal app.core modül kimliğiyle çalıştırır."""

from __future__ import annotations

import argparse
import hashlib
import importlib.abc
import importlib.metadata
import json
import os
import sys
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--receipt", required=True, type=Path)
    args = parser.parse_args()
    os.umask(0o077)
    root = args.root.resolve(strict=True)
    test_file = root / "tests/test_server_request_id.py"
    counters = {"network_attempts": 0, "database_import_attempts": 0, "process_attempts": 0}

    def audit(event: str, _args: tuple[object, ...]) -> None:
        if event in {"socket.connect", "socket.getaddrinfo", "socket.gethostbyname", "socket.gethostbyaddr"}:
            counters["network_attempts"] += 1
            raise RuntimeError("OFFLINE_NETWORK_FORBIDDEN")
        if event in {"subprocess.Popen", "os.system", "os.posix_spawn", "os.exec"}:
            counters["process_attempts"] += 1
            raise RuntimeError("OFFLINE_PROCESS_FORBIDDEN")

    class NoDatabase(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname: str, path: object = None, target: object = None) -> None:
            if fullname.split(".")[0] in {"psycopg", "psycopg2", "asyncpg", "sqlalchemy"}:
                counters["database_import_attempts"] += 1
                raise RuntimeError("OFFLINE_DATABASE_IMPORT_FORBIDDEN")
            return None

    sys.addaudithook(audit)
    sys.meta_path.insert(0, NoDatabase())
    sys.path.insert(0, str(root))
    os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    os.environ.pop("PYTEST_ADDOPTS", None)
    receipt: dict[str, object] = {
        "schema": "s10-python-negative-observation-v1",
        "setup_failure": None, "reports": [], "collection_errors": [],
        "collected_parameters": [], "identity_checks": [], "guards": counters,
    }
    try:
        import pytest
        from app.core import logging as app_logging
        from app.core import request_context

        assert app_logging.ServerRequestId is request_context.ServerRequestId
        assert Path(app_logging.__file__).resolve() == root / "app/core/logging.py"
        assert Path(request_context.__file__).resolve() == root / "app/core/request_context.py"
        receipt["modules"] = {
            "app.core.logging": {"path": app_logging.__file__, "sha256": sha(Path(app_logging.__file__))},
            "app.core.request_context": {"path": request_context.__file__, "sha256": sha(Path(request_context.__file__))},
            "test": {"path": str(test_file), "sha256": sha(test_file)},
        }
        receipt["versions"] = {
            "python": sys.version, "pytest": pytest.__version__,
            "fastapi": importlib.metadata.version("fastapi"),
            "starlette": importlib.metadata.version("starlette"),
        }

        class Recorder:
            def pytest_collectreport(self, report: object) -> None:
                if report.failed:
                    receipt["collection_errors"].append({"nodeid": report.nodeid, "outcome": report.outcome})

            def pytest_collection_modifyitems(self, items: list[object]) -> None:
                for item in items:
                    receipt["collected_parameters"].append(dict(item.callspec.params))
                    receipt["identity_checks"].append({
                        "same_request_context_module": item.module.request_context is request_context,
                        "same_exact_class": item.module.ServerRequestId is app_logging.ServerRequestId is request_context.ServerRequestId,
                        "same_formatter": item.module.JsonFormatter is app_logging.JsonFormatter,
                    })

            @pytest.hookimpl(hookwrapper=True)
            def pytest_runtest_makereport(self, item: object, call: object):
                outcome = yield
                report = outcome.get_result()
                observation = {
                    "nodeid": report.nodeid, "when": report.when, "outcome": report.outcome,
                    "parameters": dict(item.callspec.params), "exception_type": None,
                    "crash_path": None, "crash_line": None,
                }
                if call.excinfo is not None:
                    observation["exception_type"] = call.excinfo.type.__name__
                    frame = call.excinfo.traceback[-1]
                    observation["crash_path"] = str(Path(frame.path).resolve())
                    observation["crash_line"] = frame.lineno + 1
                receipt["reports"].append(observation)

        result = int(pytest.main([
            str(test_file) + "::test_tuple_values_cannot_bypass_context_or_extra_redaction",
            "-q", "--noconftest", "-p", "no:cacheprovider", "--rootdir", str(root),
            "-c", str(root / "pytest.ini"),
        ], plugins=[Recorder()]))
        receipt["pytest_exit_code"] = result
        receipt["forbidden_module_loaded"] = any(
            name.split(".")[0] in {"psycopg", "psycopg2", "asyncpg", "sqlalchemy"}
            for name in sys.modules
        )
    except BaseException as error:
        receipt["setup_failure"] = type(error).__name__
        result = 2
    write(args.receipt, receipt)
    return result


if __name__ == "__main__":
    raise SystemExit(main())
