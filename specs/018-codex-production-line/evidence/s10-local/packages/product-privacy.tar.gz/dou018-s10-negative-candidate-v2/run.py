"""Donmuş S10 eski/yeni kaynaklarını aynı nihai testlerle karşılaştırır.

Varsayılan plan; gerçek yürütme root'un --execute seçimini gerektirir. Repo ve
paket kaynaklarını değiştirmez, DB/ağ başlatmaz. Ham test başarısızlıkları yalnız
yeni özel çıktı dizininde saklanır; public çıktı içeriksiz kabul özetidir.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MAX_REPORT = 8 * 1024 * 1024
PYTHON_CASE = "test_tuple_values_cannot_bypass_context_or_extra_redaction"
WEB_FAILURES = {
    "izlenen istek başka origin yanıtıyla sessizce tamamlanmaz",
    "izlenen istek audit dışı rota yanıtıyla sessizce tamamlanmaz",
    "izlenen istek başka audit action yanıtıyla sessizce tamamlanmaz",
    "izlenen istek başka sentetik aktör yanıtıyla sessizce tamamlanmaz",
    "audit fetch yönlendirmeyi reddeder ve yanıt kaybında incomplete kalır",
    "audit fetch farklı son URL yanıtını güvenilir makbuz saymaz",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value: bool, code: str) -> None:
    if not value:
        raise RuntimeError(code)


def write(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def private_json(path: Path) -> object:
    require(path.is_file() and not path.is_symlink() and path.stat().st_size < MAX_REPORT, "MISSING_OR_LARGE_RECEIPT")
    return json.loads(path.read_text())


def verify_sources(manifest: dict[str, object]) -> dict[str, str]:
    actual = {}
    for name, expected in manifest["files"].items():
        path = ROOT / name
        require(path.is_file() and not path.is_symlink(), "SOURCE_NOT_REGULAR")
        actual[name] = sha(path)
        require(actual[name] == expected["sha256"], "SOURCE_HASH_MISMATCH")
    return actual


def stage_tree(source: Path, destination: Path) -> None:
    destination.mkdir(mode=0o700)
    for path in sorted(source.rglob("*")):
        target = destination / path.relative_to(source)
        require(not path.is_symlink(), "SOURCE_SYMLINK")
        if path.is_dir():
            target.mkdir(mode=0o700)
        else:
            with target.open("xb") as stream:
                stream.write(path.read_bytes())


def tree_hashes(directory: Path) -> dict[str, str]:
    return {str(path.relative_to(directory)): sha(path) for path in sorted(directory.rglob("*")) if path.is_file()}


def run_child(argv: list[str], cwd: Path, directory: Path, environment: dict[str, str]) -> dict[str, object]:
    started = time.monotonic()
    stdout = directory / "stdout.txt"
    stderr = directory / "stderr.txt"
    timeout = False
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            result = subprocess.run(argv, cwd=cwd, env=environment, stdout=out, stderr=err, timeout=90, check=False)
            return_code = result.returncode
        except subprocess.TimeoutExpired:
            timeout = True
            return_code = None
    return {
        "argv": argv, "cwd": str(cwd), "exit_code": return_code, "timeout": timeout,
        "duration_seconds": round(time.monotonic() - started, 6),
        "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr),
        "stdout_bytes": stdout.stat().st_size, "stderr_bytes": stderr.stat().st_size,
    }


def evaluate_python(arm: str, observation: dict[str, object], process: dict[str, object], root: Path) -> dict[str, object]:
    parameters = {(False, kind) for kind in ["plain", "internal", "subclass"]} | {(True, kind) for kind in ["plain", "internal", "subclass"]}
    reports = observation["reports"]
    calls = [r for r in reports if r["when"] == "call"]
    noncalls = [r for r in reports if r["when"] != "call"]
    selected = {(p["use_filter"], p["kind"]) for p in observation["collected_parameters"]}
    identity = observation["identity_checks"]
    baseline = arm == "baseline"
    expected_outcome = "failed" if baseline else "passed"
    checks = {
        "no_setup_or_collection_failure": observation["setup_failure"] is None and not observation["collection_errors"],
        "exact_six_parameters": selected == parameters and len(observation["collected_parameters"]) == 6,
        "one_normal_module_and_class_identity": len(identity) == 6 and all(all(item.values()) for item in identity),
        "six_real_calls": len(calls) == 6 and all(PYTHON_CASE in item["nodeid"] for item in calls),
        "setup_teardown_all_pass": len(noncalls) == 12 and all(item["outcome"] == "passed" for item in noncalls),
        "expected_call_outcomes": len(calls) == 6 and all(item["outcome"] == expected_outcome for item in calls),
        "exit_code_matches": process["exit_code"] == (1 if baseline else 0) and observation["pytest_exit_code"] == (1 if baseline else 0),
        "no_db_network_process_attempt": not any(observation["guards"].values()) and observation["forbidden_module_loaded"] is False,
    }
    if baseline:
        checks["only_exact_tuple_leak_assertion"] = all(
            item["exception_type"] == "AssertionError" and item["crash_line"] == 153
            and item["crash_path"] == str(root / "tests/test_server_request_id.py")
            for item in calls
        )
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "test_calls": len(calls)}


def evaluate_web(arm: str, junit: Path, transport: dict[str, object], process: dict[str, object]) -> dict[str, object]:
    require(junit.is_file() and junit.stat().st_size < MAX_REPORT, "JUNIT_REQUIRED")
    raw = junit.read_bytes()
    require(b"<!DOCTYPE" not in raw and b"<!ENTITY" not in raw, "JUNIT_ENTITY_FORBIDDEN")
    document = ET.fromstring(raw)
    cases = list(document.iter("testcase"))
    names = [case.attrib.get("name", "") for case in cases]
    failures = {case.attrib.get("name", ""): case.find("failure") for case in cases if case.find("failure") is not None}
    details = []
    for name, failure in failures.items():
        body = " ".join([failure.attrib.get("message", ""), failure.attrib.get("type", ""), "".join(failure.itertext())])
        # Bu dosyada before/after hook yok; tam ad+17case+assertion imzası şart.
        # Genel import/TypeError/psql/rapor hataları negatif özellik kanıtı değildir.
        details.append({
            "name": name, "failure_sha256": hashlib.sha256(body.encode()).hexdigest(),
            "assertion_signature": bool(re.search(r"expect\(|AssertionError", body)),
            "setup_error_signature": bool(re.search(r"Cannot find module|SyntaxError|ReferenceError|Failed to resolve|error during test|OFFLINE_", body)),
        })
    baseline = arm == "baseline"
    checks = {
        "exact_seventeen_unique_cases": len(cases) == 17 and len(set(names)) == 17,
        "no_error_or_skip": not list(document.iter("error")) and not list(document.iter("skipped")),
        "expected_failures": set(failures) == WEB_FAILURES if baseline else not failures,
        "failure_is_test_assertion": all(item["assertion_signature"] and not item["setup_error_signature"] for item in details),
        "expected_exit": process["exit_code"] == (1 if baseline else 0),
        "no_real_fetch": transport["unmockedFetchAttempts"] == 0 and transport["actualFetchReferenceExposed"] is False,
        "four_mock_fetch_calls": transport["mockAssignments"] == 4 and transport["mockCalls"] == 4,
    }
    return {
        "status": "PASS" if all(checks.values()) else "FAIL", "checks": checks,
        "total": len(cases), "failed": len(failures), "passed": len(cases) - len(failures),
        "failures": details, "junit_sha256": sha(junit),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--python", required=True, type=Path)
    parser.add_argument("--bun", required=True, type=Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"status": "PLAN", "runs": 4, "tests_executed": False, "database_network": False}))
        return 0
    os.umask(0o077)
    manifest = private_json(ROOT / "manifest.json")
    before = verify_sources(manifest)
    output = args.output
    require(output.is_absolute() and output.resolve() == output and not output.exists(), "NEW_CANONICAL_OUTPUT_REQUIRED")
    require(args.python.is_absolute() and args.bun.is_absolute() and args.python.is_file() and args.bun.is_file(), "EXPLICIT_RUNTIMES_REQUIRED")
    output.mkdir(mode=0o700)
    results: dict[str, object] = {}
    result: dict[str, object] = {
        "schema": "s10-negative-comparison-v1", "status": "FAIL", "runs": results,
        "package_manifest_sha256": sha(ROOT / "manifest.json"),
        "runtime_sha256": {"python": sha(args.python), "bun": sha(args.bun)},
        "scope": "exact final tests; primary S10 baseline vs review-fixed source; no real HTTP/DB/E2E claim",
    }
    try:
        for language in ["python", "web"]:
            for arm in ["baseline", "candidate"]:
                label = f"{language}-{arm}"
                directory = output / label
                directory.mkdir(mode=0o700)
                tmp = directory / "tmp"
                tmp.mkdir(mode=0o700)
                work = directory / "work"
                stage_tree(ROOT / "payload" / language / arm, work)
                source_before = tree_hashes(work)
                environment = {
                    "PATH": os.defpath, "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
                    "TMPDIR": str(tmp), "NO_COLOR": "1", "FORCE_COLOR": "0",
                    "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "PYTHONDONTWRITEBYTECODE": "1",
                }
                receipt = directory / "observations.json"
                if language == "python":
                    argv = [str(args.python), "-I", "-B", str(ROOT / "python_child.py"), "--root", str(work), "--receipt", str(receipt)]
                else:
                    environment["S10_OFFLINE_RECEIPT"] = str(receipt)
                    argv = [str(args.bun), "test", "--preload", str(ROOT / "bun_preload.ts"),
                            "--reporter=junit", "--reporter-outfile", str(directory / "junit.xml"),
                            "--timeout", "10000", "./lib/e2e-audit-receipts.test.ts"]
                process = run_child(argv, work, directory, environment)
                write(directory / "process.json", process)
                results[label] = {"process": process, "source_before": source_before}
                require(not process["timeout"] and max(process["stdout_bytes"], process["stderr_bytes"]) < MAX_REPORT, "TIMEOUT_OR_LOG_LIMIT")
                observation = private_json(receipt)
                verdict = evaluate_python(arm, observation, process, work) if language == "python" else evaluate_web(arm, directory / "junit.xml", observation, process)
                source_after = tree_hashes(work)
                results[label]["source_after"] = source_after
                verdict["checks"]["executed_sources_unchanged"] = source_before == source_after
                if source_before != source_after:
                    verdict["status"] = "FAIL"
                verdict["observations_sha256"] = sha(receipt)
                write(directory / "verdict.json", verdict)
                results[label]["verdict"] = verdict
        after = verify_sources(manifest)
        result["package_sources_unchanged"] = before == after
        result["status"] = "PASS" if len(results) == 4 and all(item["verdict"]["status"] == "PASS" for item in results.values()) and before == after else "FAIL"
    except Exception as error:
        result["harness_failure_type"] = type(error).__name__
        # Ham exception/DSN/metin yerine yalnız kısıtlı runner sabit kodu.
        code = str(error)
        result["harness_failure_code"] = code if re.fullmatch(r"[A-Z_]{1,80}", code) else "HARNESS_FAILURE"
    write(output / "result.json", result)
    print(json.dumps({"status": result["status"], "result_sha256": sha(output / "result.json"), "runs_recorded": len(results)}))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
