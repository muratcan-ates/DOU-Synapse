# S10 review-fix negatif/pozitif karşılaştırma adayı

Durum: geçici paket hazırlandı; **deney/test/CLI çalıştırılmadı**. Yalnız dosyalar okundu, kopyalandı, SHA256 hesaplandı ve Python AST parse edildi. Repo, özgün S10 adayı ve review-fix paketi değişmedi. Root gerçek koşuyu kendisi başlatacak.

## Dondurulan fark

| Dil | Eski primary S10 | İncelenmiş düzeltme | İki kolda aynı test |
|---|---|---|---|
| Python `logging.py` | `f715cbd53f17d0e4f3b0ecf6a6d81a2e3948a9c2900ff9ee783035c14d3f5c14` | `2d6c0368b20ae7634452438581921b409725bbcae7be9e69df302be0093a5610` | `2bc590c975e76f0be3dff339f0c5d542cee38eb8a31fcb9ea17b5d3bfb5525ec` |
| Bun `audit-receipts.ts` | `e8fc2601d438fb19777f9680c8a2ddb1ae89e1d47dc73c24c5808d29176727c2` | `a5a51968de4456729f8cbe214d4a683665b64514e81f93ffdf8b982dc7ce02b6` | `06d0005b1aee8193dc764ab2388efcd3e7d8d9d7f564e92509fc3cfa5f255e50` |

`request_context.py` iki kolda aynı `78be6a5d5c38a1af56b7cfaa7227da068880ada1745385df302b876bfcf9d858` dosyasıdır. Nihai Python testindeki root import sıralaması aynen korunur; review-fix paketinin eski `4018…` test kopyası çalıştırılmaz. `origins.json` her kopyanın tam kaynak yolunu ve özetini içerir. Web destek dizininde mevcut bütün `.spec.ts` kaynaklarının donmuş kopyaları vardır; bunlar yalnız testin kaynak envanteri kontrolünde okunur, Playwright tarafından çalıştırılmaz. `fixtures.ts` aynı özgün destek dosyasıdır, el yapımı stub değildir.

## Root yürütmesi

Yeni ve henüz var olmayan özel sonuç diziniyle:

```sh
python3 /private/tmp/dou018-s10-negative-candidate/run.py \
  --python /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python \
  --bun /Users/muratates/.bun/bin/bun \
  --output /private/tmp/dou018-s10-negative-result-01 \
  --execute
```

`--execute` yoksa yalnız plan JSON'u çıkar; test/DB/ağ çağrısı yapılmaz. Çalıştırıcı dört child'ı sırayla başlatır: Python eski, Python düzeltilmiş, Bun eski, Bun düzeltilmiş. Her child için 90 saniye duvar saati sınırı, Bun test başına 10 saniye sınırı vardır. Uygulama sunucusu, DB, paket kurulumu veya tarayıcı başlatılmaz. Test çıktıları mevcut sonuç dizininin üstüne yazılamaz; dizin ve dosyalar 0700/0600 oluşturulur. Hata halinde ilk çıktı korunur; aynı dizin yeniden kullanılmaz.

Paket kaynakları çalıştırmadan önce/sonra doğrulanır; gerçek çalıştırılan her arm'ın kaynakları da önce/sonra hash'lenir. Runtime binary hash'leri ve Python/pytest/FastAPI/Starlette/Bun sürümleri makbuzlara girer. Her child'ın stdout, stderr, gözlem, process ve karar dosyaları saklanır; üst çıktı yalnız durum, sonuç özeti ve dört child sayısını taşır. Ham olumsuz test çıktısındaki sabit canary sentetiktir; loglar yayınlanmadan önce mevcut arşiv incelemesinden geçirilmelidir.

## Python kabulü: assertion ile kurulum hatasını ayır

Python `-I -B` ile izole başlatılır. Her arm küçük gerçek `app/core` paketine sahiptir; `app.core.logging` ve `app.core.request_context` **normal import** yoluyla tek kez yüklenir. `importlib` alias ile ikinci bir `ServerRequestId` sınıfı üretilmez. Test modülü, logging modülü ve request_context sınıfının birebir aynı nesne olduğunu koleksiyon sırasında altı kez ölçer. Modül yolları ve byteSHA'ları ayrıca kaydedilir.

Repo `conftest.py` yüklenmez; empty `pytest.ini`, `--noconftest` ve plugin autoload kapatma DB fixture veya gizli addopts kullanımını önler. Seçilen node yalnız `test_tuple_values_cannot_bypass_context_or_extra_redaction`: plain/internal/subclass × filtre yok/var = **6 çağrı**. Ağ audit olayları ve DB kitaplık importları reddedilir, sayaçlar sıfır olmalıdır; süreç oluşturma girişimi de başarısız sayılır.

Eski kol ancak şu bileşik koşulla beklenen negatif kabul edilir: altı doğru parametre, aynı module/class kimliği, 6 gerçek call FAIL, 12 setup/teardown PASS, koleksiyon hatası yok, pytest exit1 ve her hata **tam test dosyasındaki 153. satır `assert DIGIT_RUN_UUID.hex not in output` için AssertionError**. ImportError, TypeError, fixture hatası, başka satırdaki assertion veya 0 test negatif kanıt değildir. Düzeltilmiş kolda aynı altı call ve 12 setup/teardown PASS, exit0 gerekir.

## Web kabulü: gerçek test, taklit fetch

Bun aynı nihai `lib/e2e-audit-receipts.test.ts` dosyasının **17 testini** çalıştırır. İki kol yalnız collector kaynak dosyasında ayrılır. Bun'un JUnit raporu test adları ve failure/error/skip ayrımıyla incelenir. Eski kolda yalnız şu altı test assertion nedeniyle FAIL olmalı; diğer 11 test PASS kalmalı:

- Tracked isteğin başka origin, audit dışı rota, başka action veya başka actor yanıtıyla tamamlanması: dört test.
- Audit fetch için çağıranın `redirect:follow` seçiminin bastırılmaması: bir test.
- Audit fetch'in farklı son URL'yi sessizce kabul etmesi: bir test.

Düzeltilmiş kol **17 PASS, 0 FAIL** olmalıdır. Tam 17 benzersiz testcase, error/skip yokluğu, beklenen failure adları ve assertion imzası birlikte şarttır. Eksik JUnit, desteklenmeyen CLI, import/parse hatası, beklenmeyen test adı veya transport guard hatası başarısız karşılaştırmadır; üründe kusur kanıtına çevrilmez. Rapor biçimi henüz bu adayla gerçek Bun çalıştırmasında doğrulanmadı; böyle bir kurulum hatasında özgün sonuç korunarak ayrı aday hazırlanmalı.

Preload gerçek `fetch` referansını teste vermez; testlerin açık mock fonksiyonları kullanılır. Dört mock ataması/çağrısı ve sıfır unmocked fetch girişimi beklenir. Bun/native modüllerinin tümü için genel bir sandbox iddiası yoktur: byte ile sabitlenen destek grafiğinde ağ/DB/process transportu bulunmaz; yalnız bu dört açık fetch mock'u vardır. Dolayısıyla bu koşu gerçek HTTP redirect, gerçek DB audit üretimi/silme veya E2E hedef sahipliği kanıtı değildir. Gerçek süreç/PG/E2E kabulleri root'un ayrı güvenilmiş hedefinde devam eder.

## Donma ve sınır

`manifest.json` tüm kaynak/harness/support dosyalarını özetler ve iki arm arasındaki izinli tek runtime farkını kaydeder. Sonuçlar bu paketin içine yazılmaz. Kök kaynaklara, `.env` dosyalarına, gerçek kullanıcılara veya önceki DB hedeflerine erişim yoktur. Bu hazırlık yeni bir güvenlik kusurunu ölçülmüş diye kapatmaz; gerçek kırmızı/yeşil sonucu root çalıştırması belirleyecek.

V2 düzeltmesi: Bun 1.3.14 beklenen test hatalarından sonra process exit dinleyicisinin makbuzunu üretmedi. İlk çıktı /private/tmp/dou018-s10-negative-result-01 içinde değişmez. Sayaç makbuzu şimdi bun:test afterAll aşamasında yazılır; aynı 17 JUnit testini ve beklenen kesin hataları değerlendiren oracle değişmedi. Bu yeni harness henüz çalıştırılmadı.
