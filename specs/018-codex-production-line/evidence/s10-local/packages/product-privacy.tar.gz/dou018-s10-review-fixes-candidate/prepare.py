from pathlib import Path
import hashlib,json,difflib
src=Path('/private/tmp/dou018-s10-next-candidate')
out=Path('/private/tmp/dou018-s10-review-fixes-candidate')
paths=[
'apps/api/app/core/logging.py',
'apps/api/tests/test_server_request_id.py',
'apps/web/e2e/audit-receipts.ts',
'apps/web/lib/e2e-audit-receipts.test.ts',
]
for p in paths:
 for d in ['base','files']:
  target=out/d/p
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes((src/'files'/p).read_bytes())
p=out/'files'/paths[0]
s=p.read_text()
old='''    if isinstance(value, list):
        return [_redact_any(v) for v in value]
'''
new='''    if isinstance(value, (list, tuple)):
        # JSON her ikisini de diziye çevirir; tuple içindeki metin muaf değildir.
        return [_redact_any(v) for v in value]
'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
p=out/'files'/paths[1]
p.write_text(p.read_text()+'''

@pytest.mark.parametrize("kind", ["plain", "internal", "subclass"])
@pytest.mark.parametrize("use_filter", [False, True])
def test_tuple_values_cannot_bypass_context_or_extra_redaction(
    monkeypatch: pytest.MonkeyPatch, kind: str, use_filter: bool
) -> None:
    """Sıradan JSON dizisine dönüşen tuple, doğrudan alan muafiyeti kazanmaz."""
    monkeypatch.setattr(request_context, "uuid4", lambda: DIGIT_RUN_UUID)

    class OtherId(ServerRequestId):
        pass

    values = {
        "plain": DIGIT_RUN_UUID.hex,
        "internal": ServerRequestId(),
        "subclass": OtherId(),
    }
    value = values[kind]
    for logger_name in ("app.request", "app.error", "app.other"):
        record = logging.LogRecord(logger_name, logging.INFO, __file__, 1, "sabit", (), None)
        record.context = {
            "request_id": (value,),
            "nested": ({"request_id": value}, [("value", value)]),
        }
        record.detail = (value, {"values": [value]})
        if use_filter:
            assert RedactionFilter().filter(record)
        output = JsonFormatter().format(record)
        payload = json.loads(output)
        assert DIGIT_RUN_UUID.hex not in output
        assert "[REDACTED_TCKN]" in payload["context"]["request_id"][0]
        assert "[REDACTED_TCKN]" in payload["context"]["nested"][0]["request_id"]
        assert "[REDACTED_TCKN]" in payload["context"]["nested"][1][0][1]
        assert "[REDACTED_TCKN]" in payload["detail"][0]
        assert "[REDACTED_TCKN]" in payload["detail"][1]["values"][0]
''')
p=out/'files'/paths[2]
s=p.read_text()
old='''  private readonly pending = new Set<object>();'''
new='''  private readonly pending = new Map<object, Pick<AuditReceipt, "actorId" | "action">>();'''
assert s.count(old)==1;s=s.replace(old,new)
old='''  begin(key: object, url: string, method: string, authorization?: string): void {
    if (isAuditedRequest(url, method, authorization, this.scope.apiOrigin)) this.pending.add(key);
  }
'''
new='''  begin(key: object, url: string, method: string, authorization?: string): void {
    if (isAuditedRequest(url, method, authorization, this.scope.apiOrigin)) {
      // Ham başlık/sorgu saklanmaz. Beklenen rota ve sentetik aktör yalnız
      // bu isteğin tamamlandığını doğrulamak için bellekte tutulur.
      this.pending.set(key, {
        actorId: authorization!.slice("Bearer dev:".length),
        action: `${method.toUpperCase()} ${new URL(url).pathname}`,
      });
    }
  }
'''
assert s.count(old)==1;s=s.replace(old,new)
old='''      const receipt = receiptFromResponse(observation, this.scope.apiOrigin);
      if (receipt) writePrivate(
        join(this.directory, "receipts", `${process.pid}-${randomUUID()}.json`), receipt,
      );
      if (key) this.pending.delete(key);
'''
new='''      const receipt = receiptFromResponse(observation, this.scope.apiOrigin);
      const expected = key === undefined ? undefined : this.pending.get(key);
      if (expected && (!receipt || receipt.actorId !== expected.actorId ||
          receipt.action !== expected.action)) {
        // Başka origin/rota/aktör yanıtı izlenen isteği tamamlamaz. Makbuz
        // yazılmaz; catch başarısız durumu ve pending kaydını korur.
        throw new Error("İzlenen audit isteği ile yanıt makbuzu uyuşmuyor.");
      }
      if (receipt) writePrivate(
        join(this.directory, "receipts", `${process.pid}-${randomUUID()}.json`), receipt,
      );
      if (expected && key) this.pending.delete(key);
'''
assert s.count(old)==1;s=s.replace(old,new)
old='''      const response = await fetch(url, init);'''
new='''      // Audit isteğini otomatik başka bir hedefe/rotaya taşıma. İlgisiz
      // kaynak isteklerinde çağıranın mevcut fetch seçimi değişmez.
      const response = await fetch(url, this.pending.has(key) ? { ...init, redirect: "error" } : init);'''
assert s.count(old)==1;s=s.replace(old,new)
p.write_text(s)
p=out/'files'/paths[3]
p.write_text(p.read_text()+'''

for (const mismatch of [
  { label: "başka origin", changed: { url: "http://127.0.0.1:18018/admin/overview" } },
  { label: "audit dışı rota", changed: { url: `${scope.apiOrigin}/courses` } },
  { label: "başka audit action", changed: { url: `${scope.apiOrigin}/admin/courses` } },
  { label: "başka sentetik aktör", changed: {
    authorization: "Bearer dev:22222222-2222-2222-2222-222222222222",
  } },
]) {
  test(`izlenen istek ${mismatch.label} yanıtıyla sessizce tamamlanmaz`, () => {
    withDirectory((directory) => {
      const capture = new AuditCapture(directory, scope);
      const key = {};
      capture.begin(key, observation.url, observation.method, observation.authorization);
      expect(() => capture.record({ ...observation, ...mismatch.changed }, key)).toThrow();
      expect(readdirSync(join(directory, "receipts"))).toEqual([]);
      expect(() => capture.finish()).toThrow();
      expect(() => loadAuditReceipts(directory, scope)).toThrow();
    });
  });
}

test("izlenmemiş kaynak olayı pending audit isteğini bozmaz veya tamamlamaz", () => {
  withDirectory((directory) => {
    const capture = new AuditCapture(directory, scope);
    const audited = {};
    const unrelated = {};
    capture.begin(audited, observation.url, observation.method, observation.authorization);
    capture.begin(unrelated, `${scope.apiOrigin}/courses`, "GET");
    capture.record({ url: `${scope.apiOrigin}/courses`, method: "GET", status: 200 }, unrelated);
    expect(readdirSync(join(directory, "receipts"))).toEqual([]);
    capture.record(observation, audited);
    capture.finish();
    expect(loadAuditReceipts(directory, scope)).toEqual([{
      requestId: id, actorId, action: "GET /admin/overview", result: "allowed",
    }]);
  });
});

test("audit fetch yönlendirmeyi reddeder ve yanıt kaybında incomplete kalır", async () => {
  const directory = initializeAuditCapture(scope);
  const original = globalThis.fetch;
  try {
    globalThis.fetch = (async (_input: RequestInfo | URL, init?: RequestInit) => {
      expect(init?.redirect).toBe("error");
      throw new TypeError("sentetik yönlendirme reddi");
    }) as typeof fetch;
    const capture = new AuditCapture(directory, scope);
    await expect(capture.fetch(observation.url, {
      headers: { Authorization: observation.authorization }, redirect: "follow",
    })).rejects.toThrow("sentetik yönlendirme reddi");
    expect(readdirSync(join(directory, "receipts"))).toEqual([]);
    expect(() => capture.finish()).toThrow();
    expect(() => loadAuditReceipts(directory, scope)).toThrow();
  } finally {
    globalThis.fetch = original;
    rmSync(directory, { recursive: true });
  }
});

test("audit fetch farklı son URL yanıtını güvenilir makbuz saymaz", async () => {
  const directory = initializeAuditCapture(scope);
  const original = globalThis.fetch;
  try {
    globalThis.fetch = (async () => {
      const response = new Response("{}", { status: 200 });
      // Yalnız transport sonucu sözleşmesi: gerçek HTTP redirect deneyi değildir.
      Object.defineProperty(response, "url", { value: `${scope.apiOrigin}/courses` });
      return response;
    }) as typeof fetch;
    const capture = new AuditCapture(directory, scope);
    await expect(capture.fetch(observation.url, {
      headers: { Authorization: observation.authorization },
    })).rejects.toThrow("Audit yanıt makbuzu kaydedilemedi.");
    expect(() => capture.finish()).toThrow();
    expect(() => loadAuditReceipts(directory, scope)).toThrow();
  } finally {
    globalThis.fetch = original;
    rmSync(directory, { recursive: true });
  }
});

test("audit dışı fetch çağıranın redirect seçimini korur ve makbuz üretmez", async () => {
  const directory = initializeAuditCapture(scope);
  const original = globalThis.fetch;
  try {
    globalThis.fetch = (async (_input: RequestInfo | URL, init?: RequestInit) => {
      expect(init?.redirect).toBe("follow");
      return new Response("[]", { status: 200 });
    }) as typeof fetch;
    const capture = new AuditCapture(directory, scope);
    const response = await capture.fetch(`${scope.apiOrigin}/courses`, { redirect: "follow" });
    expect(await response.json()).toEqual([]);
    capture.finish();
    expect(loadAuditReceipts(directory, scope)).toEqual([]);
  } finally {
    globalThis.fetch = original;
    rmSync(directory, { recursive: true });
  }
});
''')
readme='''# S10 review fixes — tuple maskeleme ve tracked audit yanıtı

Yalnız `/private/tmp/dou018-s10-next-candidate` manifest `e1a52aa25b4e8f25764ee2541c46610f50963dc4ce7ef5f17c0f31681f6af114` üzerine dar aday. Orijinal paket ve repo değiştirilmedi. `base/` bu dört dosyanın orijinal S10 staged sürümüdür; `files/` onun üstündeki düzeltmedir. Root, önce tam S10'la birleştirip bu dört dosyanın base hash'ini doğrulamalı; S9 çalışma ağacına doğrudan toplu kopya değildir.

## Kaynak farkı

- `logging.py`: list ve tuple içeriği aynı recursive maskelemeden geçer. JSON'da ikisi zaten diziye dönüşür. Tam iç türün yalnız doğrudan `context.request_id` alanı muaf kalır. Keyfi Python `repr/str`, dictionary key veya yeni arbitrary container güvenliği iddiası eklenmez.
- `audit-receipts.ts`: pending Map, sentetik actor + sabit action'ı bellekte tutar. Tracked key'e ait null/wrong-origin/wrong-action/wrong-actor makbuzu başarısız olur; pending ve incomplete session korunur. İzlenmeyen normal kaynak olayları yok sayılmaya devam eder. Audit fetch'inde redirect:error zorlanır; audit dışı fetch aynı seçimle sürer.
- İki mevcut test dosyasına bu sınırların negatifleri eklenir. Ürün endpoint, audit SQL, migration veya cleanup DELETE genişlemesi yok.

## Oracle ve önerilen root doğrulaması

Bu adayda pytest/Bun/DB/tarayıcı/sunucu/ağ çalıştırılmadı. Kaynak okuma ve hash üretimi yapılmıştır; test başarı sayısı yoktur.

1. Normal API import yollarıyla `tests/test_server_request_id.py` ve S9 exception/sink sınırlarını root çalıştırsın. Yeni `test_tuple_values_cannot_bypass_context_or_extra_redaction` altı parametrik tuple örneğini üç logger'da hem filtreli hem yalnız formatter yoluyla kapsar. Orijinal S10 logging.py geri konduğunda yeni tuple oracles kırmızı olmalı; doğrudan trusted-ID pozitifleri düzeltilmiş sürümde yeşil kalmalı.
2. Web normal test ortamında `lib/e2e-audit-receipts.test.ts` ve `lib/e2e-cleanup.test.ts`; tsc. Dört tracked mismatch, unrelated kaynak, audit redirect kaybı, farklı son URL ve audit dışı redirect davranışını kontrol et. Orijinal S10 collector geri konduğunda mismatch ve redirect oracles kırmızı olmalı.
3. Fetch unit taklidi gerçek network redirect kanıtı değildir. Root'un sentetik gerçek süreç/E2E kabulünde audit rotasının redirect davranışı ölçülecekse redirect:error gerçekten takip etmemeli ve incomplete makbuz korunmalı. Temizliğin root/CI trusted target receipt + baseline/post audit muhasebesi hâlâ dış katkıdır; bu düzeltme bütün DB yazımlarının yakalandığını kanıtlamaz.
4. Mevcut route.fetch/browser aynı-ID tekilleştirme, Node denied 403, izinli 200, generic500 body/error-log sınırları ve iki gerçek PG koşusunun birbirini silmemesi kabulleri korunmalı. Orijinal `/private/tmp/dou018-s10-independent-review.md` raporu özgün donmuş paket içindir.
'''
(out/'README.md').write_text(readme)
def h(data):return hashlib.sha256(data).hexdigest()
patch='';rows=[]
for p in paths:
 base=(out/'base'/p).read_bytes();candidate=(out/'files'/p).read_bytes()
 rows.append({'path':p,'base_s10_candidate_sha256':h(base),'candidate_sha256':h(candidate)})
 patch+=''.join(difflib.unified_diff(base.decode().splitlines(keepends=True),candidate.decode().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
(out/'change.patch').write_text(patch)
manifest={
 'schema':'dou-s10-review-fixes-candidate-v1',
 'status':'prepared-not-tested-not-integrated',
 'source_candidate':str(src),
 'source_manifest_sha256':h((src/'manifest.json').read_bytes()),
 'source_review_sha256':h(Path('/private/tmp/dou018-s10-independent-review.md').read_bytes()),
 'staged_files':rows,
 'production_scope':['apps/api/app/core/logging.py'],
 'runtime_executed':False,'tests_executed':False,'repository_modified':False,
 'original_candidate_modified':False,
 'patch_sha256':h((out/'change.patch').read_bytes()),
 'README_sha256':h((out/'README.md').read_bytes()),
 'oracles':[
  'apps/api/tests/test_server_request_id.py::test_tuple_values_cannot_bypass_context_or_extra_redaction',
  'apps/web/lib/e2e-audit-receipts.test.ts: tracked response mismatch cases',
  'apps/web/lib/e2e-audit-receipts.test.ts: unrelated resource and audit/non-audit fetch cases',
 ],
 'still_required':['root/CI trusted target receipt and live identity guard','exclusive audit baseline/post accounting','root normal import tests/type checks','real network/process/PG/E2E acceptance'],
}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'files':rows,'patch_sha256':manifest['patch_sha256'],'manifest_sha256':h((out/'manifest.json').read_bytes()),'review_sha256':manifest['source_review_sha256']},indent=2))
