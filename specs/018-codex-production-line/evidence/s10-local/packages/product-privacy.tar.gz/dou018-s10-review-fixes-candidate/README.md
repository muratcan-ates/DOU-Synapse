# S10 review fixes — tuple maskeleme ve tracked audit yanıtı

Yalnız `/private/tmp/dou018-s10-next-candidate` manifest `e1a52aa25b4e8f25764ee2541c46610f50963dc4ce7ef5f17c0f31681f6af114` üzerine dar aday. Orijinal paket ve repo değiştirilmedi. `base/` bu dört dosyanın orijinal S10 staged sürümüdür; `files/` onun üstündeki düzeltmedir. Root, önce tam S10'la birleştirip bu dört dosyanın base hash'ini doğrulamalı; S9 çalışma ağacına doğrudan toplu kopya değildir.

## Kaynak farkı

- `logging.py`: list ve tuple içeriği aynı recursive maskelemeden geçer. JSON'da ikisi zaten diziye dönüşür. Tam iç türün yalnız doğrudan `context.request_id` alanı muaf kalır. Keyfi Python `repr/str`, dictionary key veya yeni arbitrary container güvenliği iddiası eklenmez.
- `audit-receipts.ts`: pending Map, sentetik actor + sabit action'ı bellekte tutar. Tracked key'e ait null/wrong-origin/wrong-action/wrong-actor makbuzu başarısız olur; pending ve incomplete session korunur. İzlenmeyen normal kaynak olayları yok sayılmaya devam eder. Audit fetch'inde redirect:error zorlanır; audit dışı fetch aynı seçimle sürer.
- İki mevcut test dosyasına bu sınırların negatifleri eklenir. Ürün endpoint, audit SQL, migration veya cleanup DELETE genişlemesi yok.

## Oracle ve önerilen root doğrulaması

Bu adayda pytest/Bun/DB/tarayıcı/sunucu/ağ çalıştırılmadı. Kaynak okuma ve hash üretimi yapılmıştır; test başarı sayısı yoktur.

1. Normal API import yollarıyla `tests/test_server_request_id.py` ve S9 exception/sink sınırlarını root çalıştırsın. Yeni `test_tuple_values_cannot_bypass_context_or_extra_redaction` altı parametrik tuple örneğini üç logger'da hem filtreli hem yalnız formatter yoluyla kapsar. Orijinal S10 logging.py geri konduğunda yeni tuple oracles kırmızı olmalı; doğrudan trusted-ID pozitifleri düzeltilmiş sürümde yeşil kalmalı.
2. Web normal test ortamında `lib/e2e-audit-receipts.test.ts` ve `lib/e2e-cleanup.test.ts`; tsc. Dört tracked mismatch, unrelated kaynak, audit redirect kaybı, farklı son URL ve audit dışı redirect davranışını kontrol et. Orijinal S10 collector geri konduğunda mismatch ve redirect oracles kırmızı olmalı.
3. Fetch unit taklidi gerçek network redirect kanıtı değildir. Root'un sentetik gerçek süreç/E2E kabulünde audit rotasının redirect davranışı ölçülecekse redirect:error gerçekten takip etmemeli ve incomplete makbuz korunmalı. Temizliğin root/CI trusted target receipt + baseline/post audit muhasebesi hâlâ dış katkıdır; bu düzeltme bütün DB yazımlarının yakalandığını kanıtlamaz.
4. Mevcut route.fetch/browser aynı-ID tekilleştirme, Node denied 403, izinli 200, generic500 body/error-log sınırları ve iki gerçek PG koşusunun birbirini silmemesi kabulleri korunmalı. Orijinal `/private/tmp/dou018-s10-independent-review.md` raporu özgün donmuş paket içindir.
