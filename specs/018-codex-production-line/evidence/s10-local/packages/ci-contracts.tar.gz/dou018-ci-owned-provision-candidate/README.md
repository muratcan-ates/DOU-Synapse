# CI'ye ait yeni E2E veritabanı — hazırlık adayı

Bu paket henüz çalıştırılmadı. Python AST ve Ruff statik kontrolleri yapılmıştır;
çevrimdışı testler, Docker, PostgreSQL ve tarayıcı çalıştırmaları root'a aittir.
Mevcut repo, donmuş S10 süreç paketi ve eski kanıtlar değiştirilmemiştir.

## Somut sınır

`files/scripts/provision_ci_e2e.py`, yalnız GitHub `e2e` işinin kendisinin
oluşturduğu, pinli PostgreSQL 16 / pgvector 0.8.6 servisinde çalışır. Çağıran tam
`job.services.postgres.id` değerini verir. Bu değer ve GitHub runner/Docker daemon
güveni yetkinin kaynağıdır; hash, ortamda `GITHUB_ACTIONS=true` görmek veya
çalışır bir sunucu keşfetmek kendi başına sahiplik yetkisi değildir.

Bu araç mevcut bir yerel PostgreSQL'i sahiplenmez. `docker --host
unix:///var/run/docker.sock` ve `/usr/bin/docker` açıkça seçilmiştir. Ortamdaki
Docker context/host/TLS değişkenleri kullanılmaz. Yerel macOS Docker Desktop,
uzak Docker daemon, paylaşılan runner, rootless Docker, çok ağlı servis,
PostgreSQL 17 ve yerel pgvector 0.8.0 bu adayın kabul kapsamı dışındadır.

## Önceden sabit kabul sırası

1. Tam container ID, çalışan durum, **tam pinli image reference**, immutable image
   ID ve RepoDigest birlikte doğrulanır. Dar inspect projection hiçbir container
   environment değeri toplamaz; ağ bilgisinden yalnız tek private numeric IPv4
   kalıcı makbuza alınır. 5432/tcp published port eşlemesi açık host portuyla
   uyuşmalıdır. Host bağlantısı her zaman `127.0.0.1` + `hostaddr=127.0.0.1` olur.
2. Container içindeki yeni `env -i` psql oturumu TCP ile bu iç IP/5432'ye bağlanır.
   Cluster system identifier, `postgres` DB OID, sürüm, server address/port,
   gerçek/session kullanıcı ve superuser/recovery durumu okunur. Yalnız
   `postgres/template0/template1` DB'leri ve postgres/yerleşik pg_* rolleri
   bulunmalıdır. Mevcut `dou_synapse` veya uygulama rolleri CREATE'den önce reddedilir.
3. Aynı kimlik host'un açık numeric yolu üzerinden de **CREATE öncesi** doğrulanır.
   CREATE yalnız container'ın sahip olunan yolunda, `IF NOT EXISTS` olmadan
   `CREATE DATABASE dou_synapse TEMPLATE template0` ile yapılır. Çakışma başarıya
   çevrilmez; existing DB DROP edilmez. Yeni OID ve aynı cluster içeriden okunur.
4. Yeni DB'nin host kimliği, içerden gözlenen yeni OID/cluster/adres/sürüm ile tam
   eşleşmeden hiçbir göç, seed veya rol-password SQL'i yürütülmez. Tüm SQL dosyaları
   aynı doğrulanmış fiziksel host bağlantısında uygulanır; her dosyadan önce hedef
   ve kaynak tekrar doğrulanır. Mevcut tüm göçler dosya adı sırasıyla okunur;
   yinelenen sıra numarası, symlink ve psql meta-komutu reddedilir. Kaynaklar
   belleğe alınan baytlarıyla çalışır, SHA256'ları makbuza yazılır.
5. Mevcut `supabase/local_dev_setup.sql` **byte-exact** kullanılır; sabit SHA ile
   korunur. Önce üç uygulama rolü beklenen NOLOGIN/superuser/BYPASSRLS sınırlarında
   ve ek rol üyeliği olmadan bulunmalıdır. SQL yeni CI rollerine mevcut sentetik
   LOGIN/password ayarlarını verir. Sonrasında app BYPASSRLS=false, worker=true;
   ikisi de superuser/CREATEDB/CREATEROLE/REPLICATION=false olarak doğrulanır.
   Host üzerinden gerçek dou_app/dou_worker password bağlantıları aynı DB OID ve
   adresi görmelidir; onlara `pg_control_system()` yetkisi verilmez.
6. Mevcut `seed_demo.sql` aynen uygulanır; vector=0.8.6, iki profil, bir platform
   yöneticisi, sıfır başlangıç audit kaydı beklenir. Kapanışta servis ve tüm SQL
   kaynakları tekrar eşleştirilir. Ancak bunlar geçince pins üretilir.

Yeni GRANT/ALTER ROLE üretmedik. Existing local SQL'in sabit database adı nedeniyle
DB adı `dou_synapse` kalır; izolasyon yeni container/küme ve gözlenen CREATE/OID
üzerindedir. Uygulama üyeliği sayımı yalnız dou_app/dou_worker/dou_auth_bridge'ye
dokunan `pg_auth_members` kayıtlarını kapsar; PostgreSQL'in yerleşik monitor
üyeliklerini yanlışlıkla sıfır sayma şartı yoktur.

## Çıktı ve mevcut adapter

Yeni private 0700 dizinde `postgres.pgpass` 0600 normal dosyadır; yalnız açık
127.0.0.1/port/database/user eşleşmelerinin sentetik CI parolalarını taşır. `PG*`
ortam değişkenleri driver import/bağlantısından önce temizlenir. `.pgpass` veya
PGSERVICE keşfiyle başka kullanıcı/rota seçilmez. Dosyayı artifact'a yüklemeyin.

`created.json` ayrı CREATE makbuzudur. `provision.json` source hashes ve doğrulama
sonuçlarını; `pins.json` mevcut `e2e_audit_guard.py` **tam** şemasını;
`handoff.json` pins yolu/hash/passfile/runId değerlerini taşır.
`issuer=github-owned-service`, `ownership=exclusive-synthetic`;
`provisionSha256` gerçek provision makbuzunu bağlar.

`run_owned_e2e.py` şu parametrelerle çağrılır: `--repo`, `--pins`,
`--pins-sha256`, `--passfile`, `--output`, `--run-id`, `--web-port` ve isteğe bağlı
`--webpack`. **`--mode` yoktur.** `workflow-steps.example.yml` root için entegrasyon
örneğidir, mevcut iş akışına uygulanmamıştır.

**Adapter eşleşmesi:** `cleanup.ts` sabit dou_synapse adına yalnız
`CI=true` **ve** `GITHUB_ACTIONS=true` durumunda izin veriyor. İncelenen 180b5e5e
adapter web_env'de ikinci işareti geçirmiyordu. Root'un son `d0db75dce445efc26a1d77944bcd680e023c3750597f1420bfeee2938f1ffd6a`
sürümü bağımsız salt okunur kaynak kontrolünde, GitHub-owned pins için parent
`CI=true/GITHUB_ACTIONS=true` şartını ve child'a kontrollü aktarımı içeriyor.
Bu eşleşme kaynak düzeyinde çözülmüştür; gerçek E2E kabulünü root ayrıca ölçüyor.
Bu pakette adapter değiştirilmedi.

## Root'un çalıştıracağı kontroller

Çevrimdışı sözleşme testleri (DB ve Docker çağrıları stub ile değiştirilir):

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-ci-owned-provision-candidate/files/scripts/test_provision_ci_e2e.py
```

13 unittest yöntemi; bazıları birden çok olumsuz girdiyi kapsar. Yanlış ID/image,
port/ağ/CIDR, wrong cluster/OID/server identity, existing DB/shared role,
source drift, role membership, CI bağlamı, geçerli private handoff ve gerçek
subprocess/psycopg çağrılarının ortam/argüman sınırları kontrol edilir. Stub
pozitifinin geçmesi gerçek Docker/SQL sonuçlarını kanıtlamaz.

Gerçek kontrol ayrı, yeni sahip olunan GitHub Linux servisinde yapılmalıdır:

- exact tag+RepoDigest ve host DNAT server IP varsayımını gerçek inspect/PG ile ölç;
- ilk kurulumun son kaydı PASS, pins/hash eşit, app/worker gerçek bağlantıları doğru;
- aynı servise ikinci çağrı `FRESH_SERVICE_REQUIRED` ile, CREATE/rol değişimi yok;
- yanlış mapped port veya başka fresh service ID/host eşlemi ile başlamayı reddet;
- mevcut API adapter gerçek tarayıcı koşusu + API durmuş makbuzu + audit baseline
  korunması/ek kayıt sıfır son muhasebesi ayrı kanıt olsun.

Doğrulayıcılar arasında yetkili DBA/Docker yöneticisinin hedefi değiştirmediği
operasyon varsayımı vardır. İki transport gözlemi bu aktörlere karşı atomik kilit
değildir. Başarısız CREATE yanıtında sonucun belirsiz olması dahil hiçbir durumda
otomatik DROP/rol geri alma yapılmaz; servis GitHub job yaşam döngüsüne bırakılır.
Hata stdout'ta yalnız sabit kodla raporlanır; önceki çıktı dizinine yazılmaz ve
başarı pins'i basılmaz. Kısmi göçler aynı container'da yeniden denenmez; yeni servis
gerekir. Bu teknik yerel/CI kabul, hosted veya hukuki uygunluk iddiası değildir.
