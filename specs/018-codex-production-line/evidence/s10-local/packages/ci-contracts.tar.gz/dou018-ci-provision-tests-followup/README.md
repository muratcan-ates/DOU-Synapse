# CI provisioning test follow-up — P3 ordering gate

Only a test overlay is prepared. The original helper, its frozen 13-test package, the repository, and previous evidence remain unchanged. No test, DB, Docker, subprocess or network execution was performed; the patched Python file was parsed as AST only.

Upstream package: `/private/tmp/dou018-ci-owned-provision-candidate`, manifest `4d0fe7c583a163335c9894e1be387d35fbb75389db847f78dc42e78c59fb0a25`. Helper SHA `21f9aaa93c80bb378b3f7a395465d932e00b2ad1b447b46db750ff055ecad18f`; original test SHA `023e13690a32a6417d1ba4583ce5e2ae759d160ef98c5337e3fecc86f54b11f7`.

The overlay has 14 unittest methods: the same 13 tests, with the source-order assertion strengthened, plus one new late identity change test. It is not “14 additional tests.” The unchanged local bootstrap fixture is copied byte-for-byte only to let the overlay run from its own directory.

Changes:

1. The existing ordering test now searches only the events **after the preceding source and before the current source**. The first source's identity read can no longer satisfy every later source's gate.
2. The new test injects a different observed cluster only when one source has already been applied. The real provision function must reject before applying the bootstrap/password source or seed. It preserves the earlier CREATE receipt and asserts no `provision.json`, `pins.json` or `handoff.json` success files. The runtime is the existing offline Backend/Connection double; no DB claim is made.

Root can run the original 13 tests unchanged, then this overlay. To import the exact frozen helper while using the overlay's colocated fixture:

```sh
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/private/tmp/dou018-ci-owned-provision-candidate/files/scripts \
/Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python \
/private/tmp/dou018-ci-provision-tests-followup/files/scripts/test_provision_ci_e2e.py
```

Source hashes must be checked against the manifests immediately before and after root execution. The import path deliberately points to the frozen helper; do not silently select a different repository or globally installed module.

The patch applies to `scripts/test_provision_ci_e2e.py` when root stages the original package. The bootstrap fixture is unchanged and needs no source diff. A negative control may remove only the repeated per-source identity check in a new disposable helper copy while retaining the first new-DB identity check: the strengthened ordering test and late mismatch test should fail. That mutation has **not** been made or run here and must not affect the frozen helper. Existing tests retain their original assertions; failures must not be reclassified as actual Docker/DB evidence.
