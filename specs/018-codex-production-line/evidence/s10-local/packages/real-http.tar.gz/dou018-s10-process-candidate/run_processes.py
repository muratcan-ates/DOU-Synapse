"""Root yürütür: iki kaynak kolu × iki gerçek HTTP protokolü, yalnız özel loopback."""

from __future__ import annotations

import argparse
import ast
import hashlib
import http.client
import json
import os
import re
import shutil
import socket
import subprocess
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any
from uuid import UUID

from common import (
    ARMS,
    HERE,
    PROTOCOLS,
    PYTHON,
    ProbeFailure,
    digest,
    read_logs,
    require,
    source_plan,
    verify_runtime,
    verify_sources,
    write_json,
)

PUBLIC_ERROR_MESSAGE = "İşlem tamamlanamadı. Lütfen daha sonra tekrar deneyin."
CLIENT_IDS = {
    "ordinary": "s10-ordinary-trace",
    "ascii": "S10_SYNTHETIC_AyseYilmaz_Student01234",
    "uuid": "fedcba98-7654-4321-8fed-cba987654321",
    "first": "s10-first-duplicate-header",
    "second": "s10-second-duplicate-header",
    "reuse": "s10-reused-by-client",
    "concurrent": "s10-concurrent-client-choice",
}
# Yalnız bilinen S9 başlıksız-UUID zayıflığı için tarihsel gözlem. Candidate bu
# dönüşümü kullanamaz: onda ham server ID ile günlük bire bir eşleşmek zorunda.
OLD_DIGIT_MASK = re.compile(r"(?<!\d)\d{11}(?!\d)")


def cases() -> list[dict[str, Any]]:
    values = [
        ("no-header", "/health/live", [], False),
        ("ordinary", "/health/live", [CLIENT_IDS["ordinary"]], False),
        ("ascii", "/health/live", [CLIENT_IDS["ascii"]], False),
        ("uuid", "/health/live", [CLIENT_IDS["uuid"]], False),
        ("duplicate", "/courses", [CLIENT_IDS["first"], CLIENT_IDS["second"]], False),
        ("ascii-401", "/courses", [CLIENT_IDS["ascii"]], False),
        ("reuse-one", "/health/live", [CLIENT_IDS["reuse"]], False),
        ("reuse-two", "/health/live", [CLIENT_IDS["reuse"]], False),
        ("error-ascii", "/__s10_probe__/error", [CLIENT_IDS["ascii"]], True),
        ("error-uuid", "/__s10_probe__/error", [CLIENT_IDS["uuid"]], True),
    ]
    values += [
        (f"concurrent-{index}", "/health/live", [CLIENT_IDS["concurrent"]], False)
        for index in range(4)
    ]
    return [
        {"case": name, "path": path, "ids": ids, "error": error}
        for name, path, ids, error in values
    ]


def environment(stage: Path, passfile: Path) -> dict[str, str]:
    return {
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
        "LANG": "en_US.UTF-8",
        "PYTHONPATH": str(stage),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONUNBUFFERED": "1",
        "ENVIRONMENT": "local",
        "DEV_AUTH_ENABLED": "true",
        "API_VERSION": "0.1.0",
        "SUPABASE_JWT_SECRET": "",
        "SUPABASE_JWT_ISSUER": "",
        "DATABASE_URL": "postgresql+psycopg://dou_app:synthetic_probe_only@127.0.0.1:9/s10_never_connect",
        "WORKER_DATABASE_URL": "postgresql+psycopg://dou_worker:synthetic_probe_only@127.0.0.1:9/s10_never_connect",
        "PGPASSFILE": str(passfile),
        "EMBEDDING_PROVIDER": "hashing",
        "EMBEDDING_WARMUP_ENABLED": "false",
        "LLM_FAKE_PROVIDER": "true",
        "EVAL_RUNTIME_ENABLED": "false",
        "GROQ_API_KEY": "",
        "GEMINI_API_KEY": "",
        "OPENAI_API_KEY": "",
        "HF_HUB_OFFLINE": "1",
        "HF_DATASETS_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
        "HTTP_PROXY": "",
        "HTTPS_PROXY": "",
        "ALL_PROXY": "",
        "NO_PROXY": "127.0.0.1",
    }


def encoded(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def fetch(
    port: int,
    case: dict[str, Any],
    arm: str,
    directory: Path,
    barrier: threading.Barrier | None = None,
) -> dict[str, Any]:
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    try:
        if barrier is not None:
            barrier.wait(timeout=5)
        method = "POST" if case["error"] else "GET"
        payload = (
            encoded(json.loads((HERE / "fixture.json").read_text())) if case["error"] else None
        )
        # putheader her çağrıda ayrı alan üretir; dict kullanıp duplicate vakasını kaybetmeyiz.
        connection.putrequest(method, case["path"])
        for value in case["ids"]:
            connection.putheader("X-Request-ID", value)
        connection.putheader("Connection", "close")
        if payload is not None:
            connection.putheader("Content-Type", "application/json")
            connection.putheader("Content-Length", str(len(payload)))
        connection.endheaders(payload)
        response = connection.getresponse()
        body = response.read(65537)
        require(len(body) <= 65536, "RESPONSE_TOO_LARGE")
        response_headers = response.getheaders()
        write_json(
            directory / "wire" / (case["case"] + ".json"),
            {
                "status": response.status,
                "response_headers": response_headers,
                "body_hex": body.hex(),
                "body_sha256": hashlib.sha256(body).hexdigest(),
                "body_bytes": len(body),
            },
        )
        parsed = json.loads(body)
        header_id = response.getheader("X-Request-ID")
        expected_status = 500 if case["error"] else 401 if case["path"] == "/courses" else 200
        require(response.status == expected_status, "HTTP_STATUS")
        if response.status == 200:
            require(
                parsed == {"status": "ok", "environment": "local", "version": "0.1.0"},
                "HEALTH_BODY",
            )
            support_id = header_id
            normalized_body = parsed
        else:
            require(set(parsed) == {"error"}, "ERROR_ROOT_SCHEMA")
            require(set(parsed["error"]) == {"code", "message", "request_id"}, "ERROR_SCHEMA")
            require(
                parsed["error"]["code"]
                == ("internal_error" if case["error"] else "unauthenticated"),
                "ERROR_CODE",
            )
            require(
                type(parsed["error"]["message"]) is str and bool(parsed["error"]["message"]),
                "ERROR_MESSAGE",
            )
            if case["error"]:
                require(parsed["error"]["message"] == PUBLIC_ERROR_MESSAGE, "GENERIC_ERROR_MESSAGE")
                require(header_id is None, "EXISTING_500_HEADER_CONTRACT")
            support_id = parsed["error"]["request_id"]
            normalized_body = {"error": {**parsed["error"], "request_id": "<support-id>"}}
        require(type(support_id) is str and bool(support_id), "SUPPORT_ID_MISSING")
        if not case["error"]:
            require(header_id == support_id, "BODY_HEADER_ID_MISMATCH")
        if arm == "baseline" and case["ids"]:
            require(support_id == case["ids"][0], "BASELINE_FIRST_HEADER_ECHO")
        else:
            parsed_uuid = UUID(support_id)
            require(parsed_uuid.version == 4 and parsed_uuid.hex == support_id, "GENERATED_UUID4")
        if arm == "candidate":
            require(support_id not in CLIENT_IDS.values(), "CLIENT_SELECTED_ID_ACCEPTED")
        fixture = json.loads((HERE / "fixture.json").read_text())
        require(
            not any(marker in body.decode() for marker in fixture.values()),
            "PRIVATE_ERROR_RESPONSE",
        )
        # Ham header hash'i Date/Content-Length gibi gerçek wire farklarını saklar.
        # Eşli sözleşme kıyası sadece ID ve taşıyıcı değişken alanlarını ayırır.
        normalized_headers = {
            name.lower(): value
            for name, value in response_headers
            if name.lower() not in {"date", "server", "content-length", "x-request-id"}
        }
        normalized_headers["x-request-id"] = "<support-id>" if header_id is not None else None
        normalized = {
            "status": response.status,
            "body": normalized_body,
            "headers": normalized_headers,
        }
        return {
            "case": case["case"],
            "method": method,
            "path": case["path"],
            "status": response.status,
            "support_id": support_id,
            "x_request_id": header_id,
            "body_sha256": hashlib.sha256(body).hexdigest(),
            "body_bytes": len(body),
            "headers_sha256": hashlib.sha256(encoded(response_headers)).hexdigest(),
            "raw_body": parsed,
            "response_headers": response_headers,
            "normalized_contract": normalized,
            "normalized_contract_sha256": hashlib.sha256(encoded(normalized)).hexdigest(),
        }
    finally:
        connection.close()


def frames_checked(record: dict[str, Any], stage: Path) -> None:
    summary = record.get("exception")
    require(isinstance(summary, dict), "EXCEPTION_METADATA_MISSING")
    require(set(summary) == {"error_type", "frames", "frames_truncated"}, "EXCEPTION_SCHEMA")
    require(summary["error_type"] == "RuntimeError", "EXCEPTION_TYPE")
    require(type(summary["frames_truncated"]) is bool, "EXCEPTION_TRUNCATION_TYPE")
    require(
        isinstance(summary["frames"], list) and 0 < len(summary["frames"]) <= 8, "APP_FRAME_COUNT"
    )
    for frame in summary["frames"]:
        require(set(frame) == {"path", "function", "line"}, "FRAME_SCHEMA")
        relative = Path(frame["path"])
        require(not relative.is_absolute() and ".." not in relative.parts, "FRAME_PATH")
        source = stage / "app" / relative
        require(source.is_file() and source.resolve().is_relative_to(stage / "app"), "FRAME_SOURCE")
        text = source.read_text()
        names = {"<module>", "<lambda>", "<listcomp>", "<dictcomp>", "<setcomp>", "<genexpr>"}
        names.update(
            node.name
            for node in ast.walk(ast.parse(text))
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        )
        require(frame["function"] in names, "FRAME_FUNCTION")
        require(
            type(frame["line"]) is int and 1 <= frame["line"] <= len(text.splitlines()),
            "FRAME_LINE",
        )


def audit(
    directory: Path,
    arm: str,
    protocol: str,
    stage: Path,
    pid: int,
    port: int,
    exit_code: int,
    responses: list[dict[str, Any]],
    seconds: float,
) -> dict[str, Any]:
    manifest = verify_sources()
    runtime_hashes = verify_runtime(stage, arm, manifest)
    binding = json.loads((directory / "binding.json").read_text())
    receipt = json.loads((directory / "receipt.json").read_text())
    require(binding["pid"] == receipt["pid"] == pid, "PID_BINDING")
    require(binding["arm"] == arm and binding["protocol"] == protocol, "ARM_PROTOCOL_BINDING")
    require(binding["source_manifest_sha256"] == digest(HERE / "manifest.json"), "MANIFEST_BINDING")
    require(binding["fixture_sha256"] == digest(HERE / "fixture.json"), "FIXTURE_BINDING")
    require(binding["versions"] == manifest["runtime_versions"], "FRAMEWORK_VERSIONS")
    require(binding["python_major_minor"] == [3, 12], "PYTHON_VERSION")
    expected_transport = {
        "h11": "uvicorn.protocols.http.h11_impl.H11Protocol",
        "httptools": "uvicorn.protocols.http.httptools_impl.HttpToolsProtocol",
    }[protocol]
    require(binding["transport"] == expected_transport, "REAL_PROTOCOL_BINDING")
    modules = {"app.main", "app.core.errors", "app.core.logging"}
    if arm == "candidate":
        modules.add("app.core.request_context")
    require(set(binding["loaded"]) == modules, "MODULE_SET")
    for name, loaded in binding["loaded"].items():
        path = stage / (name.replace(".", "/") + ".py")
        require(loaded == {"path": str(path), "sha256": digest(path)}, "MODULE_SOURCE_BINDING")
    require(receipt["runtime_source_hashes"] == runtime_hashes, "RUNTIME_RECEIPT_BINDING")
    require(
        receipt["counters"] == {"database": 0, "outbound_socket": 0, "embedding": 0, "llm": 0},
        "DEPENDENCY_CALL_ATTEMPT",
    )
    require(
        receipt["configured"]
        == {
            "json_formatter": True,
            "error_enabled": True,
            "error_handlers": 0,
            "error_propagates": True,
        },
        "LOGGER_CHAIN",
    )
    require(exit_code == receipt["exit_code"] == 0, "PROCESS_EXIT")
    require(
        receipt["control_thread_stopped"]
        and receipt["control_stop_received"]
        and receipt["server_started"],
        "GRACEFUL_STOP",
    )
    raw, records = read_logs(directory)
    fixture = json.loads((HERE / "fixture.json").read_text())
    require(not any(marker in raw for marker in fixture.values()), "PRIVATE_EXCEPTION_LOG")
    presence = {name: value in raw for name, value in CLIENT_IDS.items()}
    if arm == "candidate":
        require(not any(presence.values()), "CLIENT_ID_IN_CANDIDATE_LOG")
    else:
        require(
            all(found for name, found in presence.items() if name != "second")
            and not presence["second"],
            "BASELINE_ECHO_CANARY_CONTRAST",
        )
    require(
        not any(record.get("logger") == "uvicorn.access" for record in records),
        "ACCESS_LOG_REOPENED",
    )
    for event in ("Application startup complete.", "Application shutdown complete."):
        require(
            sum(
                record.get("logger") == "uvicorn.error" and record.get("message") == event
                for record in records
            )
            == 1,
            "LIFESPAN_SUCCESS_EVENT",
        )
    completed = [
        record
        for record in records
        if record.get("logger") == "app.request" and record.get("message") == "istek tamamlandı"
    ]
    errors = [record for record in records if record.get("level") in {"ERROR", "CRITICAL"}]
    app_errors = [record for record in errors if record.get("logger") == "app.error"]
    server_errors = [record for record in errors if record.get("logger") == "uvicorn.error"]
    require(
        len(errors) == 4 and len(app_errors) == len(server_errors) == 2, "TWO_ERRORS_TWO_CHANNELS"
    )
    require(len(completed) == 12 and len(responses) == 14, "HTTP_LOG_COUNT")
    baseline_masked = []
    expected_completed = Counter()
    for response in responses:
        if response["status"] == 500:
            continue
        observed_id = response["support_id"]
        if arm == "baseline" and response["case"] == "no-header":
            masked = OLD_DIGIT_MASK.sub("[REDACTED_TCKN]", observed_id)
            if masked != observed_id:
                baseline_masked.append(
                    {
                        "case": response["case"],
                        "server_id": observed_id,
                        "expected_old_log_id": masked,
                    }
                )
            observed_id = masked
        expected_completed[
            (observed_id, response["method"], response["path"], response["status"])
        ] += 1
    actual_completed = Counter()
    for event in completed:
        context = event.get("context")
        require(
            isinstance(context, dict)
            and set(context) == {"request_id", "method", "path", "status", "duration_ms"},
            "COMPLETION_SCHEMA",
        )
        require(
            type(context["duration_ms"]) in (int, float) and context["duration_ms"] >= 0,
            "DURATION_METADATA",
        )
        actual_completed[
            (context["request_id"], context["method"], context["path"], context["status"])
        ] += 1
    require(actual_completed == expected_completed, "REQUEST_LOG_CORRELATION")
    expected_error_ids = Counter(
        response["support_id"] for response in responses if response["status"] == 500
    )
    require(
        Counter(event["context"]["request_id"] for event in app_errors) == expected_error_ids,
        "GENERIC_500_LOG_CORRELATION",
    )
    for event in app_errors:
        require(
            event["message"] == "beklenmeyen hata"
            and set(event["context"]) == {"request_id", "error_code"}
            and event["context"]["error_code"] == "internal_error",
            "APP_ERROR_SCHEMA",
        )
        frames_checked(event, stage)
    for event in server_errors:
        require(
            event["message"] == "ASGI uygulama hatası"
            and event["context"] == {"error_code": "asgi_application_error"},
            "UVICORN_SECOND_CHANNEL_SCHEMA",
        )
        frames_checked(event, stage)
    observations = receipt["error_observations"]
    require(len(observations) == 2, "ACTUAL_ROUTE_OBSERVATIONS")
    require(
        Counter(item["request_id"] for item in observations) == expected_error_ids,
        "ROUTE_ERROR_ID_BINDING",
    )
    require(
        all(item["same_state_object"] and item["same_helper_object"] for item in observations),
        "SAME_REQUEST_ID_OBJECT",
    )
    require(
        all(
            item["type"] == ("ServerRequestId" if arm == "candidate" else "str")
            for item in observations
        ),
        "INTERNAL_ID_ORIGIN",
    )
    ids = {item["case"]: item["support_id"] for item in responses}
    require(
        (ids["reuse-one"] != ids["reuse-two"]) is (arm == "candidate"), "REUSED_CLIENT_ID_POLICY"
    )
    if arm == "candidate":
        require(len(set(ids.values())) == 14, "CANDIDATE_ID_UNIQUENESS")
    return {
        "arm": arm,
        "protocol": protocol,
        "pid": pid,
        "port": port,
        "exit_code": exit_code,
        "seconds": round(seconds, 6),
        "responses": responses,
        "client_id_log_presence": presence,
        "baseline_generated_id_masked": baseline_masked,
        "all_exact_support_correlations": not baseline_masked,
        "request_completion_events": len(completed),
        "app_error_events": len(app_errors),
        "uvicorn_second_error_events": len(server_errors),
        "uvicorn_second_error_has_request_id": False,
        "concurrency_scope": (
            "four client threads released at barrier; real health routing; "
            "not a server scheduling benchmark"
        ),
        "binding": binding,
        "receipt": receipt,
        "runtime_source_hashes": runtime_hashes,
        "wire_sha256": {p.name: digest(p) for p in sorted((directory / "wire").glob("*.json"))},
        "log_sha256": {name: digest(directory / name) for name in ("stdout.log", "stderr.log")},
        "sidecar_sha256": {
            name: digest(directory / name)
            for name in ("binding.json", "configured.json", "receipt.json")
        },
    }


def run_one(out: Path, arm: str, protocol: str, manifest: dict[str, Any]) -> dict[str, Any]:
    directory = out / f"{arm}-{protocol}"
    directory.mkdir(mode=0o700)
    (directory / "wire").mkdir(mode=0o700)
    stage = directory / "runtime"
    stage.mkdir(mode=0o700)
    for relative, source in source_plan(manifest, arm).items():
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        os.link(HERE / source, target)
    verify_runtime(stage, arm, manifest)
    passfile = directory / "empty.pgpass"
    passfile.touch(mode=0o600, exist_ok=False)
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(("127.0.0.1", 0))
    listener.listen(32)
    port = listener.getsockname()[1]
    control_read, control_write = os.pipe()
    proc = None
    responses = []
    started = time.monotonic()
    try:
        with (
            (directory / "stdout.log").open("x") as stdout,
            (directory / "stderr.log").open("x") as stderr,
        ):
            proc = subprocess.Popen(  # noqa: S603
                [
                    str(PYTHON),
                    str(HERE / "child.py"),
                    "--arm",
                    arm,
                    "--protocol",
                    protocol,
                    "--output",
                    str(directory),
                    "--stage",
                    str(stage),
                    "--socket-fd",
                    str(listener.fileno()),
                    "--control-fd",
                    str(control_read),
                ],
                cwd=directory,
                env=environment(stage, passfile),
                pass_fds=(listener.fileno(), control_read),
                stdout=stdout,
                stderr=stderr,
            )
            os.close(control_read)
            control_read = -1
            deadline = time.monotonic() + 25
            while not (directory / "ready.json").exists():
                require(proc.poll() is None, "CHILD_EXIT_BEFORE_READY")
                read_logs(directory)
                require(time.monotonic() < deadline, "READY_TIMEOUT")
                time.sleep(0.02)
            require(
                json.loads((directory / "ready.json").read_text())
                == {"pid": proc.pid, "address": ["127.0.0.1", port]},
                "OWN_LISTENER_READY",
            )
            selected = cases()
            for case in selected[:10]:
                responses.append(fetch(port, case, arm, directory))
            barrier = threading.Barrier(4)
            with ThreadPoolExecutor(max_workers=4) as pool:
                futures = [
                    pool.submit(fetch, port, case, arm, directory, barrier)
                    for case in selected[10:]
                ]
                responses.extend(future.result(timeout=8) for future in futures)
            write_json(directory / "responses.json", responses)
            require(os.write(control_write, b"S") == 1, "CONTROL_PIPE_WRITE")
            os.close(control_write)
            control_write = -1
            proc.wait(timeout=12)
    finally:
        listener.close()
        if control_read >= 0:
            os.close(control_read)
        if control_write >= 0:
            os.close(control_write)
        if proc is not None and proc.poll() is None:
            proc.kill()
            proc.wait(timeout=5)
    require(proc is not None, "CHILD_NOT_CREATED")
    result = audit(
        directory,
        arm,
        protocol,
        stage,
        proc.pid,
        port,
        proc.returncode,
        responses,
        time.monotonic() - started,
    )
    verify_runtime(stage, arm, manifest)
    # Yalnız bu çalıştırıcının yeni oluşturduğu ve hash'ini doğruladığı ağaç
    # kaldırılır. Kaynak snapshot/overlay aynı hardlink inode'unda korunur.
    shutil.rmtree(stage)
    require(not stage.exists(), "OWN_RUNTIME_NOT_REMOVED")
    result["own_runtime_removed_after_hash_check"] = True
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    out = args.output
    require(out.parent == Path("/private/tmp/dou018-evidence"), "OUTPUT_PARENT")
    require(re.fullmatch(r"s10-process-[a-z0-9-]{1,40}", out.name) is not None, "OUTPUT_NAME")
    require(out.parent.resolve() == out.parent and not out.exists(), "OUTPUT_EXISTS_OR_SYMLINK")
    os.umask(0o077)
    manifest = verify_sources()
    out.mkdir(mode=0o700)
    report: dict[str, Any] = {
        "status": "running",
        "results": [],
        "manifest_sha256": digest(HERE / "manifest.json"),
        "baseline_commit": manifest["baseline_commit"],
        "candidate_sources": manifest["candidate_overlay"],
        "scope": (
            "actual source-pinned Uvicorn h11/httptools synthetic HTTP; "
            "no DB/audit/model or hosted parity"
        ),
    }
    started = time.monotonic()
    exit_code = 2
    try:
        for arm in ARMS:
            for protocol in PROTOCOLS:
                report["active_case"] = {"arm": arm, "protocol": protocol}
                verify_sources()
                result = run_one(out, arm, protocol, manifest)
                report["results"].append(result)
                write_json(out / f"{arm}-{protocol}" / "audit.json", result)
        for protocol in PROTOCOLS:
            pair = [result for result in report["results"] if result["protocol"] == protocol]
            require(len(pair) == 2, "PAIR_COUNT")
            left = {response["case"]: response for response in pair[0]["responses"]}
            right = {response["case"]: response for response in pair[1]["responses"]}
            require(set(left) == set(right), "PAIR_CASE_SET")
            require(
                all(
                    left[name]["normalized_contract"] == right[name]["normalized_contract"]
                    for name in left
                ),
                "PAIRED_HTTP_CONTRACT_CHANGED",
            )
            require(
                all(
                    left[name]["body_sha256"] == right[name]["body_sha256"]
                    for name in left
                    if left[name]["status"] == 200
                ),
                "HEALTH_RAW_BODY_CHANGED",
            )
        candidate_ids = [
            response["support_id"]
            for result in report["results"]
            if result["arm"] == "candidate"
            for response in result["responses"]
        ]
        require(
            len(candidate_ids) == len(set(candidate_ids)) == 28,
            "CANDIDATE_CROSS_PROCESS_ID_UNIQUENESS",
        )
        verify_sources()
        report["status"] = "PASS"
        report["processes"] = 4
        report["http_requests"] = 56
        report["normalized_pair_contracts_equal"] = True
        exit_code = 0
    except Exception as error:
        report["status"] = "FAIL"
        report["reason"] = (
            str(error) if isinstance(error, ProbeFailure) else "UNEXPECTED_PROCESS_FAILURE"
        )
        report["error_type"] = type(error).__name__
    finally:
        try:
            verify_sources()
            report["source_unchanged"] = True
        except Exception:
            report["source_unchanged"] = False
            report["status"] = "FAIL"
            exit_code = 2
        report["seconds"] = round(time.monotonic() - started, 6)
        write_json(out / "result.json", report)
        print(json.dumps({"status": report["status"], "result": str(out / "result.json")}))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
