"""Gerçek Uvicorn çocuğu; yalnız parent'ın devrettiği listener ve kapanış borusu.

Bu dosya hazırlık sırasında çalıştırılmadı. Hata rotası ve yaşam döngüsü adaptörü
yalnız bu test sürecinin belleğine eklenir; üretim kaynakları değiştirilmez.
"""

from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import json
import logging
import os
import select
import socket
import sys
import threading
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from common import ARMS, HERE, digest, require, verify_runtime, verify_sources, write_json


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=ARMS, required=True)
    parser.add_argument("--protocol", choices=("h11", "httptools"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--socket-fd", type=int, required=True)
    parser.add_argument("--control-fd", type=int, required=True)
    args = parser.parse_args()
    require(args.output == args.output.resolve(), "CHILD_OUTPUT_SYMLINK")
    require(
        args.output.parent.parent == Path("/private/tmp/dou018-evidence"), "CHILD_OUTPUT_PARENT"
    )
    require(args.output.parent.name.startswith("s10-process-"), "CHILD_OUTPUT_PREFIX")
    manifest = verify_sources()
    require(args.arm in manifest["arm_order"], "ARM_NOT_IN_MANIFEST")
    stage = args.stage
    require(stage == args.output / "runtime" and stage.resolve() == stage, "STAGE_LOCATION")
    runtime_hashes = verify_runtime(stage, args.arm, manifest)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(stage))
    counters = {"database": 0, "outbound_socket": 0, "embedding": 0, "llm": 0}

    def forbidden(kind: str):
        def denied(*_args: Any, **_kwargs: Any) -> Any:
            counters[kind] += 1
            raise RuntimeError("S10_PROCESS_DEPENDENCY_FORBIDDEN")

        return denied

    import psycopg

    psycopg.connect = forbidden("database")
    psycopg.Connection.connect = forbidden("database")
    psycopg.AsyncConnection.connect = forbidden("database")
    socket.create_connection = forbidden("outbound_socket")
    socket.socket.connect = forbidden("outbound_socket")
    socket.socket.connect_ex = forbidden("outbound_socket")
    socket.getaddrinfo = forbidden("outbound_socket")

    from app.modules.generation import fake, llm
    from app.modules.ingestion import embedding

    llm.build_llm_client = forbidden("llm")
    llm.LiteLlmClient.complete = forbidden("llm")
    fake.FakeLlmClient.complete = forbidden("llm")
    embedding.get_embedding_provider = forbidden("embedding")
    for provider in (embedding.HashingEmbeddingProvider, embedding.FastEmbedProvider):
        provider.embed_query = forbidden("embedding")
        provider.embed_documents = forbidden("embedding")

    import uvicorn
    from fastapi import Request

    config = uvicorn.Config(
        "app.main:app",
        host="127.0.0.1",
        port=0,
        loop="asyncio",
        http=args.protocol,
        ws="none",
        lifespan="on",
        interface="asgi3",
        access_log=True,
        log_level="info",
        proxy_headers=False,
        timeout_graceful_shutdown=5,
    )
    config.load()
    main_module = importlib.import_module("app.main")
    app_logging = importlib.import_module("app.core.logging")
    app_errors = importlib.import_module("app.core.errors")
    require(config.loaded_app is main_module.app, "LOADED_APP_IDENTITY")
    expected_protocol = {
        "h11": "uvicorn.protocols.http.h11_impl.H11Protocol",
        "httptools": "uvicorn.protocols.http.httptools_impl.HttpToolsProtocol",
    }[args.protocol]
    actual_protocol = (
        config.http_protocol_class.__module__ + "." + config.http_protocol_class.__name__
    )
    require(actual_protocol == expected_protocol, "PROTOCOL_CLASS_MISMATCH")
    loaded = {}
    module_names = ["app.main", "app.core.errors", "app.core.logging"]
    if args.arm == "candidate":
        module_names.append("app.core.request_context")
    for module_name in module_names:
        module = importlib.import_module(module_name)
        path = Path(module.__file__).resolve()
        require(path.is_relative_to(stage), "MODULE_OUTSIDE_ARM")
        require(digest(path) == runtime_hashes[str(path.relative_to(stage))], "MODULE_HASH")
        loaded[module_name] = {"path": str(path), "sha256": digest(path)}
    require(main_module.configure_logging is app_logging.configure_logging, "LOGGING_BINDING")
    require(
        main_module.unhandled_error_handler is app_errors.unhandled_error_handler, "HANDLER_BINDING"
    )
    if args.arm == "candidate":
        request_context = importlib.import_module("app.core.request_context")
        require(
            main_module.request_id_of is app_errors.request_id_of is request_context.request_id_of,
            "REQUEST_CONTEXT_CALLABLE_BINDING",
        )
    fixture = json.loads((HERE / "fixture.json").read_text())
    error_observations = []

    def private_failure(payload: dict[str, str]) -> None:
        try:
            raise ValueError(payload["cause"] + " " + payload["url"])
        except ValueError as cause:
            error = RuntimeError(payload["body"])
            error.add_note(payload["note"])
            raise error from cause

    async def injected_error(request: Request) -> None:
        support_id = app_errors.request_id_of(request)
        error_observations.append(
            {
                "request_id": str(support_id),
                "type": type(support_id).__name__,
                "same_state_object": request.state.request_id is support_id,
                "same_helper_object": app_errors.request_id_of(request) is support_id,
            }
        )
        payload = await request.json()
        require(payload == fixture, "UNEXPECTED_SYNTHETIC_REQUEST")
        private_failure(payload)

    # Yerel import, ertelenmiş tür adının FastAPI tarafından gerçek Request
    # sınıfı olarak görülmesi için açıkça bağlanır; query parametresi oluşmaz.
    injected_error.__annotations__["request"] = Request
    main_module.app.add_api_route(
        "/__s10_probe__/error", injected_error, methods=["POST"], include_in_schema=False
    )
    original_lifespan = main_module.app.router.lifespan_context
    configured = {}

    @asynccontextmanager
    async def controlled_lifespan(app: Any) -> AsyncIterator[Any]:
        async with original_lifespan(app) as state:
            root_handlers = logging.getLogger().handlers
            error_logger = logging.getLogger("uvicorn.error")
            require(len(root_handlers) == 1, "ROOT_HANDLER_COUNT")
            require(
                isinstance(root_handlers[0].formatter, app_logging.JsonFormatter), "ROOT_FORMATTER"
            )
            require(
                not error_logger.handlers and error_logger.propagate and not error_logger.disabled,
                "UVICORN_ERROR_ROUTE",
            )
            require(not logging.getLogger("uvicorn").handlers, "UVICORN_PARENT_HANDLER")
            configured.update(
                {
                    "json_formatter": True,
                    "error_enabled": True,
                    "error_handlers": 0,
                    "error_propagates": True,
                }
            )
            write_json(args.output / "configured.json", {"pid": os.getpid(), **configured})
            yield state

    main_module.app.router.lifespan_context = controlled_lifespan
    listener = socket.socket(fileno=args.socket_fd)
    address = list(listener.getsockname())
    require(address[0] == "127.0.0.1" and 0 < address[1] < 65536, "LISTENER_NOT_LOOPBACK")
    server = uvicorn.Server(config)
    finished = threading.Event()
    stop_state = {"received": False}
    binding = {
        "pid": os.getpid(),
        "arm": args.arm,
        "protocol": args.protocol,
        "transport": actual_protocol,
        "loaded": loaded,
        "versions": {
            name: importlib.metadata.version(name)
            for name in ("fastapi", "starlette", "uvicorn", "h11", "httptools")
        },
        "python_major_minor": list(sys.version_info[:2]),
        "source_manifest_sha256": digest(HERE / "manifest.json"),
        "fixture_sha256": digest(HERE / "fixture.json"),
        "adapter": (
            "hardlinked source-pinned real app + synthetic error route; "
            "observed actual lifespan and dependency guards"
        ),
    }
    write_json(args.output / "binding.json", binding)

    def controlled_shutdown() -> None:
        try:
            while not server.started and not finished.wait(0.01):
                pass
            if finished.is_set():
                return
            write_json(args.output / "ready.json", {"pid": os.getpid(), "address": address})
            while not finished.is_set():
                readable, _, _ = select.select([args.control_fd], [], [], 0.1)
                if readable:
                    stop_state["received"] = os.read(args.control_fd, 1) == b"S"
                    server.should_exit = True
                    return
        finally:
            os.close(args.control_fd)

    control = threading.Thread(target=controlled_shutdown, daemon=True, name="s10-private-stop")
    control.start()
    exit_code = 0
    try:
        # Uvicorn'un kendi sinyal yakalayıcıları değiştirilmez.
        server.run(sockets=[listener])
    except SystemExit as error:
        exit_code = error.code if type(error.code) is int else 98
    except Exception:
        exit_code = 99
    finally:
        finished.set()
        control.join(timeout=2)
        listener.close()
        write_json(
            args.output / "receipt.json",
            {
                "pid": os.getpid(),
                "exit_code": exit_code,
                "server_started": server.started,
                "control_stop_received": stop_state["received"],
                "control_thread_stopped": not control.is_alive(),
                "counters": counters,
                "configured": configured,
                "error_observations": error_observations,
                "runtime_source_hashes": verify_runtime(stage, args.arm, manifest),
            },
        )
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
