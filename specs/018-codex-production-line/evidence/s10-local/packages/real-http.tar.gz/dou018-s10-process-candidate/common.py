"""S10 iki kol süreç deneyinin sabit kaynak ve çıktı sınırları."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
PYTHON = Path(
    "/Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python"
)
ARMS = ("baseline", "candidate")
PROTOCOLS = ("h11", "httptools")
MAX_LOG_BYTES = 1024 * 1024


class ProbeFailure(Exception):
    """Yalnız önceden tanımlı sabit başarısızlık kodu taşır."""


def require(condition: bool, code: str) -> None:
    if not condition:
        raise ProbeFailure(code)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: Any) -> None:
    require(not path.exists(), "OUTPUT_EXISTS")
    temporary = path.with_suffix(path.suffix + ".writing")
    with temporary.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    temporary.replace(path)


def source_plan(manifest: dict[str, Any], arm: str) -> dict[str, str]:
    require(arm in ARMS, "UNKNOWN_ARM")
    files = dict(manifest["shared_sources"])
    if arm == "candidate":
        files.update(manifest["candidate_overlay"])
    return files


def verify_sources() -> dict[str, Any]:
    manifest = json.loads((HERE / "manifest.json").read_text())
    require(manifest["arm_order"] == list(ARMS), "ARM_ORDER")
    require(manifest["protocol_order"] == list(PROTOCOLS), "PROTOCOL_ORDER")
    actual_files = {
        str(path.relative_to(HERE))
        for path in HERE.rglob("*")
        if path.is_file() and path != HERE / "manifest.json"
    }
    require(actual_files == set(manifest["package_files"]), "PACKAGE_FILE_SET_CHANGED")
    for relative, expected in manifest["package_files"].items():
        path = HERE / relative
        require(
            path.is_file() and not path.is_symlink() and digest(path) == expected, "PACKAGE_CHANGED"
        )
    for absolute, expected in manifest["current_candidate_sources"].items():
        require(digest(Path(absolute)) == expected, "CURRENT_CANDIDATE_CHANGED")
    for absolute, expected in manifest["framework_sources"].items():
        require(digest(Path(absolute)) == expected, "FRAMEWORK_CHANGED")
    require(digest(PYTHON.resolve()) == manifest["python_binary_sha256"], "PYTHON_CHANGED")
    for absolute, expected in manifest["frozen_candidate_manifests"].items():
        require(digest(Path(absolute)) == expected, "FROZEN_CANDIDATE_CHANGED")
    return manifest


def verify_runtime(stage: Path, arm: str, manifest: dict[str, Any]) -> dict[str, str]:
    expected = source_plan(manifest, arm)
    actual = {str(path.relative_to(stage)) for path in stage.rglob("*") if path.is_file()}
    require(actual == set(expected), "RUNTIME_FILE_SET_CHANGED")
    hashes = {}
    for relative, source in expected.items():
        path = stage / relative
        require(
            not path.is_symlink() and path.resolve().is_relative_to(stage), "RUNTIME_LINK_ESCAPE"
        )
        value = digest(path)
        require(value == manifest["package_files"][source], "RUNTIME_SOURCE_CHANGED")
        hashes[relative] = value
    return hashes


def read_logs(directory: Path) -> tuple[str, list[dict[str, Any]]]:
    raw_parts, records = [], []
    for name in ("stdout.log", "stderr.log"):
        path = directory / name
        require(path.stat().st_size <= MAX_LOG_BYTES, "EXCESSIVE_LOG")
        raw = path.read_text(errors="replace")
        raw_parts.append(raw)
        for line in raw.splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                records.append(value)
    return "\n".join(raw_parts), records
