# S10 — Gerçek Uvicorn kaynak eşli istek kimliği deneyi

**Hazırlanmış ve henüz çalıştırılmamış harness.** Repo/DB/model/sunucu/ağ işlemi yapılmadı. Yalnız Git kaynaklarının salt okunur snapshot'ı, tmp dosyaları, Python AST ve üç yardımcıda Ruff statik kontrolü kullanıldı. Bu dört süreç veya 56 HTTP isteği hazırlanırken yürütülmedi. Root gerçek çalıştırmayı ayrı ağır iş sırasında yapar.

## Sabit kaynak kolları

- Baseline: `deb83e1c0c4553e00072ea6797bd48b6ab53f330` içindeki gerçek `apps/api/app` + `apps/api/static`. Snapshot `shared/` altında **bir kere** bulunur; Git commit'i ve her dosyanın SHA256'sı bağlıdır.
- Candidate: aynı ortak kaynaklar üzerinde orijinal S10 `main.py`, `errors.py`, yeni `request_context.py` ve review-fix `logging.py` dört overlay dosyası. `errors.py` için root'un son import sırası düzenlemesi kullanılır: `421ec8a6c217d8215bc0fa3b3ca2b7e67faa9f02eb0fb4dc9e38f53c37d9ad4a`. Önceki `e217…` kaynakla import bağları ve import dışı AST eşitliği hazırlıkta ayrıca karşılaştırıldı; `/private/tmp/dou018-evidence/s10-style-01/result.json` byte hash'i `source-plan.json` içinde korunur.
- Orijinal S10 ve review-fix manifestleri doğrulanır; bu dosyalar veya önceki S9 süreç kanıtları değiştirilmez. Güncel root candidate app/static dosyalarının tamamı da manifestteki etkili aday hash'lerine bağlıdır; root yeni üretim düzeltmesi yaparsa harness eski adayı finalmiş gibi çalıştırmak yerine `CURRENT_CANDIDATE_CHANGED` ile durur.
- Kurulu FastAPI/Starlette/Uvicorn/h11/httptools kaynakları, HTTP parser uzantıları, sürümler ve gerçek Python binary hash'i sabitlenir. Yeni bağımlılık veya indirme yoktur.

Root yürütürken her süreç için yeni çıktı klasöründe `runtime/app` ve `runtime/static` kurulur. Bunlar snapshot/overlay dosyalarına **hardlink** verir: Python normal paket yollarını ve gerçek `main.STATIC_DIR`/logging frame kökünü kullanır; özel importer, yeniden yazılmış eski fonksiyon veya sahte modül yoktur. Çocuk kapandıktan ve dosya kümesi/hash'leri doğrulandıktan sonra yalnız yeni oluşturulmuş runtime ağacı kaldırılır. Böylece kod/static kaynakları sonuç arşivinde dört kez çoğalmaz. Başarısız/hash'i değişmiş runtime inceleme için bırakılır; mevcut başka dizine veya sürece dokunulmaz. POSIX aynı dosya sistemi hardlink/pass_fds varsayımı açık, Windows taşınabilirliği iddia edilmez.

## Önceden sabit deney

İki kol × `h11` / `httptools` = **4 ardışık gerçek süreç**. Her süreçte **14 HTTP isteği**, toplam **56**:

1. Başlıksız gerçek `/health/live`.
2. Olağan izleme metniyle sağlık isteği.
3. İzinli ASCII isim/öğrenci canary'siyle sağlık isteği.
4. Geçerli UUID biçimli istemci kimliğiyle sağlık isteği.
5. Gerçek `/courses` 401 yoluna iki ayrı `X-Request-ID` alanı; ilk/ikinci farklıdır.
6. ASCII canary ile aynı gerçek 401 yolu.
7–8. Aynı istemci kimliğiyle iki ayrı sağlık isteği.
9–10. ASCII/UUID kimlikli, fixture JSON'unu alan iki kontrollü sentetik hata. Rota yalnız test sürecinin belleğinde gerçek `app.main.app` yönlendiricisine eklenir; mevcut generic500 handler, Starlette yeniden yükseltmesi ve gerçek Uvicorn ikinci hata logger'ı çalışır. Handler/logger doğrudan elle çağrılıp gerçek ağ yerine sunulmaz.
11–14. Parent'ta dört iş parçacığının bariyerden birlikte salındığı gerçek sağlık istekleri. Bu eşzamanlı istemci gönderimidir, sunucuda belirli bir iç yürütme sırası veya performans benchmark'ı değildir.

Her kolda gerçek app lifespan çalışır: normal startup/shutdown başarı kayıtları ve configure_logging sonrası Uvicorn error logger zinciri doğrulanır. Yaşam döngüsü hata varyantları bu dar S10 ölçümünde tekrar edilmez; önceki S9 kanıtları ayrı kalır.

## Kabul oracle'ları

- Baseline izinli istemci kimliğini aynen echo eder; duplicate başlıkta ilk alan seçilir. Candidate her HTTP isteği için taze canonical UUID4 hex üretir, istemci seçimini taşımaz. Aynı istemci kimliği iki istekte baseline'da aynı, candidate'ta farklıdır. Candidate'ın iki protokol sürecindeki 28 kimlik de tekildir.
- 401/500 hata gövdesinin destek kodu, gerçek `app.request` / `app.error` kaydıyla eşleşir. 200/401 header kodu aynı isteğin log koduyla eşleşir. Error route içinde aynı helper çağrısının/state'in **aynı nesneyi** döndürdüğü ve candidate tipinin `ServerRequestId` olduğu gözlenir.
- **Mevcut 500 başlık sözleşmesi:** Her iki kolda da `X-Request-ID` yanıt başlığı yoktur; kod gövdede ve app.error'dadır. Bu deney header eklemez veya eksik header'ı varmış gibi saymaz.
- **Tarihsel baseline istisnası:** Başlıksız S9 isteğinin rastgele UUID'si 11 rakam kalıbına denk gelirse eski log maskesi kodu değiştirebilir. Yalnız önceden bilinen `(?<!\d)\d{11}(?!\d)` dönüşümü baseline'ın bu tek vakasında beklenebilir. `baseline_generated_id_masked` ve `all_exact_support_correlations:false` açık yazılır; tam korelasyon denmez. Candidate için istisna yoktur. Bu oracle S10 adayına maske muafiyeti sağlamaz; gerçek digit-run iç tür davranışı ayrıca API birim/PG kanıtında sınanır.
- Her süreçte 12 tamamlandı kaydı + 2 app.error + 2 Uvicorn ikinci hata kaydı vardır. İkinci Uvicorn kaydı mevcut sözleşmede request_id taşımaz; buna sahte ID korelasyonu eklenmez. O kanalda güvenli sabit olay, tip, uygulama köküne göreli izinli kaynak frame'leri ve canary yokluğu doğrulanır.
- İstemci kimliği canary'leri baseline logunda beklenir, candidate logunda bulunamaz. Duplicate ikinci alan baseline'da da loga giremez. Hata gövdesi/cause/notes/özel URL canary'leri **iki kolun da** ham stdout/stderr ve HTTP hata yanıtında bulunamaz. `uvicorn.access` kapalı kalır.
- Her ham HTTP yanıtı doğrulamadan önce `wire/<case>.json` içine bounded body hex/hash + gerçek header listesi olarak yazılır; bir ret de ham kanıtı kaybetmez. Bütün değerler sentetiktir. Başarılı per-case raporda ayrıca parsed gövde ve normalized kontrat/hash bulunur.
- Eşli normalize kıyas yalnız destek ID değerini placeholder yapar. Header'daki ID varlığı ayrıca korunur; `Date`, `Server`, ID uzunluğuyla değişen `Content-Length` normalize header kıyasından ayrılır, ham header hash/listesinde saklanır. Diğer gövde alanları, durumlar ve seçilmemiş gerçek header'lar eşit olmak zorundadır. 200 sağlık yanıtlarının ham body hash'i de bire bir eşleşir. Hata gövdesinin ham hash'inin iki kolda aynı olması beklenmez; ID farkı gizlenmez.

## Süreç / bağımlılık sınırı

Parent yalnız kendisinin açtığı `127.0.0.1:0` listener'ı `pass_fds` ile devreder; URL, host veya port kullanıcı/ortamdan alınmaz. `http.client` proxy veya redirect keşfi kullanmaz. Duplicate header'lar dict ile birleştirilmeden `putheader` çağrılarıyla gönderilir.

Çocuk ortamı allowlist ile sıfırdan kurulur: dev/fake/hashing, warmup/eval kapalı, gerçek LLM anahtarları boş, HF offline, proxy boş. Gerçek/private/ambient PG env taşınmaz; yeni özel boş regular passfile kullanılır. `psycopg` sync/async bağlantıları, model fabrikaları/yöntemleri ve socket connect/DNS girişleri engellenip sayılır. Başarı için dört sayaç da **0** olmalıdır. Bu beklenen yolların guard kanıtıdır; keyfi native kod/OS bypass'larının genel sertifikası değildir.

Hazır sinyali ancak `server.started` sonrası own PID + numeric address ile yazılır. Kapanış özel pipe'taki stop byte ile `server.should_exit=True` yapar; Uvicorn'un sinyal handler'ları değiştirilmez. Normal exit0, kontrol thread'i kapalı ve stop alındı şarttır. Timeout yalnız bu Popen nesnesinin çocuğunu öldürür ve başarılı deney sayılmaz. Startup 25s, HTTP 5s, normal kapanış 12s sınırlıdır; stdout/stderr dosyaları her biri 1MiB sınırındadır.

Bu ölçüm **403 audit/RLS/gerçek PG**, model kalitesi, gerçek sağlayıcı, hosted proxy/collector, p95/SLO veya genel anonimlik kabulü değildir. Bunlar root'un ayrı süreç/DB ve E2E kanıtında kalır. Kaynaklar/veri yalnız yerel kontrollü sentetik kapsamdır.

## Root çalıştırma

S10 üretim kaynaklarını freeze edip başka ağır iş yokken, yeni çıktı adıyla:

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/muratates/code/dou-synapse-018-codex-production-line/apps/api/.venv/bin/python /private/tmp/dou018-s10-process-candidate/run_processes.py --output /private/tmp/dou018-evidence/s10-process-01
```

Çıktı mevcutsa veya symlink/yanlış parent ise çalışma reddedilir. Aynı dosya/rapor üzerine tekrar yazılmaz. Ana `result.json`, dört per-process `audit.json`, binding/configured/receipt, wire ve ham log hash'leri birlikte incelenmelidir. Geçen S9 sayıları yeni S10 çalışması gibi sunulmaz. Bu paketi hazırlayan ajan hiçbir gerçek süreç, test sunucusu, DB veya ağ isteği çalıştırmadı.
