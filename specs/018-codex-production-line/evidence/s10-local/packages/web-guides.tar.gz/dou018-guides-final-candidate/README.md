# Son kullanıcı kılavuzları — güncel 018 kaynaklarına bağlı aday

Bu paket yalnız doküman adayıdır; repoya uygulanmadı. Önceki adayın 14 bulgusu yeniden kontrol edildi. Önceki manifest `dea63e516e724d07ab42e5ec624fa4370b893742c27629d164f59b5e02fc3bcb` içindeki bütün arayüz/API referans hash'leri aynı kaldı. Depodaki öğrenci ve eğitmen kılavuzları da önceki baseline hash'leriyle aynı; yeni admin kılavuzu hâlâ depoda yok. Rebase gerektiren eşzamanlı belge değişikliği bulunmadı.

## Uygulanacak kapsam

- `files/docs/student-guide.md`: B2'de zaten var olan katalog/oturum akışı, kayıtlı alıştırma geri bildirimi, B3 eksik ölçüt alıntısı, kişisel sohbet silmenin üç kapsamı, açık geri bildirim paylaşımı, aktif sınav ve veri indirme kilidi, profil işlemleri.
- `files/docs/instructor-guide.md`: B1 konuya bağlı öğrenme çıktısı; B3 kod rubrikleri; B4 kişisel sohbetler; B5 politika geçmişi; B6 sınıflandırma kapalıyken uygun hazır havuzla yayın; B7 sunucuya uygulanan durum/konu filtreleri. Özelliğin kapalı veya erişimin kısıtlı olabileceği kullanıcı dilinde anlatılır; ortama özel bayrak/SQL/API komutları kılavuza taşınmaz.
- `files/docs/admin-guide.md`: mevcut salt okunur Bilgi İşlem alanı, ayrı platform yetkisi, sağlık/Ölçülemedi durumları, başarılı sohbet p95 örneklemi, teknik kayıtların ve destek paylaşımının sınırları. Öğrenci adına veri silme veya yetki düzenleme özelliği varmış gibi anlatılmaz.
- `readme-admin-link.patch`: yalnız başlangıç belgeleri tablosuna Bilgi İşlem kılavuzu bağlantısı ekler. Tam README kopyası verilmedi; root'un eşzamanlı S10/kanıt metinlerini eski kopyayla ezmeyin.
- `guides-final.patch`: üç kılavuz ile aynı README bağlantı hunk'ını birlikte içerir. Birleşik patch kullanılıyorsa README patch'ini ikinci kez uygulamayın.

Önceki adaydan ürün açıklamasındaki tek ek eşitleme **S10 Destek kodu**dur: kodun sunucu tarafından ilgili istek için oluşturulduğu, yeniden denemede değişebileceği ve varsa yetkili destek ekibine iletilebileceği üç role uygun biçimde anlatıldı. Eski admin metnindeki genel “hata izleme numarası” etiketi gerçek arayüzdeki **Destek kodu** ile değiştirildi. İstemcinin kendi izleme kodunu oluşturması ya da girmesi istenmiyor.

## İnceleme ve kanıt sınırları

`previous-audit.md`, önceki 14 bulgunun değiştirilmemiş tablosudur; eski belge satırları `baseline/docs/` kopyalarına aittir. Son kaynakların aynı byte hash'lerinde kaldığı manifestte gösterilir. B2 yeni geliştirilmiş bir özellik gibi sayılmaz. Kaynaklı geri bildirim tek başına gerçek LLM kalitesi, resmî not, production veya hukuki uygunluk kanıtı değildir.

Metin üzerinden kontrol edilen `static-links-and-labels.json`:

- Üç kılavuzun bağlantıları ile README'deki üç kılavuz girişinin toplamı 29; 15 eski görsel hedefi mevcut.
- Profil bölümüne giden iki Markdown fragment'i mevcut öğrenci kılavuzundaki başlıkla eşleşiyor. Önceki adayda “anchor doğrulanmadı” bırakılan iki öğe burada yalnız **metinden türetilen başlık eşleşmesi** olarak doğrulandı.
- 14 önemli alan/düğme/durum etiketi ve S10 üretim davranışı ilgili kaynak satırlarında bulundu. Bunlar önceki 14 bulgu ile aynı sayım değildir; ek kaynak etiketi envanteridir.
- Eksik yerel dosya veya çözülemeyen fragment bulunmadı. Bu, tarayıcıda tıklama ya da Markdown render testi değildir. Ağ çağrısı, API/DB/test çalıştırması veya yeni ekran görüntüsü yapılmadı.

Görsellerin önceki sürüme ait örnek ekranlar olduğu uyarısı iki kılavuzun başında korunur; görüntü dosyaları değiştirilmedi. Eski belge metinleri ve tarihsel ölçüm anlatıları hash'li baseline kopyalarında saklıdır. Root kalıcı I kanıt paketine bu baseline'ları da alabilir; yeni kılavuzlar eski hız/test/model başarı iddialarını bugünün sonucu olarak tekrar etmez. Bu alt görev root'un 71 E2E sonucunu yeniden çalıştırmadı ve eski görselleri o koşuda çekilmiş gibi sunmaz.

## Root'a devir

Önce manifestteki `baseline_sha256` değerlerini kontrol edin; rehberlerden biri değişmişse patch'i körlemesine uygulamayın. README hunk'ı yalnız yeni bağlantıdır. Bütünleşik docs-check ve root'un belge kabulü hâlâ ayrıca yapılacak; bu aday kendi başına hosted CI veya 036 commit kabulü değildir.

Kullanıcı kılavuzları teknik özelliklerin nerede kullanılacağını ve erişim/silme sınırlarını anlatır. Yeni canlı auth, model, hosting, otomatik operasyon veya yasal uyumluluk vaadi eklenmemiştir.
