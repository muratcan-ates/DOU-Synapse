from pathlib import Path
import difflib
import hashlib
import json
import re

repo = Path('/Users/muratates/code/dou-synapse-018-codex-production-line')
out = Path('/private/tmp/dou018-guides-next-candidate')
student = out / 'files/docs/student-guide.md'
t = student.read_text()
t = t.replace('ilgili soru-cevap içeriği ve açıklamanız, adınızla birlikte hocanızın inceleme alanında\ngörülebilir.', 'ilgili soru-cevap içeriği ve açıklamanız, hesabınızda görünen adınız veya e-postanızla\nbirlikte hocanızın inceleme alanında görülebilir.')
t = t.replace('izleyin; bütün derslerde sabit sayıda basamak beklemeyin.', 'izleyin; basamak göstergesini sınırsız ipucu hakkı olarak yorumlamayın.')
student.write_text(t)
instructor = out / 'files/docs/instructor-guide.md'
t = instructor.read_text().replace('soru-cevap çiftini ve açıklamasını öğretmen incelemesine açmayı seçerse, bu kayıt ad ve\nzaman bilgisiyle kuyrukta görünür.', 'soru-cevap çiftini ve açıklamasını öğretmen incelemesine açmayı seçerse, bu kayıt hesapta\ngörünen ad veya e-posta ve zaman bilgisiyle kuyrukta görünür.')
instructor.write_text(t)
admin = out / 'files/docs/admin-guide.md'
admin.write_text(admin.read_text().replace('**—** gösterimi', '**-** gösterimi'))

paths = ['docs/student-guide.md', 'docs/instructor-guide.md', 'docs/admin-guide.md']
def sha(data):
    return hashlib.sha256(data).hexdigest()
def line(path, needle):
    for index, value in enumerate((repo/path).read_text().splitlines(), 1):
        if needle in value:
            return f'`{path}:{index}`'
    raise ValueError((path, needle))
def code(path, needle):
    return line(path, needle)
s = 'docs/student-guide.md'
i = 'docs/instructor-guide.md'
f = 'apps/web/components/exam/feedback-panel.tsx'
b = 'apps/web/app/courses/[courseId]/blueprints/page.tsx'
q = 'apps/web/app/courses/[courseId]/questions/page.tsx'
findings = [
('G01 / gizlilik', line(s, '**Hocanız sorularınızı okuyamaz.' )+'; '+line(i, '### Öğrencilerin sorularını göremezsiniz'), 'Öğretmenin hiçbir sohbet içeriğini okuyamayacağı iddiası, açık paylaşım tercihini atlıyor. Paylaşılan tek soru-cevap ve açıklama hesapta görünen ad veya e-posta ile sunuluyor; bütün geçmiş paylaşılmıyor.', code('apps/web/components/chat-feedback.tsx', 'Bu soru-cevap çiftini')+'; '+code('apps/api/app/api/feedback.py', 'student_name=full_name or email')+'; '+code('apps/web/app/courses/[courseId]/quality/page.tsx', 'Paylaşılan inceleme kuyruğu'), 'Öğrenci §2; eğitmen §7'),
('G02 / B2 mevcut, 015 düzeltmesi', line(s, 'Alıştırmada tek soruya ait geri bildirim')+'; '+line(s, 'Gönderdiğiniz alıştırma sorusuna geri döndüğünüzde'), 'Aynı belgede geri bildirim yenilenmez / yeniden açılır çelişkisi var. Mevcut akış kayıtlı alıştırma geri bildirimini tekrar okur, yeniden puanlamaz; kaynak ve sınav erişimi tekrar denetlenir. B2 kataloğu yeni geliştirme olarak sunulmadı.', code('apps/web/components/exam/saved-practice-feedback.tsx', 'Cevap yeniden puanlanmaz')+'; '+code('apps/web/components/exam/start-panel.tsx', 'Şu anda açık sınavlar'), 'Öğrenci §5'),
('G03 / B1', line(i, '**Sınavlar** ekranında dersin öğrenme çıktısını'), 'Ekran adı Sınav blueprint\'i; konu seçilmemesi “dersin geneline” dağılım değildir. Null konu ayrı gösterilir ve çıktı oluştururken gerçek konu seçilebilir.', code(b, 'Çıktının konusu')+'; '+code(b, 'Konu atanmadı; dağılımda ayrı gösterilir')+'; '+code(b, 'Konusuz çıktıdan'), 'Eğitmen §4'),
('G04 / B3', line(i, 'Klasik sorularda ölçütlerin toplamı')+'; '+line(s, '### "Neden yanlış?"'), 'Kod rubriği düzenleme, rubriksiz eski kayıt uyarısı ve eksik ölçüt dayanağı eksik. Eksik ölçüt alıntısı yanlış şık çelişkisiyle aynı şey değil; bunu kanıtlanmış çelişki diye anlatmamak gerekiyor.', code('apps/web/components/question-authoring/draft-editor.tsx', 'Bu eski kod sorusunda')+'; '+code('apps/web/lib/question-authoring.ts', 'en az')+'; '+code(f, 'Eksik ölçütün dayanağı'), 'Eğitmen §4–5; öğrenci §5'),
('G05 / B4', line(s, '### Konuşmalarınız kayıtlı')+'; '+line(i, '## İlgili belgeler'), 'Tek sohbeti ve dersteki bütün kişisel sohbetleri silme adımları yok. Kapsam, açık onay/iptal ve silmeden sonra yeniden yükleme yolu belirtilmeli; kişisel silme sınav erişimini açmıyor.', code('apps/web/components/chat-history-delete.tsx', 'const label =')+'; '+code('apps/web/components/chat-history-delete.tsx', 'Kalıcı olarak sil')+'; '+code('apps/web/app/courses/[courseId]/chat/page.tsx', 'Kişisel sohbet geçmişin')+'; '+code('apps/web/app/courses/[courseId]/chat/page.tsx', 'Sohbeti yeniden yükle'), 'Öğrenci §2; eğitmen §9'),
('G06 / B5', line(i, '## 4. Soru havuzu ve onay')+'; '+line(i, '## 5. Sınıf analitiği'), 'Ders AI politikası ve değişiklik geçmişi için kullanıcı adımları yok. Mod/kaynak seçimi, boş kaynak seçiminin anlamı, etkin sınırlar ve Önce/Sonra incelemesi anlatılmalı; geçmişi açmak geri alma işlemi değildir.', code('apps/web/app/courses/[courseId]/settings/page.tsx', 'Tüm ders materyallerini kullan')+'; '+code('apps/web/components/policy-history.tsx', 'Politika geçmişi')+'; '+code('apps/web/components/policy-history.tsx', 'Önce:'), 'Eğitmen §6'),
('G07 / B6', line(i, 'Soru düzenleme özelliği açılmışsa')+'; '+line(i, 'yayın kapısını denetleyin'), 'Tüm yayın akışını düzenleme açık koşuluna bağlayan anlatım eksik. Sınıflandırma kapalıyken mevcut uygun onaylı havuzla yayın mümkündür; eksik soruları değiştirme yolu ve denetim sonucu belirleyicidir.', code(b, 'Soru sınıflandırma şu anda kapalı.')+'; '+code(b, 'Kapıyı denetle')+'; '+code(b, 'Yeni taslak sürüm'), 'Eğitmen §5'),
('G08 / B7', line(i, '## 4. Soru havuzu ve onay'), 'Durum ve konu süzgeçlerinin tüm havuza uygulanması, görünen sayının yüklenmiş sonuç olması ve boş filtreyi değiştirme adımları yok.', code(q, 'Konu süzgeci')+'; '+code(q, 'Süzgeçler tüm soru havuzunda uygulanır.')+'; '+code(q, 'Bu süzgeçte soru yok.'), 'Eğitmen §4'),
('G09 / veri işlemleri', line(s, 'Ayrıntı: [KVKK Aydınlatma Metni]')+'; '+line(i, '[KVKK Aydınlatma Metni]'), 'Profil/Verilerim adımları yok, bağlantı etiketi mevcut teknik kapsamla uyumsuz. Profil bilgilerini kaldırma bütün verilerin silinmesi ya da tam anonimleşme değildir; kurum hesabı ve bağlı akademik kayıtlar korunur.', code('apps/web/app/profile/page.tsx', 'Verilerimi indir veya sil')+'; '+code('apps/web/app/account/page.tsx', 'Bu işlem bütün verilerinizi silmez')+'; '+code('apps/web/app/account/page.tsx', 'JSON olarak indir'), 'Öğrenci §7; eğitmen §9; admin §4'),
('G10 / sınav sınırı', line(s, 'Aynı derste başka bir')+'; '+line(s, 'Gerçek sınav modunda ipucu'), 'Mevcut aynı ders sınav kilidi kısmen anlatılmış, bütün derslerde etkin öğrenci sınavına bağlı kişisel veri indirme kilidi yok. Sekme/yenileme ve eski kaynak bağlantıları yetkiyi değiştirmez.', code('apps/api/app/api/privacy.py', 'any_active_student_exam_session')+'; '+code('apps/web/components/exam/saved-practice-feedback.tsx', 'exam_in_progress')+'; '+code('apps/web/components/course-nav.tsx', 'locksWithAssistant: true'), 'Öğrenci §5'),
('G11 / giriş ve kanıt kapsamı', line(s, 'Üniversite hesabınızla girersiniz.')+'; '+line(i, 'Canlı ortamda üniversite hesabınızla')+'; '+line(i, 'Üretim gerçek bir dil modeli anahtarı ister.')+'; '+line(s, 'hiçbiri örnek veri değildir.'), 'Gerçek üniversite kimliği, anahtarsız ortam davranışı ve görsellerin veri niteliği kesin anlatılıyor. Kılavuz, sunulan giriş yöntemi ile örnek ortamı ayırmalı; canlı auth/model/ekran doğrulaması bu incelemede yapılmadı.', code('apps/web/app/page.tsx', 'Parola')+'; '+code('apps/web/app/page.tsx', 'DEMO_USERS'), 'İki kılavuzun girişi; eğitmen §4; tarihsel iddialar baseline kopyalarında korunur'),
('G12 / materyal kurtarma', line(i, '**Başarısız** | İşlenemedi.')+'; '+line(i, '**İlk yükleme yavaştır.**')+'; '+line(i, 'Analitikte ret oranı %0'), 'Başarısız materyali sil/yeniden yükle yönlendirmesi mevcut Yeniden işle adımını atlıyor. Sabit hız süreleri ve eski bilinen analitik kusuru güncel işlem adımı olarak güvenilir değil.', code('apps/web/app/courses/[courseId]/page.tsx', 'Yeniden işle')+'; '+code('apps/web/lib/labels.ts', 'uploaded: { label: "Sırada"'), 'Eğitmen §2 ve §10; öğrenci §8'),
('G13 / Sokratik sınır', line(s, 'en küçük')+'; '+line(s, 'beş\n' ) if False else line(s, 'Sokratik modda beş'), 'Beş aşama sözlüğü mevcut; sorun her küçük mesajın ilerleteceği ve her derste bütün ipuçlarının açılacağı beklentisi. Anlamlı deneme ile dersin ipucu sınırı ayrılmalı; aşama sayısı değişmiş gibi yazılmadı.', code('apps/api/app/modules/assessment/socratic.py', 'MIN_ATTEMPT_CHARS')+'; '+code('apps/api/app/api/chat.py', 'max_stage_index=policy.max_hints')+'; '+code('apps/web/lib/chat.ts', 'SOCRATIC_STAGES ='), 'Öğrenci §3'),
('G14 / admin kılavuzu yok', '`docs/admin-guide.md` mevcut değil', 'Salt okunur Bilgi İşlem rolü, teknik sekmeler, sağlık/Ölçülemedi ve başarılı sohbet p95 örneklemi için yol tarifi eksik. Admin alanına akademik içerik, kullanıcı düzenleme veya yönetici adına veri silme özelliği eklenmiş gibi anlatılmamalı.', code('apps/web/components/app-shell.tsx', 'label: "Bilgi İşlem"')+'; '+code('apps/web/app/admin/page.tsx', 'Salt okunur operasyon alanı')+'; '+code('apps/web/app/admin/page.tsx', 'HTTP hata yanıtları')+'; '+code('apps/web/components/portal/admin-data-table.tsx', 'Önceki'), 'Yeni admin kılavuzu §1–4'),
]

report = '''# 018 kullanıcı kılavuzları: kaynakla karşılaştırma ve aday metinler

Bu inceleme yalnız belge/kod okumasıdır. Repo, kaynak kodu, veritabanı veya tarayıcı durumu değiştirilmedi; test, sunucu, canlı auth/model ya da ağ işlemi çalıştırılmadı. Üç kılavuz tmp adayındadır. Fiili çalışma kabulü veya yeni sürüm sertifikası değildir.

## Bulgular

Aşağıdaki satırlar değişmemiş depo kılavuzuna ve incelenen kaynaklara aittir. Eksik bölüm bulgularında en yakın eski bölüm referansı verildi. B2 öğrenci kataloğu zaten 014 akışıdır; yeni geliştirilmiş gibi sunulmadı.

| Bulgu | Eski belge | Sapma / eksik adım | Mevcut kaynak dayanağı | Adaydaki yer |
|---|---|---|---|---|
'''
for finding in findings:
    report += '| ' + ' | '.join(value.replace('|', '\\|') for value in finding) + ' |\n'
report += '''
## Aday kapsamı

- `files/docs/student-guide.md`: sohbet paylaşımı ve üç silme kapsamı, kaynak erişimi, mevcut katalog/oturumlar, geri bildirim yenileme, eksik ölçüt alıntısı, sınav ve veri indirme kilidi, profil işlemleri. Eski 015 eki ana akışa alındı.
- `files/docs/instructor-guide.md`: konuya bağlı çıktı, soru filtreleme/rubrik, sınıflandırma kapalı yayın alternatifi, politika geçmişi, açık paylaşılan kalite incelemesi ve kaynak yenileme/kurtarma. Gerçek kullanıcının işine yaramayan veri tabanı, özellik bayrağı, test ve sağlayıcı kurulum ayrıntıları adımlara taşınmadı.
- `files/docs/admin-guide.md`: mevcut salt okunur Bilgi İşlem alanı; ayrı rol, kullanıcı/ders/kullanım/işleme sekmeleri, başarısız veya bilinmeyen ölçüm, başarılı sohbet p95 örneklemi ve kişisel metadata sınırı.
- `guides-proposal.patch`: yalnız bu üç belge için uygulanabilir unified diff. Repo dosyalarına uygulanmadı. README ve diğer ortak belgeler değiştirilmedi.

## Korunan sınırlar ve tarihsel metin

- Silme türleri birbirinin yerine kullanılmıyor; profil alanlarını kaldırmak tam silme veya anonimleştirme diye anlatılmıyor. İndirilen yerel kopyaların silinmediği açık. Silme sırasında sınav kilidinin kalkacağı iddiası yok.
- Paylaşılan geri bildirimde görünen kimlik ad veya e-posta olabilir. Analitik ile açıkça paylaşılan tek etkileşim ayrıldı; anonimlik/hukuki uygunluk garantisi eklenmedi.
- Soru rubric/cevap anahtarı ve kaynak ayrıntılarının aktif sınavda açılacağı bir yol tarif edilmedi. Eksik ölçüt dayanağı “kanıtlanmış çelişki” olarak sunulmadı.
- Eski görsel dosyalarına dokunulmadı. 9 Ağustos hız/5 taslak→0 öğrenci/4 onay gibi geçmiş ölçüm anlatıları, tam eski belgelerle `baseline/docs/` altında hash'li korunur; güncel kılavuz adımı veya bugünkü ölçüm gibi tekrarlanmaz. Root isterse eski tarihsel ölçüm bölümünü devir arşivine alabilir. Yeni ekran görüntüsü üretildiği veya görüntülerin yeni sürümde doğrulandığı iddiası yok.
- Admin sayıları içeriksiz olmakla bütünüyle anonim değildir. Sağlık kartı canlıya çıkış onayı veya bütün süreçlerin testi değildir. P95 yalnız kaydedilmiş başarılı HTTP sohbet örneklemine aittir; tüm istekleri kapsayan SLO gibi sunulmadı.
- Kurum kimlik sağlayıcısı, gerçek model pedagojik başarısı, bulut işletimi ve hukuki süreçlerin tamamlandığı iddiası yok.

## Uygulamadan sonra root'un dar kabulü

Aşağıdakiler önerilen gözden geçirme adımlarıdır; bu alt görevde çalıştırılmadı. Mevcut ürün kanıtlarını tekrar üretme zorunluluğu iddiası değildir.

1. Öğrenci: etkileşim paylaşım kutusu, tek/derse ait/tüm sohbet silme onayı, aynı ders sınav kilidi ve başka derste etkin sınav varken veri indirme uyarısını belge etiketleriyle karşılaştır.
2. Eğitmen: konu atanmış ve atanmamış çıktı; rubriksiz eski kod taslağını açma/düzeltme; durum+konu süzgeci ve boş sonuç; sınıflandırma kapalı fakat hazır havuzdan kâğıt yayınlama anlatımını karşılaştır.
3. Politika: kayıt açıldığında Önce/Sonra okunması, geçmiş gezintisi ve boş kaynak seçiminin anlamını karşılaştır; olmayan geri alma düğmesi aranmasın.
4. Öğrenci sonuçları: kaydedilmiş alıştırma tekrar açılırken kaynak/sınav engelinin korunması ve eksik ölçüt alıntısının kullanıcı metnini karşılaştır.
5. Admin: ayrı yetki ve dört salt okunur sekme; P95 örneklem sayısı ve `-`/Ölçülemedi durumları. Yeni retry, rol yazma veya öğrenci adına silme yetkisi varsayılmasın.
6. Kılavuz bağlantıları ve eski görsellerin hâlâ yerinde olması uygulama sonrası kontrol edilsin. README'deki mevcut öğrenci/eğitmen bağlantıları değişmez; admin kılavuzuna eğitmen kılavuzundan erişilir. README'ye ek bağlantı istenirse root ayrı küçük düzenleme yapabilir.
'''
(out/'audit.md').write_text(report)

source_paths = [
'apps/web/app/page.tsx','apps/web/components/app-shell.tsx','apps/web/components/course-nav.tsx',
'apps/web/app/courses/[courseId]/chat/page.tsx','apps/web/components/chat-history-delete.tsx',
'apps/web/components/chat-feedback.tsx','apps/web/lib/chat-history-deletion.ts','apps/web/lib/chat.ts',
'apps/web/app/courses/[courseId]/quality/page.tsx','apps/api/app/api/feedback.py',
'apps/web/app/profile/page.tsx','apps/web/app/account/page.tsx','apps/api/app/api/privacy.py',
'apps/web/components/exam/start-panel.tsx','apps/web/components/exam/running-exam.tsx',
'apps/web/components/exam/finished-exam.tsx','apps/web/components/exam/session-history.tsx',
'apps/web/components/exam/saved-practice-feedback.tsx','apps/web/components/exam/feedback-panel.tsx',
'apps/web/lib/exam.ts','apps/web/lib/exam-drafts.ts','apps/web/lib/use-exam-drafts.ts',
'apps/web/app/courses/[courseId]/sources/[chunkId]/page.tsx',
'apps/web/app/courses/[courseId]/questions/page.tsx','apps/web/lib/labels.ts','apps/web/lib/questions.ts',
'apps/web/components/question-authoring/generate-panel.tsx','apps/web/components/question-authoring/draft-editor.tsx',
'apps/web/components/question-authoring/question-detail.tsx','apps/web/components/question-authoring/question-exam-usage.tsx',
'apps/web/lib/question-authoring.ts','apps/api/app/schemas/assessment.py',
'apps/web/app/courses/[courseId]/blueprints/page.tsx','apps/web/app/courses/[courseId]/settings/page.tsx',
'apps/web/components/policy-history.tsx','apps/web/lib/policy-history.ts',
'apps/web/app/courses/[courseId]/page.tsx','apps/web/app/courses/[courseId]/sources/page.tsx',
'apps/web/app/admin/page.tsx','apps/web/components/portal/admin-data-table.tsx','apps/api/app/api/admin.py',
'apps/web/components/socratic-ladder.tsx','apps/api/app/modules/assessment/socratic.py','apps/api/app/api/chat.py',
'docs/team/codex/CODEX-RUNBOOK.md',
]
manifest = {
 'schema_version': 1,
 'scope': 'guide_candidate_only',
 'repository': str(repo),
 'date': '2026-09-08',
 'evidence_basis': 'Read-only current document and implementation inspection; no new runtime acceptance.',
 'executed_browser_tests': False, 'executed_unit_tests': False, 'executed_database_actions': False,
 'repository_mutated': False,
 'staged_files': [],
 'read_source_sha256': {p:sha((repo/p).read_bytes()) for p in source_paths},
}
patch = ''
for p in paths:
    original = (repo/p).read_bytes() if (repo/p).exists() else None
    staged = (out/'files'/p).read_bytes()
    if original is not None:
        baseline = out/'baseline'/p
        baseline.parent.mkdir(parents=True, exist_ok=True)
        baseline.write_bytes(original)
    patch += ''.join(difflib.unified_diff(
        original.decode().splitlines(keepends=True) if original is not None else [],
        staged.decode().splitlines(keepends=True),
        fromfile='a/'+p if original is not None else '/dev/null', tofile='b/'+p))
    manifest['staged_files'].append({'path':p,'baseline_sha256':sha(original) if original is not None else None, 'candidate_sha256':sha(staged), 'candidate_lines':len(staged.decode().splitlines())})
(out/'guides-proposal.patch').write_text(patch)
manifest['artifacts']={p:sha((out/p).read_bytes()) for p in ['audit.md','guides-proposal.patch']}
# Only statically inventory file targets. Do not run docs_check/tests/browser.
links=[]
for p in paths:
    for match in re.finditer(r'!?\[[^\]]*\]\(([^)]+)\)',(out/'files'/p).read_text()):
        target=match.group(1)
        if '://' in target: continue
        target_file=target.split('#',1)[0]
        resolved=((out/'files'/p).parent/target_file).resolve()
        staged_exists=resolved.exists()
        repo_exists=((repo/p).parent/target_file).resolve().exists()
        links.append({'document':p,'target':target,'file_present_in_staged_or_repo':staged_exists or repo_exists,'anchor_verified':False if '#' in target else None})
manifest['static_link_file_inventory']=links
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'staged_files':manifest['staged_files'], 'audit_sha256':manifest['artifacts']['audit.md'],'patch_sha256':manifest['artifacts']['guides-proposal.patch'],'manifest_sha256':sha((out/'manifest.json').read_bytes()),'link_file_inventory_count':len(links),'missing_link_files':[r for r in links if not r['file_present_in_staged_or_repo']]},ensure_ascii=False,indent=2))
